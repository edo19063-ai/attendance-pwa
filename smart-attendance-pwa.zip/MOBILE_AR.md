# تطبيق الجوال (أندرويد APK / iOS)

مجلد `mobile/` يغلّف الواجهة بـ **Capacitor** فينتج تطبيقاً أصلياً: الواجهة مضمّنة داخله، ويتصل بخادمك عبر HTTPS. لا يحوي التطبيق أي سر أو منطق تحقق.

## ما الممكن على كل منصة (بصراحة)
| المنصة | الناتج | كيف يثبّته المستخدم |
|---|---|---|
| **أندرويد** (وهواتف Huawei بلا خدمات Google) | `APK` للتثبيت المباشر، و`AAB` لـ Google Play | يفتح ملف APK (مع السماح بالتثبيت من مصدر غير معروف)، أو من Google Play |
| **آيفون** | تطبيق iOS | **لا يوجد APK للآيفون.** النشر يتطلب حساب Apple Developer (99$ سنوياً) عبر TestFlight أو App Store |
| **أي هاتف، مجاناً** | التطبيق القابل للتثبيت (PWA) الجاهز أصلاً | Safari ← مشاركة ← «إضافة إلى الشاشة الرئيسية»، أو Chrome ← «تثبيت التطبيق» |

إن لم تملك حساب Apple Developer فالـ PWA هو الحل المجاني الكامل للآيفون (راجع `DEPLOY_AR.md`).

## قبل البناء: تجهيز الخادم
1. انشر الخادم على **HTTPS** (`DEPLOY_AR.md`).
2. فعّل `ALLOW_NATIVE_APP=1` في بيئة الخادم، وإلا يرفض الخادم طلبات التطبيق (CORS) فيظهر «تعذر الاتصال».

## الطريقة الأسهل: بناء آلي على GitHub (لا تحتاج Android Studio)
1. ارفع المشروع إلى مستودع GitHub.
2. Settings ← Secrets and variables ← Actions ← **Variables**:
   - `API_URL` = `https://attendance.example.com/api` (إلزامي)
   - `APP_ID` = معرّف تطبيقك مثل `edu.mycollege.attendance` (**غيّره قبل أول بناء**، لا يمكن تغييره لاحقاً بعد النشر)
   - `APP_NAME` = اسم التطبيق (اختياري)
3. Actions ← **Build mobile apps** ← Run workflow.
4. نزّل الملفات من Artifacts:
   - `android-apk`: ملف `app-debug.apk` يُثبَّت فوراً للتجربة.
   - `ios-simulator-build`: يتحقق أن تطبيق iOS يُبنى (للمحاكي فقط، لا يعمل على آيفون حقيقي).

### توقيع نسخة الإنتاج لأندرويد (مطلوب للنشر)
```bash
keytool -genkeypair -v -keystore release.keystore -alias attendance \
  -keyalg RSA -keysize 2048 -validity 10000
base64 -w0 release.keystore   # انسخ الناتج
```
أضف Secrets: `ANDROID_KEYSTORE_BASE64` و`ANDROID_KEYSTORE_PASSWORD` و`ANDROID_KEY_ALIAS` و`ANDROID_KEY_PASSWORD`.
عندها يُنتج الخط `smart-attendance-release.apk` و`smart-attendance-release.aab` موقَّعين.
⚠️ **احتفظ بملف `release.keystore` وكلمتي المرور في مكان آمن للأبد**؛ فقدانه يمنعك من تحديث التطبيق على Google Play.

## البناء على جهازك
المتطلبات: Node 20+، وللأندرويد JDK 21 وAndroid Studio (أو Android SDK)، وللآيفون macOS وXcode وCocoaPods.
```bash
cd mobile && npm install
VITE_API_URL=https://attendance.example.com/api npm run build:web   # يبني الواجهة ويتحقق من تضمين الرابط
APP_ID=edu.mycollege.attendance npm run android                     # أول مرة فقط يلزم APP_ID

cd android && ./gradlew assembleDebug
# الناتج: mobile/android/app/build/outputs/apk/debug/app-debug.apk

# آيفون (على macOS):
cd .. && npm run ios && npm run open:ios
# في Xcode: Signing & Capabilities ← اختر Team ← شغّل على جهازك، أو Product ← Archive ← Distribute (TestFlight)
```
`npm run build:web` يرفض أي رابط ليس HTTPS كاملاً، ويتأكد أن الرابط ضُمِّن فعلاً في الحزمة.
للتجربة المحلية فقط يمكن `ALLOW_INSECURE_API=1` مع رابط http (أندرويد 9+ وiOS يمنعان HTTP عادةً).

## ما أضافه المشروع
- **الصلاحيات تلقائياً:** الكاميرا والموقع (أندرويد: `AndroidManifest.xml`، آيفون: `Info.plist` بنصوص عربية). كما يعطّل النسخ الاحتياطي لبيانات التطبيق، ويمنع HTTP غير المشفر.
- **الأيقونة وشاشة البداية** بجميع الأحجام (من `mobile/assets`).
- **الخادم:** يسمح بأصول التطبيق (`https://localhost` و`capacitor://localhost`) عند `ALLOW_NATIVE_APP=1`، وأُصلح CORS ليقبل `DELETE`.
- **الواجهة:** مهلة الطلبات تعمل على iOS 15 وما قبله، ولا يُسجَّل Service Worker داخل التطبيق، وهوامش آمنة للشاشات ذات النتوء.

## قبل النشر في المتاجر
- **Google Play:** رابط سياسة خصوصية يذكر الكاميرا (مسح الباركود) والموقع (التحقق من القاعة)، ونموذج «أمان البيانات». ارفع ملف `AAB` الموقَّع.
- **App Store:** ستراجع Apple التطبيق وقد ترفض التطبيقات التي هي «موقع مغلَّف» فقط (البند 4.2). نقاط قوتك: الكاميرا والموقع الأصليان ووظيفة واضحة، لكن القرار ليس مضموناً. وسيحتاج المراجعون **حساب تجربة**.
- ⚠️ **مراجعو المتاجر لن يكونوا داخل قاعتك**، فسيرفض الخادم مسحهم بسبب الموقع. جهّز محاضرة تجريبية بنصف قطر كبير (`allowed_radius_meters`) أو نسخة خادم تجريبية، واذكر الخطوات في ملاحظات المراجعة.

## قيود لم أتحقق منها
- **لم أبنِ التطبيق ولم أجرّبه على أي جهاز**: بيئتي بلا Android SDK ولا Xcode ولا شبكة. المختبَر فعلياً: سكربتات البناء وتعديل ملفات الصلاحيات (على قوالب مطابقة لما يولّده Capacitor) وملف YAML. **أول تشغيل للـ workflow قد يكشف مشاكل إصدارات**؛ ابدأ بنسخة debug واقرأ سجل الأخطاء.
- **الكاميرا والـ GPS داخل WebView:** يجب تجربتهما على جهاز حقيقي أندرويد وآيفون (على iOS تحديداً). إن لم تعمل الكاميرا يبقى إدخال الرمز يدوياً.
- **الحواف والنتوء:** افحص ظهور الواجهة تحت شريط الحالة على أجهزة حقيقية.
- **انتحال الموقع (Mock GPS):** التطبيق لا يكتشفه. اكتشافه يتطلب ملحقاً أصلياً (Play Integrity / App Attest) ولم يُنفَّذ.
- **التحديثات:** الواجهة مضمّنة، فتغيير الشاشات يتطلب إصداراً جديداً من التطبيق، أما تغييرات الخادم فتصل فوراً. أبقِ الـ API متوافقاً مع الإصدارات القديمة.
- إصدارات Capacitor (`^7`) وJava 21 مبنية على معرفتي؛ إن اختلفت المتطلبات فعدّل `mobile/package.json` وسطر `java-version` في الـ workflow.

## مشاكل شائعة
| العَرَض | السبب والحل |
|---|---|
| «تعذر الاتصال بالخادم» | `API_URL` خطأ، أو `ALLOW_NATIVE_APP` غير مفعّل، أو الخادم بلا HTTPS صالح |
| الكاميرا سوداء | لم تُمنح الصلاحية: إعدادات الهاتف ← التطبيق ← الأذونات |
| «دقة GPS ضعيفة» | اخرج إلى مكان مفتوح وانتظر استقرار الموقع، وفعّل «الموقع الدقيق» |
| فشل `gradlew` | تأكد من JDK 21 ومتغير `ANDROID_HOME` |
| `APP_ID غير صالح` | استخدم ثلاثة أجزاء على الأقل مثل `edu.college.attendance` |
