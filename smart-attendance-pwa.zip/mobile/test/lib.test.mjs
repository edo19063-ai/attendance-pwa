import test from 'node:test';
import assert from 'node:assert/strict';
import { execFileSync } from 'node:child_process';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { normalizeApiUrl, validateAppId } from '../scripts/lib.mjs';

const here = path.dirname(fileURLToPath(import.meta.url));

test('normalizeApiUrl: accepts https, trims slashes, completes bare domains with /api', () => {
  assert.equal(normalizeApiUrl('https://att.example.com/api'), 'https://att.example.com/api');
  assert.equal(normalizeApiUrl('https://att.example.com/api/'), 'https://att.example.com/api');
  assert.equal(normalizeApiUrl('https://att.example.com'), 'https://att.example.com/api');
  assert.equal(normalizeApiUrl('https://att.example.com/'), 'https://att.example.com/api');
  assert.equal(normalizeApiUrl('  https://att.example.com:8443/v1/api  '), 'https://att.example.com:8443/v1/api');
});

test('normalizeApiUrl: rejects missing, malformed, relative, http, and credentials/query', () => {
  for (const bad of [undefined, '', '   ', '/api', 'att.example.com/api', 'ftp://x.com/api', 'javascript:alert(1)']) {
    assert.throws(() => normalizeApiUrl(bad), Error, String(bad));
  }
  assert.throws(() => normalizeApiUrl('http://att.example.com/api'), /https/);
  assert.throws(() => normalizeApiUrl('https://user:pw@att.example.com/api'), /بيانات دخول/);
  assert.throws(() => normalizeApiUrl('https://att.example.com/api?x=1'), /استعلام/);
});

test('normalizeApiUrl: http allowed only with the explicit insecure flag (local testing)', () => {
  assert.equal(normalizeApiUrl('http://192.168.1.20:4000/api', { allowInsecure: true }), 'http://192.168.1.20:4000/api');
});

test('validateAppId', () => {
  assert.equal(validateAppId('edu.mycollege.attendance'), 'edu.mycollege.attendance');
  assert.equal(validateAppId('com.smartattendance.app'), 'com.smartattendance.app');
  for (const bad of ['', 'app', 'com.app', '1com.app.x', 'com.my-app.x', 'com..app', undefined]) {
    assert.throws(() => validateAppId(bad), /APP_ID/, String(bad));
  }
});

test('prepare.mjs (DRY_RUN) prints the exact build sequence for each platform', () => {
  const script = path.join(here, '..', 'scripts', 'prepare.mjs');
  for (const platform of ['android', 'ios']) {
    const out = execFileSync('node', [script, platform], { env: { ...process.env, DRY_RUN: '1' }, encoding: 'utf8' });
    assert.match(out, new RegExp(`npx cap add ${platform}`));
    assert.match(out, new RegExp(`npx capacitor-assets generate --${platform}`));
    assert.match(out, new RegExp(`npx cap sync ${platform}`));
    assert.ok(out.indexOf('cap add') < out.indexOf('capacitor-assets') && out.indexOf('capacitor-assets') < out.indexOf('cap sync'));
  }
  assert.throws(() => execFileSync('node', [script, 'windows'], { env: { ...process.env, DRY_RUN: '1' }, stdio: 'pipe' }));
  assert.throws(
    () => execFileSync('node', [script, 'android'], { env: { ...process.env, DRY_RUN: '1', APP_ID: 'bad id' }, stdio: 'pipe' }),
    (e) => /APP_ID/.test(String(e.stderr))
  );
});
