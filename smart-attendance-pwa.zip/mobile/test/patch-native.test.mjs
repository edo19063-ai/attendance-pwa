import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { patchAndroidManifest, patchInfoPlist, patchAndroid, patchIos, ANDROID_PERMISSIONS, ANDROID_FEATURES, IOS_KEYS } from '../scripts/patch-native.mjs';
import { ANDROID_MANIFEST, INFO_PLIST } from './fixtures.mjs';

const count = (s, needle) => s.split(needle).length - 1;

test('android: adds camera + location permissions and optional hardware features', () => {
  const out = patchAndroidManifest(ANDROID_MANIFEST);
  for (const p of ANDROID_PERMISSIONS) assert.equal(count(out, `<uses-permission android:name="${p}"`), 1, p);
  for (const f of ANDROID_FEATURES) assert.match(out, new RegExp(`<uses-feature android:name="${f.replace(/\./g, '\\.')}" android:required="false"`));
  assert.ok(out.includes('android.permission.INTERNET')); // لم يُمسّ
  assert.ok(out.trimEnd().endsWith('</manifest>'));
});

test('android: disables backup and cleartext traffic', () => {
  const out = patchAndroidManifest(ANDROID_MANIFEST);
  assert.ok(!out.includes('android:allowBackup="true"'));
  assert.match(out, /android:allowBackup="false"/);
  assert.equal(count(out, 'android:usesCleartextTraffic="false"'), 1);
});

test('android: idempotent (second run changes nothing, no duplicates)', () => {
  const once = patchAndroidManifest(ANDROID_MANIFEST);
  assert.equal(patchAndroidManifest(once), once);
});

test('android: respects an existing cleartext setting and existing permissions', () => {
  const custom = ANDROID_MANIFEST.replace('<application', '<application android:usesCleartextTraffic="true"')
    .replace('</manifest>', '    <uses-permission android:name="android.permission.CAMERA" />\n</manifest>');
  const out = patchAndroidManifest(custom);
  assert.equal(count(out, 'usesCleartextTraffic'), 1);
  assert.equal(count(out, 'android.permission.CAMERA'), 1);
});

test('android: rejects unrecognised manifests instead of corrupting them', () => {
  assert.throws(() => patchAndroidManifest('<manifest></manifest>'), /غير مألوف/);
  assert.throws(() => patchAndroidManifest('not xml'), /غير مألوف/);
});

test('ios: adds usage descriptions (Arabic) and export-compliance key once', () => {
  const out = patchInfoPlist(INFO_PLIST);
  for (const [k, text] of Object.entries(IOS_KEYS)) {
    assert.equal(count(out, `<key>${k}</key>`), 1, k);
    assert.ok(out.includes(text));
  }
  assert.equal(count(out, '<key>ITSAppUsesNonExemptEncryption</key>'), 1);
  assert.match(out, /<key>ITSAppUsesNonExemptEncryption<\/key>\s*<false\/>/);
  assert.ok(out.includes('UIRequiredDeviceCapabilities')); // المحتوى الأصلي سليم
  assert.ok(out.trimEnd().endsWith('</plist>'));
  // ما زالت وثيقة plist متوازنة
  assert.equal(count(out, '<dict>'), count(out, '</dict>'));
});

test('ios: idempotent and rejects non-plist input', () => {
  const once = patchInfoPlist(INFO_PLIST);
  assert.equal(patchInfoPlist(once), once);
  assert.throws(() => patchInfoPlist('hello'), /غير مألوف/);
});

test('file helpers patch real files in place, and fail clearly when platform is missing', () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'native-'));
  const androidDir = path.join(dir, 'android');
  const iosDir = path.join(dir, 'ios');
  fs.mkdirSync(path.join(androidDir, 'app/src/main'), { recursive: true });
  fs.mkdirSync(path.join(iosDir, 'App/App'), { recursive: true });
  fs.writeFileSync(path.join(androidDir, 'app/src/main/AndroidManifest.xml'), ANDROID_MANIFEST);
  fs.writeFileSync(path.join(iosDir, 'App/App/Info.plist'), INFO_PLIST);

  assert.equal(patchAndroid(androidDir), true);
  assert.equal(patchAndroid(androidDir), false); // الثانية: لا تغيير
  assert.equal(patchIos(iosDir), true);
  assert.equal(patchIos(iosDir), false);
  assert.match(fs.readFileSync(path.join(iosDir, 'App/App/Info.plist'), 'utf8'), /NSCameraUsageDescription/);
  assert.throws(() => patchAndroid(path.join(dir, 'nope')), /cap add/);
});
