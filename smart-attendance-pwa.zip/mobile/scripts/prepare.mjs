#!/usr/bin/env node
/**
 * يجهّز مشروع المنصة (android أو ios): يضيفه إن لم يوجد، يولّد الأيقونات، يضبط الصلاحيات، ثم يزامن الواجهة.
 * الاستخدام:  node scripts/prepare.mjs android
 * متغيرات اختيارية: APP_ID (قبل أول إضافة للمنصة) ، APP_NAME ، DRY_RUN=1 (يطبع الأوامر فقط)
 */
import { execSync } from 'node:child_process';
import { existsSync, readFileSync, writeFileSync } from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { patchAndroid, patchIos } from './patch-native.mjs';
import { validateAppId } from './lib.mjs';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const platform = process.argv[2];
const DRY = process.env.DRY_RUN === '1';

function fail(msg) {
  console.error(`✘ ${msg}`);
  process.exit(1);
}
if (!['android', 'ios'].includes(platform)) fail('الاستخدام: node scripts/prepare.mjs <android|ios>');

const run = (cmd) => {
  console.log('▶', cmd);
  if (!DRY) execSync(cmd, { cwd: root, stdio: 'inherit' });
};

// 1) إعدادات التطبيق (اسم/معرّف) — يجب ضبط المعرّف قبل إنشاء مشروع المنصة
const cfgPath = path.join(root, 'capacitor.config.json');
const cfg = JSON.parse(readFileSync(cfgPath, 'utf8'));
const platformDir = path.join(root, platform);
const platformExists = existsSync(platformDir);
let changed = false;
if (process.env.APP_ID && process.env.APP_ID !== cfg.appId) {
  if (platformExists) fail(`مشروع ${platform} موجود بالفعل؛ تغيير APP_ID بعد إنشائه يتطلب حذف المجلد ${platform}/ وإعادة التوليد.`);
  cfg.appId = validateAppId(process.env.APP_ID);
  changed = true;
}
if (process.env.APP_NAME && process.env.APP_NAME !== cfg.appName) {
  cfg.appName = process.env.APP_NAME;
  changed = true;
}
validateAppId(cfg.appId);
if (changed && !DRY) writeFileSync(cfgPath, JSON.stringify(cfg, null, 2) + '\n', 'utf8');
console.log(`التطبيق: ${cfg.appName} (${cfg.appId}) → ${platform}`);

// 2) الواجهة المبنية يجب أن تكون جاهزة
if (!DRY && !existsSync(path.join(root, 'www', 'index.html'))) {
  fail('لا توجد واجهة مبنية في www/. شغّل أولاً:  VITE_API_URL=https://... npm run build:web');
}

// 3) إنشاء المنصة + الأيقونات + الصلاحيات + المزامنة
if (!platformExists) run(`npx cap add ${platform}`);
run(`npx capacitor-assets generate --${platform}`);
if (!DRY) {
  const touched = platform === 'android' ? patchAndroid(platformDir) : patchIos(platformDir);
  console.log(touched ? '✔ ضُبطت صلاحيات الكاميرا والموقع وإعدادات الأمان' : '✔ الصلاحيات مضبوطة مسبقاً');
}
run(`npx cap sync ${platform}`);
console.log(`\n✔ ${platform} جاهز. ${platform === 'android' ? 'ابنِ بـ: cd android && ./gradlew assembleDebug' : 'افتحه بـ: npm run open:ios (يتطلب macOS وXcode)'}`);
