#!/usr/bin/env node
/**
 * يبني الواجهة (web/) برابط الـ API المطلوب ثم ينسخها إلى mobile/www ليغلّفها Capacitor.
 * الاستخدام:  VITE_API_URL=https://attendance.example.com/api npm run build:web
 */
import { execSync } from 'node:child_process';
import { cpSync, existsSync, readdirSync, readFileSync, rmSync } from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { normalizeApiUrl } from './lib.mjs';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const webDir = path.resolve(root, '..', 'web');
const dist = path.join(webDir, 'dist');
const www = path.join(root, 'www');

function fail(msg) {
  console.error(`✘ ${msg}`);
  process.exit(1);
}

let apiUrl;
try {
  apiUrl = normalizeApiUrl(process.env.VITE_API_URL, { allowInsecure: process.env.ALLOW_INSECURE_API === '1' });
} catch (e) {
  fail(e.message);
}
console.log(`API: ${apiUrl}`);

const run = (cmd) => {
  console.log('▶', cmd);
  execSync(cmd, { cwd: webDir, stdio: 'inherit', env: { ...process.env, VITE_API_URL: apiUrl } });
};
run('npm install --no-audit --no-fund');
run('npm run build');

if (!existsSync(path.join(dist, 'index.html'))) fail('لم يُنتَج web/dist/index.html. راجع أخطاء البناء أعلاه.');

// تأكد أن الرابط ضُمِّن فعلاً في الحزمة (وإلا سيحاول التطبيق الاتصال بمسار نسبي لا وجود له)
const assets = path.join(dist, 'assets');
const embedded =
  existsSync(assets) &&
  readdirSync(assets)
    .filter((f) => f.endsWith('.js'))
    .some((f) => readFileSync(path.join(assets, f), 'utf8').includes(apiUrl));
if (!embedded) fail(`رابط الـ API (${apiUrl}) غير موجود داخل الحزمة المبنية. تأكد أن الواجهة تقرأ VITE_API_URL.`);
console.log('✔ رابط الـ API مضمَّن في الحزمة');

rmSync(www, { recursive: true, force: true });
cpSync(dist, www, { recursive: true });
rmSync(path.join(www, 'sw.js'), { force: true }); // لا حاجة لـ Service Worker داخل التطبيق
console.log(`✔ نُسخت الواجهة إلى ${www}`);
