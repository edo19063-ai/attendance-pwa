/** دوال نقية (بلا آثار جانبية) قابلة للاختبار. */

/**
 * يتحقق من رابط الـ API الذي سيُضمَّن في التطبيق ويوحّد صيغته.
 * التطبيق يعمل من ملفات محلية، فلا يصلح الرابط النسبي /api: يلزم رابط كامل HTTPS.
 */
export function normalizeApiUrl(raw, { allowInsecure = false } = {}) {
  if (!raw || !String(raw).trim()) {
    throw new Error('VITE_API_URL مطلوب: رابط الخادم الكامل، مثل https://attendance.example.com/api');
  }
  let u;
  try {
    u = new URL(String(raw).trim());
  } catch {
    throw new Error(`رابط الـ API غير صالح: ${raw}`);
  }
  if (u.protocol !== 'https:' && !(allowInsecure && u.protocol === 'http:')) {
    throw new Error('رابط الـ API يجب أن يبدأ بـ https:// (أندرويد وآيفون يمنعان HTTP العادي). للتجربة المحلية فقط: ALLOW_INSECURE_API=1');
  }
  if (u.username || u.password || u.search || u.hash) {
    throw new Error('رابط الـ API يجب ألا يحوي بيانات دخول أو معاملات استعلام');
  }
  let p = u.pathname.replace(/\/+$/, '');
  if (p === '') p = '/api'; // أُدخل النطاق فقط: نكمل المسار المعتاد
  return `${u.origin}${p}`;
}

/** معرّف تطبيق صالح بصيغة أندرويد/آبل: com.company.app */
export function validateAppId(id) {
  if (!/^[a-z][a-z0-9_]*(\.[a-z][a-z0-9_]*){2,}$/i.test(id || '')) {
    throw new Error(`APP_ID غير صالح: "${id}". استخدم صيغة مثل edu.mycollege.attendance (ثلاثة أجزاء على الأقل)`);
  }
  return id;
}
