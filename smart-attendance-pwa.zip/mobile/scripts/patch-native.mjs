/**
 * يضيف إلى مشروعي أندرويد وiOS (اللذين يولّدهما Capacitor) ما يلزم للكاميرا والموقع،
 * ويشدّد الأمان. دوال نقية وقابلة للإعادة (idempotent): تشغيلها مرتين لا يكرر شيئاً.
 */
import { existsSync, readFileSync, writeFileSync } from 'node:fs';

export const ANDROID_PERMISSIONS = [
  'android.permission.CAMERA',
  'android.permission.ACCESS_FINE_LOCATION',
  'android.permission.ACCESS_COARSE_LOCATION',
];
// required=false: لا يمنع Google Play تثبيت التطبيق على أجهزة بلا كاميرا/GPS (يبقى الإدخال اليدوي للرمز)
export const ANDROID_FEATURES = ['android.hardware.camera', 'android.hardware.location.gps'];

export const IOS_KEYS = {
  NSCameraUsageDescription: 'يستخدم التطبيق الكاميرا لمسح باركود الحضور فقط.',
  NSLocationWhenInUseUsageDescription: 'يتحقق التطبيق من وجودك داخل القاعة عند تسجيل الحضور فقط.',
};

export function patchAndroidManifest(xml) {
  if (!/<\/manifest>/.test(xml) || !/<application\b/.test(xml)) {
    throw new Error('AndroidManifest.xml غير مألوف (لا يحوي <application> و</manifest>)');
  }
  let out = xml;

  // لا نسخ احتياطي عبر adb/السحابة لبيانات التطبيق (فيها رمز جلسة المحاضر)
  out = out.replace(/android:allowBackup="true"/, 'android:allowBackup="false"');
  // لا اتصال HTTP غير مشفر
  if (!/android:usesCleartextTraffic=/.test(out)) {
    out = out.replace(/<application\b/, '<application\n        android:usesCleartextTraffic="false"');
  }

  const lines = [];
  for (const p of ANDROID_PERMISSIONS) {
    if (!out.includes(`android:name="${p}"`)) lines.push(`    <uses-permission android:name="${p}" />`);
  }
  for (const f of ANDROID_FEATURES) {
    if (!out.includes(`android:name="${f}"`)) lines.push(`    <uses-feature android:name="${f}" android:required="false" />`);
  }
  if (lines.length) out = out.replace(/<\/manifest>/, `${lines.join('\n')}\n</manifest>`);
  return out;
}

export function patchInfoPlist(plist) {
  const closing = plist.lastIndexOf('</dict>');
  if (closing === -1 || !/<plist\b/.test(plist)) throw new Error('Info.plist غير مألوف');
  const add = [];
  for (const [key, text] of Object.entries(IOS_KEYS)) {
    if (!plist.includes(`<key>${key}</key>`)) add.push(`\t<key>${key}</key>\n\t<string>${text}</string>`);
  }
  // بلا هذا المفتاح يسأل App Store Connect عن "التصدير والتشفير" عند كل رفع (التطبيق لا يضيف تشفيراً خاصاً)
  if (!plist.includes('<key>ITSAppUsesNonExemptEncryption</key>')) {
    add.push('\t<key>ITSAppUsesNonExemptEncryption</key>\n\t<false/>');
  }
  if (!add.length) return plist;
  return `${plist.slice(0, closing)}${add.join('\n')}\n${plist.slice(closing)}`;
}

function patchFile(file, fn) {
  if (!existsSync(file)) throw new Error(`الملف غير موجود: ${file} (شغّل cap add أولاً)`);
  const before = readFileSync(file, 'utf8');
  const after = fn(before);
  if (after !== before) writeFileSync(file, after, 'utf8');
  return after !== before;
}

export const patchAndroid = (androidDir) =>
  patchFile(`${androidDir}/app/src/main/AndroidManifest.xml`, patchAndroidManifest);
export const patchIos = (iosDir) => patchFile(`${iosDir}/App/App/Info.plist`, patchInfoPlist);
