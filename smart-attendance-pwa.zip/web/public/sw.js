/*
 * Service Worker: يجعل التطبيق قابلاً للتثبيت ويسرّع التحميل.
 * قواعد أمنية مقصودة:
 *  - لا يخزّن أي طلب إلى /api أبداً (رموز الحضور والبيانات الحساسة تأتي من الشبكة دائماً).
 *  - يخزّن فقط ملفات الواجهة الثابتة من نفس النطاق.
 * ارفع رقم VERSION عند أي تغيير في هذا الملف.
 */
const VERSION = 'v1';
const CACHE = `attendance-shell-${VERSION}`;
const SHELL = ['/', '/manifest.webmanifest', '/icons/icon-192.png', '/icons/icon-512.png'];

self.addEventListener('install', (event) => {
  event.waitUntil(caches.open(CACHE).then((c) => c.addAll(SHELL)).then(() => self.skipWaiting()));
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches
      .keys()
      .then((keys) => Promise.all(keys.filter((k) => k !== CACHE).map((k) => caches.delete(k))))
      .then(() => self.clients.claim())
  );
});

self.addEventListener('fetch', (event) => {
  const req = event.request;
  const url = new URL(req.url);
  if (req.method !== 'GET' || url.origin !== self.location.origin) return; // لا نتدخل
  if (url.pathname.startsWith('/api/')) return; // البيانات الحساسة: شبكة فقط

  // التنقل بين الصفحات: الشبكة أولاً، ثم النسخة المخزّنة عند انقطاع الاتصال
  if (req.mode === 'navigate') {
    event.respondWith(
      fetch(req)
        .then((res) => {
          const copy = res.clone();
          caches.open(CACHE).then((c) => c.put('/', copy));
          return res;
        })
        .catch(() => caches.match('/'))
    );
    return;
  }

  // الملفات الثابتة (أسماؤها تحوي hash): المخزّن أولاً
  if (url.pathname.startsWith('/assets/') || url.pathname.startsWith('/icons/')) {
    event.respondWith(
      caches.match(req).then(
        (hit) =>
          hit ||
          fetch(req).then((res) => {
            if (res.ok) {
              const copy = res.clone();
              caches.open(CACHE).then((c) => c.put(req, copy));
            }
            return res;
          })
      )
    );
  }
});
