/**
 * يصدّر بيانات الواجهة الأولية إلى ملف JSON يستورده الخادم عند أول تشغيل،
 * كي تتطابق معرّفات الطلاب والمقررات والمحاضرات بين الواجهة والخادم.
 *
 * الاستخدام:  npm run export-seed
 * (الأكواد السرية القديمة والصور لا تُصدَّر عمداً؛ الخادم يولّد أكواداً جديدة.)
 */
import { mkdirSync, writeFileSync } from 'node:fs';
import { dirname, resolve } from 'node:path';
import {
  INITIAL_STUDENTS,
  INITIAL_COURSES,
  INITIAL_ENROLLMENTS,
  INITIAL_LECTURES,
  INITIAL_ATTENDANCE,
  INITIAL_PARTICIPATIONS,
  INITIAL_FEEDBACKS,
} from '../src/data/initialData';

const target = resolve(process.argv[2] ?? '../server/data/seed-input.json');

const data = {
  students: INITIAL_STUDENTS.map((s) => ({
    student_id: s.student_id,
    full_name: s.full_name,
    university_id: s.university_id,
  })),
  courses: INITIAL_COURSES.map((c) => ({
    course_id: c.course_id,
    course_name: c.course_name,
    course_code: c.course_code,
  })),
  enrollments: INITIAL_ENROLLMENTS.map((e) => ({ student_id: e.student_id, course_id: e.course_id })),
  lectures: INITIAL_LECTURES,
  attendance: INITIAL_ATTENDANCE,
  participations: INITIAL_PARTICIPATIONS,
  feedbacks: INITIAL_FEEDBACKS,
};

mkdirSync(dirname(target), { recursive: true });
writeFileSync(target, JSON.stringify(data, null, 2), 'utf8');
console.log(`تم التصدير إلى: ${target}`);
console.log(`طلاب: ${data.students.length} | مقررات: ${data.courses.length} | محاضرات: ${data.lectures.length} | سجلات حضور: ${data.attendance.length} | نقاط تفاعل: ${data.participations.length} | تقييمات: ${data.feedbacks.length}`);
