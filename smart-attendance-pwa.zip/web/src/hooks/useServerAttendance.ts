/**
 * خطافات React تربط الواجهة بالخادم الآمن.
 * تعيد بيانات بنفس أشكال دوال الـ Context القديمة، فيبقى تعديل المكونات صغيراً.
 * البيانات المرجعية الثابتة (أسماء، صور، مقررات) تبقى من الـ Context؛
 * أما حالة الحضور والتوكن والتقارير فمصدرها الخادم فقط.
 */
import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { useAttendance } from '../context/AttendanceContext';
import type {
  AcademicAdvisorAlert,
  AdvisorAlertStatus,
  AttendanceExcuse,
  AttendanceStatus,
  ExcuseStatus,
  Student,
  StudentAttendanceSummary,
} from '../types/attendance';
import {
  ApiError,
  addParticipation,
  autoGenerateAlerts,
  closeSession,
  createDelegation,
  createAlert,
  deleteAlert,
  errorMessage,
  fetchAlerts,
  fetchAssistantLog,
  fetchAtRisk,
  fetchDelegations,
  fetchFeedbackStats,
  fetchExcuses,
  revokeDelegation,
  reviewExcuse,
  updateAlert,
  type AssistantLogEntry,
  type AtRiskRow,
  type FeedbackStats,
  type ServerDelegation,
  type ServerAlert,
  type ServerExcuse,
  type ServerExcuseStatus,
  fetchLiveToken,
  fetchReport,
  fetchRoster,
  openSession,
  setStudentStatus,
  type RosterRow,
} from '../services/api';

// ======================================================================
// كشف المحاضرة (بديل getLectureDetails)
// ======================================================================
export interface LectureStudentRow {
  student: Student;
  status: AttendanceStatus;
  notes: string;
  recorded_at?: string;
  method: RosterRow['method'];
  distance_meters: number | null;
  /** نقاط التفاعل المتراكمة في مقرر المحاضرة (من الخادم) */
  points: number;
}

export function useLectureDetails(lectureId: number, pollMs = 0) {
  const { lectures, courses, students, enrollments } = useAttendance();
  // اللقطة مرتبطة برقم المحاضرة، فتُشتق حالة "تم التحميل" فوراً عند تبديل المحاضرة
  const [snapshot, setSnapshot] = useState<{ lectureId: number; rows: RosterRow[] } | null>(null);
  const [errorState, setErrorState] = useState<{ lectureId: number; message: string } | null>(null);
  const activeLecture = useRef(lectureId);
  activeLecture.current = lectureId;

  const roster = snapshot && snapshot.lectureId === lectureId ? snapshot.rows : null;
  const error = errorState && errorState.lectureId === lectureId ? errorState.message : null;
  const loaded = roster !== null;
  const loading = !loaded && error === null;

  const refresh = useCallback(async () => {
    const requested = lectureId;
    try {
      const r = await fetchRoster(requested);
      if (activeLecture.current !== requested) return; // تجاهل استجابة قديمة
      setSnapshot({ lectureId: requested, rows: r.roster });
      setErrorState(null);
    } catch (e) {
      if (activeLecture.current === requested) setErrorState({ lectureId: requested, message: errorMessage(e) });
    }
  }, [lectureId]);

  useEffect(() => {
    refresh();
    if (pollMs > 0) {
      const id = setInterval(refresh, pollMs);
      return () => clearInterval(id);
    }
  }, [pollMs, refresh]);

  const lecture = lectures.find((l) => l.lecture_id === lectureId);
  const course = lecture ? courses.find((c) => c.course_id === lecture.course_id) : undefined;

  const studentsWithStatus: LectureStudentRow[] = useMemo(() => {
    if (!lecture) return [];
    const byStudent = new Map<number, RosterRow>((roster ?? []).map((r): [number, RosterRow] => [r.studentId, r]));
    return enrollments
      .filter((e) => e.course_id === lecture.course_id)
      .map((e) => students.find((s) => s.student_id === e.student_id))
      .filter((s): s is Student => Boolean(s))
      .map((student) => {
        const row = byStudent.get(student.student_id);
        return {
          student,
          status: row?.status ?? 'Absent',
          notes: row?.notes ?? '',
          recorded_at: row?.recordedAt ?? undefined,
          method: row?.method ?? null,
          distance_meters: row?.distanceMeters ?? null,
          points: row?.points ?? 0,
        };
      });
  }, [lecture, roster, enrollments, students]);

  /** تعديل يدوي (يُسجَّل على الخادم كقرار محاضر ولا يمكن تجاوزه بالمسح). */
  const updateStatus = useCallback(
    async (studentId: number, status: AttendanceStatus, notes = ''): Promise<{ ok: boolean; message?: string }> => {
      try {
        await setStudentStatus(lectureId, studentId, status, notes);
        await refresh();
        return { ok: true };
      } catch (e) {
        return { ok: false, message: errorMessage(e) };
      }
    },
    [lectureId, refresh]
  );

  /** منح نقطة تفاعل (محاضر أو معيد مفوَّض لهذه المحاضرة). */
  const addPoint = useCallback(
    async (studentId: number, reason?: string): Promise<{ ok: boolean; message: string }> => {
      try {
        const r = await addParticipation(lectureId, studentId, reason);
        await refresh();
        return { ok: true, message: `تم منح نقطة التميز والمشاركة للطالب ${r.studentName} (المجموع: ${r.points})` };
      } catch (e) {
        return { ok: false, message: errorMessage(e) };
      }
    },
    [lectureId, refresh]
  );

  /** تحضير الجميع (يتخطى من هو حاضر بالفعل). */
  const markAllPresent = useCallback(async (): Promise<{ ok: boolean; failed: number }> => {
    const targets = studentsWithStatus.filter((r) => r.status !== 'Present');
    const results = await Promise.allSettled(
      targets.map((r) => setStudentStatus(lectureId, r.student.student_id, 'Present', r.notes))
    );
    await refresh();
    const failed = results.filter((r) => r.status === 'rejected').length;
    return { ok: failed === 0, failed };
  }, [studentsWithStatus, lectureId, refresh]);

  return { lecture, course, studentsWithStatus, loaded, loading, error, refresh, updateStatus, markAllPresent, addPoint };
}

// ======================================================================
// تقرير المقرر (بديل getCourseAttendanceReport / getAbsenceThresholdReport)
// ======================================================================
export function useCourseReport(courseId: number) {
  const { courses } = useAttendance();
  const [rows, setRows] = useState<Awaited<ReturnType<typeof fetchReport>>['rows']>([]);
  const [totalLectures, setTotalLectures] = useState<number>(0);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);
  const activeCourse = useRef(courseId);
  activeCourse.current = courseId;

  const refresh = useCallback(async () => {
    const requested = courseId;
    setLoading(true);
    try {
      const r = await fetchReport(requested);
      if (activeCourse.current !== requested) return;
      setRows(r.rows);
      setTotalLectures(r.totalLectures);
      setError(null);
    } catch (e) {
      if (activeCourse.current === requested) setError(errorMessage(e));
    } finally {
      if (activeCourse.current === requested) setLoading(false);
    }
  }, [courseId]);

  useEffect(() => {
    setRows([]);
    refresh();
  }, [refresh]);

  const course = courses.find((c) => c.course_id === courseId);

  const summaries: StudentAttendanceSummary[] = useMemo(
    () =>
      rows
        .map((r) => ({
          student_id: r.studentId,
          full_name: r.fullName,
          university_id: r.universityId,
          course_name: course?.course_name ?? '',
          course_code: course?.course_code ?? '',
          total_lectures: r.totalLectures,
          present_count: r.present,
          absent_count: r.absent,
          late_count: r.late,
          excused_count: r.excused,
          attendance_percentage: r.attendancePercentage,
          absent_percentage: r.totalLectures > 0 ? Math.round((r.absent / r.totalLectures) * 1000) / 10 : 0,
        }))
        .sort((a, b) => b.absent_count - a.absent_count || a.full_name.localeCompare(b.full_name)),
    [rows, course]
  );

  return { summaries, totalLectures, loading, error, refresh };
}

/** نفس قاعدة الإنذار القديمة: غياب أكثر من الحد، أو نسبة غياب ≥ النسبة المحددة. */
export function filterAbsenceThreshold(
  summaries: StudentAttendanceSummary[],
  minAbsences: number,
  minAbsencePct: number
): StudentAttendanceSummary[] {
  return summaries.filter((s) => s.absent_count > minAbsences || s.absent_percentage >= minAbsencePct);
}

// ======================================================================
// الرمز المباشر وجلسة الحضور (للمحاضر)
// ======================================================================
export interface LiveTokenState {
  token: string;
  /** وقت انتهاء الرمز بساعة هذا الجهاز (ms) */
  expiresAt: number;
  intervalSeconds: number;
}

export function useLiveSession(lectureId: number) {
  const [isOpen, setIsOpen] = useState<boolean | null>(null); // null = جارٍ التحقق
  const [live, setLive] = useState<LiveTokenState | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState<boolean>(false);
  const [generation, setGeneration] = useState<number>(0);

  useEffect(() => {
    let cancelled = false;
    let timer: ReturnType<typeof setTimeout> | undefined;

    const loop = async () => {
      try {
        const t = await fetchLiveToken(lectureId);
        if (cancelled) return;
        setLive({ token: t.token, expiresAt: Date.now() + t.expiresInMs, intervalSeconds: t.intervalSeconds });
        setIsOpen(true);
        setError(null);
        // الطلب التالي مع نهاية النافذة الحالية تماماً
        timer = setTimeout(loop, Math.max(t.expiresInMs + 40, 250));
      } catch (e) {
        if (cancelled) return;
        if (e instanceof ApiError && e.code === 'session_closed') {
          setIsOpen(false);
          setLive(null);
          setError(null);
          return; // لا استطلاع أثناء الإغلاق
        }
        if (e instanceof ApiError && e.status === 401) return; // البوابة ستعرض تسجيل الدخول
        setError(errorMessage(e));
        timer = setTimeout(loop, 3000);
      }
    };

    setIsOpen(null);
    setLive(null);
    loop();
    return () => {
      cancelled = true;
      if (timer) clearTimeout(timer);
    };
  }, [lectureId, generation]);

  const open = useCallback(async () => {
    setBusy(true);
    try {
      await openSession(lectureId);
      setGeneration((g) => g + 1);
    } catch (e) {
      setError(errorMessage(e));
    } finally {
      setBusy(false);
    }
  }, [lectureId]);

  const close = useCallback(async () => {
    setBusy(true);
    try {
      await closeSession(lectureId);
      setGeneration((g) => g + 1);
    } catch (e) {
      setError(errorMessage(e));
    } finally {
      setBusy(false);
    }
  }, [lectureId]);

  return { isOpen, live, error, busy, open, close };
}

// ======================================================================
// الأعذار (للمحاضر): قائمة المراجعة والقرار
// ======================================================================
const EXCUSE_STATUS_AR: Record<ServerExcuseStatus, ExcuseStatus> = {
  pending: 'قيد المراجعة',
  accepted: 'مقبول',
  rejected: 'مرفوض',
};

export function toAttendanceExcuse(e: ServerExcuse): AttendanceExcuse {
  return {
    excuse_id: e.id,
    student_id: e.studentId,
    lecture_id: e.lectureId,
    reason_text: e.reasonText,
    document_url: e.documentUrl,
    status: EXCUSE_STATUS_AR[e.status],
    submitted_at: new Date(e.submittedAt).toLocaleString('ar-SA'),
    student_name: e.studentName,
    university_id: e.universityId,
    lecture_topic: e.lectureTopic,
    course_name: e.courseName,
    review_notes: e.reviewNotes || undefined,
  };
}

export function useServerExcuses(pollMs = 10000) {
  const [rows, setRows] = useState<ServerExcuse[]>([]);
  const [loaded, setLoaded] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  const refresh = useCallback(async () => {
    try {
      const r = await fetchExcuses();
      setRows(r.excuses);
      setError(null);
    } catch (e) {
      setError(errorMessage(e));
    } finally {
      setLoaded(true);
    }
  }, []);

  useEffect(() => {
    refresh();
    if (pollMs > 0) {
      const id = setInterval(refresh, pollMs);
      return () => clearInterval(id);
    }
  }, [pollMs, refresh]);

  const excuses = useMemo(() => rows.map(toAttendanceExcuse), [rows]);

  /** القبول يحوّل الغياب إلى «معذور» في سجل الحضور على الخادم تلقائياً. */
  const review = useCallback(
    async (excuseId: number, action: 'accept' | 'reject', notes = ''): Promise<{ success: boolean; message: string }> => {
      try {
        await reviewExcuse(excuseId, action, notes);
        await refresh();
        return { success: true, message: `تم تحديث حالة العذر بنجاح إلى: ${action === 'accept' ? 'مقبول' : 'مرفوض'}` };
      } catch (e) {
        return { success: false, message: errorMessage(e) };
      }
    },
    [refresh]
  );

  return { excuses, loaded, error, refresh, review };
}

// ======================================================================
// الإرشاد الأكاديمي: الطلاب المرشحون للإنذار + التنبيهات
// ======================================================================
export interface AtRiskStudent {
  student_id: number;
  full_name: string;
  university_id: string;
  course_name: string;
  absent_count: number;
  absent_percentage: number;
}

export function useAtRisk(minAbsences = 2, minPct = 20) {
  const [rows, setRows] = useState<AtRiskRow[]>([]);
  const [error, setError] = useState<string | null>(null);

  const refresh = useCallback(async () => {
    try {
      const r = await fetchAtRisk(minAbsences, minPct);
      setRows(r.students);
      setError(null);
    } catch (e) {
      setError(errorMessage(e));
    }
  }, [minAbsences, minPct]);

  useEffect(() => {
    refresh();
  }, [refresh]);

  const students: AtRiskStudent[] = useMemo(
    () =>
      rows.map((r) => ({
        student_id: r.studentId,
        full_name: r.fullName,
        university_id: r.universityId,
        course_name: r.courseName,
        absent_count: r.absent,
        absent_percentage: r.absentPercentage,
      })),
    [rows]
  );

  return { students, error, refresh };
}

export function useAdvisorAlerts(enabled = true) {
  const { students, departments } = useAttendance();
  const [rows, setRows] = useState<ServerAlert[]>([]);
  const [error, setError] = useState<string | null>(null);

  const refresh = useCallback(async () => {
    if (!enabled) return; // المعيد المفوَّض لا يملك صلاحية التنبيهات
    try {
      const r = await fetchAlerts();
      setRows(r.alerts);
      setError(null);
    } catch (e) {
      setError(errorMessage(e));
    }
  }, [enabled]);

  useEffect(() => {
    refresh();
  }, [refresh]);

  const alerts: AcademicAdvisorAlert[] = useMemo(
    () =>
      rows.map((a) => {
        const st = students.find((s) => s.student_id === a.studentId);
        const dept = st?.department_id
          ? departments.find((d) => d.department_id === st.department_id)?.department_name
          : st?.department_name;
        return {
          alert_id: a.id,
          student_id: a.studentId,
          advisor_name: a.advisorName,
          absence_count: a.absenceCount,
          status: a.status,
          timestamp: new Date(a.createdAt).toLocaleString('ar-SA'),
          student_name: a.studentName,
          university_id: a.universityId,
          department: dept || 'تقنية المعلومات',
          notes: a.notes,
        };
      }),
    [rows, students, departments]
  );

  const create = useCallback(
    async (studentId: number, advisorName: string, absenceCount: number, notes = '') => {
      try {
        const r = await createAlert({ studentId, advisorName, absenceCount, notes });
        await refresh();
        return { success: true, message: `تم رفع تنبيه الإرشاد الأكاديمي للطالب (${r.alert.studentName}) بنجاح.` };
      } catch (e) {
        return { success: false, message: errorMessage(e) };
      }
    },
    [refresh]
  );

  const updateStatus = useCallback(
    async (alertId: number, status: AdvisorAlertStatus, notes?: string) => {
      try {
        await updateAlert(alertId, { status, notes });
        await refresh();
        return { success: true, message: `تم تحديث حالة التنبيه الأكاديمي إلى: (${status})` };
      } catch (e) {
        return { success: false, message: errorMessage(e) };
      }
    },
    [refresh]
  );

  const remove = useCallback(
    async (alertId: number) => {
      try {
        await deleteAlert(alertId);
        await refresh();
        return { success: true, message: 'تم حذف التنبيه' };
      } catch (e) {
        return { success: false, message: errorMessage(e) };
      }
    },
    [refresh]
  );

  const autoGenerate = useCallback(async () => {
    try {
      const r = await autoGenerateAlerts();
      await refresh();
      return { success: true, created: r.created, message: '' };
    } catch (e) {
      return { success: false, created: 0, message: errorMessage(e) };
    }
  }, [refresh]);

  return { alerts, error, refresh, create, updateStatus, remove, autoGenerate };
}

// ======================================================================
// إحصاءات تقييم المحاضرة (مجهولة الهوية)
// ======================================================================
export function useFeedbackStats(lectureId: number, pollMs = 8000): FeedbackStats {
  const [stats, setStats] = useState<{ lectureId: number; value: FeedbackStats } | null>(null);

  useEffect(() => {
    let cancelled = false;
    const load = async () => {
      try {
        const r = await fetchFeedbackStats(lectureId);
        if (!cancelled) setStats({ lectureId, value: { average: r.average, count: r.count, breakdown: r.breakdown } });
      } catch {
        /* يبقى آخر عرض صالح */
      }
    };
    load();
    const id = pollMs > 0 ? setInterval(load, pollMs) : undefined;
    return () => {
      cancelled = true;
      if (id) clearInterval(id);
    };
  }, [lectureId, pollMs]);

  return stats && stats.lectureId === lectureId ? stats.value : { average: 0, count: 0, breakdown: {} };
}

// ======================================================================
// تفويض المعيد (المحاضر فقط): إنشاء وسحب وقائمة التفويضات
// ======================================================================
export function useDelegations(lectureId: number, enabled: boolean) {
  const [rows, setRows] = useState<ServerDelegation[]>([]);
  const [error, setError] = useState<string | null>(null);

  const refresh = useCallback(async () => {
    if (!enabled) return;
    try {
      const r = await fetchDelegations(lectureId);
      setRows(r.delegations);
      setError(null);
    } catch (e) {
      setError(errorMessage(e));
    }
  }, [lectureId, enabled]);

  useEffect(() => {
    setRows([]);
    refresh();
    if (!enabled) return;
    const id = setInterval(refresh, 15000); // يلتقط انتهاء المدة تلقائياً
    return () => clearInterval(id);
  }, [refresh, enabled]);

  /** الكود الكامل يُعاد هنا مرة واحدة فقط ولا يمكن استرجاعه لاحقاً. */
  const create = useCallback(
    async (assistantName: string, durationMinutes: number) => {
      try {
        const r = await createDelegation({ assistantName, lectureId, durationMinutes });
        await refresh();
        return { ok: true as const, accessCode: r.accessCode, delegation: r.delegation };
      } catch (e) {
        return { ok: false as const, message: errorMessage(e) };
      }
    },
    [lectureId, refresh]
  );

  const revoke = useCallback(
    async (delegationId: number) => {
      try {
        await revokeDelegation(delegationId);
        await refresh();
        return { ok: true as const };
      } catch (e) {
        return { ok: false as const, message: errorMessage(e) };
      }
    },
    [refresh]
  );

  const active = useMemo(() => rows.filter((d) => d.status === 'active'), [rows]);
  return { delegations: rows, active, error, refresh, create, revoke };
}

// ======================================================================
// سجل تدقيق المحاضرة (يُجلب عند الطلب)
// ======================================================================
export function useAssistantLog(lectureId: number) {
  const [logs, setLogs] = useState<AssistantLogEntry[]>([]);
  const [error, setError] = useState<string | null>(null);

  const load = useCallback(async () => {
    try {
      const r = await fetchAssistantLog(lectureId);
      setLogs(r.logs);
      setError(null);
    } catch (e) {
      setError(errorMessage(e));
    }
  }, [lectureId]);

  useEffect(() => {
    setLogs([]);
    load();
  }, [load]);

  return { logs, error, reload: load };
}
