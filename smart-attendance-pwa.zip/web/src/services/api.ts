/**
 * عميل API للخادم الآمن. لا يحتوي أي سر ولا منطق تحقق: كل القرارات على الخادم.
 */
import type { AttendanceStatus, AdvisorAlertStatus } from '../types/attendance';

const BASE: string = (import.meta as { env?: Record<string, string> }).env?.VITE_API_URL ?? '/api';

// ---------------------------------------------------------------- أنواع
export interface RosterRow {
  studentId: number;
  universityId: string;
  fullName: string;
  status: AttendanceStatus;
  method: 'scan' | 'manual' | 'import' | null;
  notes: string;
  recordedAt: string | null;
  distanceMeters: number | null;
  /** نقاط التفاعل المتراكمة للطالب في مقرر المحاضرة */
  points: number;
}

export interface ReportRow {
  studentId: number;
  universityId: string;
  fullName: string;
  totalLectures: number;
  present: number;
  late: number;
  excused: number;
  absent: number;
  attendancePercentage: number;
}

export interface LiveToken {
  token: string;
  expiresInMs: number;
  intervalSeconds: number;
  serverTime: number;
}

export interface ScanResult {
  ok: true;
  status: 'Present' | 'Late';
  alreadyRecorded: boolean;
  studentName: string;
  /** رمز قصير العمر لتقييم المحاضرة دون إعادة إدخال الكود السري */
  feedbackToken: string;
  /** نقاط تفاعل الطالب في المقرر */
  participationPoints: number;
}

export interface FeedbackStats {
  average: number;
  count: number;
  breakdown: Record<number, number>;
}

export interface ServerDelegation {
  id: number;
  assistantName: string;
  lectureId: number;
  createdAt: string;
  expiresAt: string;
  revokedAt: string | null;
  status: 'active' | 'expired' | 'revoked';
}

export interface AssistantLogEntry {
  log_id: number;
  lecture_id: number;
  assistant_name: string;
  action_performed: string;
  timestamp: string;
  status: 'نجاح' | 'تحذير' | 'فشل';
  ip_address?: string;
}

/** من يستخدم الواجهة الآن: محاضر بصلاحية كاملة، أو معيد بتفويض مؤقت لمحاضرة واحدة. */
export interface AuthInfo {
  role: 'instructor' | 'assistant';
  assistantName?: string;
  lectureId?: number;
  expiresAt?: number;
}

export type ServerExcuseStatus = 'pending' | 'accepted' | 'rejected';

export interface ServerExcuse {
  id: number;
  studentId: number;
  universityId: string;
  studentName: string;
  lectureId: number;
  lectureTopic: string;
  courseName: string;
  reasonText: string;
  documentUrl: string;
  status: ServerExcuseStatus;
  submittedAt: string;
  reviewedAt: string | null;
  reviewNotes: string;
}

export interface AtRiskRow {
  studentId: number;
  universityId: string;
  fullName: string;
  courseId: number;
  courseName: string;
  courseCode: string;
  absent: number;
  totalLectures: number;
  absentPercentage: number;
}

export interface ServerAlert {
  id: number;
  studentId: number;
  universityId: string;
  studentName: string;
  advisorName: string;
  absenceCount: number;
  status: AdvisorAlertStatus;
  notes: string;
  createdAt: string;
  updatedAt: string;
}

export class ApiError extends Error {
  constructor(public status: number, public code: string, message: string) {
    super(message);
    this.name = 'ApiError';
  }
}

export const errorMessage = (e: unknown, fallback = 'حدث خطأ غير متوقع'): string =>
  e instanceof Error && e.message ? e.message : fallback;

// ---------------------------------------------------------------- جلسة المحاضر / المعيد
const TOKEN_KEY = 'instructor_token';
const AUTH_KEY = 'staff_auth';
let instructorToken: string | null = null;
let authInfo: AuthInfo | null = null;
try {
  instructorToken = sessionStorage.getItem(TOKEN_KEY);
  const saved = sessionStorage.getItem(AUTH_KEY);
  authInfo = saved ? (JSON.parse(saved) as AuthInfo) : instructorToken ? { role: 'instructor' } : null;
  if (!instructorToken) authInfo = null;
} catch {
  /* التخزين غير متاح */
}
const listeners = new Set<() => void>();
const notify = () => listeners.forEach((l) => l());

/** مسجّل دخول كمحاضر أو كمعيد مفوَّض. */
export const isInstructorLoggedIn = (): boolean => instructorToken !== null;
/** الدور الحالي (للعرض فقط: الخادم هو من يفرض الصلاحيات فعلاً). المرجع ثابت حتى يتغير الدور. */
export const getAuthInfo = (): AuthInfo | null => authInfo;
export const subscribeAuth = (cb: () => void): (() => void) => {
  listeners.add(cb);
  return () => listeners.delete(cb);
};

function setSession(token: string, info: AuthInfo): void {
  instructorToken = token;
  authInfo = info;
  try {
    sessionStorage.setItem(TOKEN_KEY, token);
    sessionStorage.setItem(AUTH_KEY, JSON.stringify(info));
  } catch {
    /* ignore */
  }
  notify();
}

export function logout(): void {
  instructorToken = null;
  authInfo = null;
  try {
    sessionStorage.removeItem(TOKEN_KEY);
    sessionStorage.removeItem(AUTH_KEY);
  } catch {
    /* ignore */
  }
  notify();
}

// ---------------------------------------------------------------- الطلب الأساسي
/** مهلة للطلب. AbortSignal.timeout غير متوفر في iOS 15 وما قبله، فنستخدم AbortController. */
function timeoutSignal(ms: number): AbortSignal {
  if (typeof AbortSignal !== 'undefined' && 'timeout' in AbortSignal) return AbortSignal.timeout(ms);
  const c = new AbortController();
  setTimeout(() => c.abort(), ms);
  return c.signal;
}

async function request<T>(method: string, path: string, body?: unknown, auth = false): Promise<T> {
  let res: Response;
  try {
    res = await fetch(BASE + path, {
      method,
      headers: {
        'Content-Type': 'application/json',
        ...(auth && instructorToken ? { Authorization: `Bearer ${instructorToken}` } : {}),
      },
      body: body === undefined ? undefined : JSON.stringify(body),
      signal: timeoutSignal(15000),
    });
  } catch {
    throw new ApiError(0, 'network', 'تعذر الاتصال بالخادم. تحقق من الشبكة وحاول مجدداً');
  }
  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    if (auth && res.status === 401) logout(); // انتهت الجلسة أو غير صالحة
    throw new ApiError(res.status, data.code ?? 'error', data.message ?? 'حدث خطأ غير متوقع');
  }
  return data as T;
}

// ---------------------------------------------------------------- الطالب
function newDeviceId(): string {
  if (typeof crypto.randomUUID === 'function') return crypto.randomUUID();
  const b = new Uint8Array(16); // احتياطي للمتصفحات الأقدم (قبل iOS 15.4)
  crypto.getRandomValues(b);
  return Array.from(b, (x) => x.toString(16).padStart(2, '0')).join('');
}

function deviceId(): string {
  try {
    let id = localStorage.getItem('attendance_device_id');
    if (!id) {
      id = newDeviceId();
      localStorage.setItem('attendance_device_id', id);
    }
    return id;
  } catch {
    return 'volatile-' + newDeviceId();
  }
}

function getPosition(): Promise<{ lat: number; lng: number; accuracy: number }> {
  return new Promise((resolve, reject) => {
    if (!navigator.geolocation) return reject(new Error('المتصفح لا يدعم تحديد الموقع'));
    navigator.geolocation.getCurrentPosition(
      (p) => resolve({ lat: p.coords.latitude, lng: p.coords.longitude, accuracy: p.coords.accuracy }),
      (err) =>
        reject(
          new Error(
            err.code === err.PERMISSION_DENIED
              ? 'تم رفض إذن الموقع. فعّله من إعدادات المتصفح ثم أعد المحاولة'
              : 'تعذر تحديد موقعك. تأكد من تشغيل GPS وحاول مجدداً'
          )
        ),
      { enableHighAccuracy: true, timeout: 12000, maximumAge: 0 }
    );
  });
}

/** يلتقط الموقع الحقيقي للجهاز ثم يرسل الطلب. الخادم هو من يقرر القبول. */
export async function scanAttendance(p: {
  lectureId: number;
  universityId: string;
  secretCode: string;
  token: string;
}): Promise<ScanResult> {
  const geo = await getPosition();
  return request<ScanResult>('POST', '/attendance/scan', { ...p, deviceId: deviceId(), geo });
}

// ---------------------------------------------------------------- المحاضر
export async function login(password: string): Promise<void> {
  const r = await request<{ token: string }>('POST', '/auth/login', { password });
  setSession(r.token, { role: 'instructor' });
}

/** دخول المعيد بكود التفويض الذي منحه له المحاضر (يخص محاضرة واحدة ومدة محدودة). */
export async function loginAssistant(accessCode: string): Promise<void> {
  const r = await request<{ token: string; assistantName: string; lectureId: number; expiresAt: number }>(
    'POST', '/auth/assistant-login', { accessCode: accessCode.trim() });
  setSession(r.token, { role: 'assistant', assistantName: r.assistantName, lectureId: r.lectureId, expiresAt: r.expiresAt });
}

export const openSession = (lectureId: number) =>
  request<{ ok: true; alreadyOpen: boolean }>('POST', `/lectures/${lectureId}/session/open`, {}, true);

export const closeSession = (lectureId: number) =>
  request<{ ok: true }>('POST', `/lectures/${lectureId}/session/close`, {}, true);

export const fetchLiveToken = (lectureId: number) =>
  request<LiveToken & { ok: true }>('GET', `/lectures/${lectureId}/token`, undefined, true);

export const fetchRoster = (lectureId: number) =>
  request<{ ok: true; roster: RosterRow[] }>('GET', `/lectures/${lectureId}/roster`, undefined, true);

export const setStudentStatus = (lectureId: number, studentId: number, status: AttendanceStatus, notes = '') =>
  request<{ ok: true }>('PUT', `/lectures/${lectureId}/attendance/${studentId}`, { status, notes }, true);

export const fetchReport = (courseId: number) =>
  request<{ ok: true; totalLectures: number; rows: ReportRow[] }>('GET', `/courses/${courseId}/report`, undefined, true);

export const rotateSecret = (studentId: number) =>
  request<{ ok: true; secretCode: string }>('POST', `/students/${studentId}/secret/rotate`, {}, true);

// ---------------------------------------------------------------- الأعذار
/** تقديم عذر من الطالب (بالرقم الجامعي والكود السري). */
export const submitExcuse = (p: {
  universityId: string;
  secretCode: string;
  lectureId: number;
  reasonText: string;
  documentUrl?: string;
}) => request<{ ok: true; excuse: ServerExcuse }>('POST', '/excuses', p);

/** أعذار الطالب نفسه ليعرف حالتها. */
export const fetchMyExcuses = (p: { universityId: string; secretCode: string }) =>
  request<{ ok: true; excuses: ServerExcuse[] }>('POST', '/excuses/mine', p);

export const fetchExcuses = (status?: ServerExcuseStatus) =>
  request<{ ok: true; excuses: ServerExcuse[] }>('GET', `/excuses${status ? `?status=${status}` : ''}`, undefined, true);

export const reviewExcuse = (excuseId: number, action: 'accept' | 'reject', notes = '') =>
  request<{ ok: true; excuse: ServerExcuse }>('POST', `/excuses/${excuseId}/review`, { action, notes }, true);

// ---------------------------------------------------------------- الإرشاد الأكاديمي
export const fetchAtRisk = (minAbsences = 2, minPct = 20) =>
  request<{ ok: true; students: AtRiskRow[] }>(
    'GET', `/advising/at-risk?minAbsences=${minAbsences}&minPct=${minPct}`, undefined, true);

export const fetchAlerts = () => request<{ ok: true; alerts: ServerAlert[] }>('GET', '/academic-alerts', undefined, true);

export const createAlert = (p: { studentId: number; advisorName?: string; absenceCount: number; notes?: string }) =>
  request<{ ok: true; alert: ServerAlert }>('POST', '/academic-alerts', p, true);

export const updateAlert = (alertId: number, p: { status: AdvisorAlertStatus; notes?: string }) =>
  request<{ ok: true; alert: ServerAlert }>('PUT', `/academic-alerts/${alertId}`, p, true);

export const deleteAlert = (alertId: number) =>
  request<{ ok: true }>('DELETE', `/academic-alerts/${alertId}`, undefined, true);

export const autoGenerateAlerts = () =>
  request<{ ok: true; created: number }>('POST', '/academic-alerts/auto-generate', {}, true);

// ---------------------------------------------------------------- التقييم والنقاط
export const submitFeedback = (p: { feedbackToken: string; score: number }) =>
  request<{ ok: true }>('POST', '/feedback', p);

export const fetchFeedbackStats = (lectureId: number) =>
  request<{ ok: true } & FeedbackStats>('GET', `/lectures/${lectureId}/feedback`, undefined, true);

export const addParticipation = (lectureId: number, studentId: number, reason?: string) =>
  request<{ ok: true; studentName: string; points: number }>(
    'POST', `/lectures/${lectureId}/participation`, { studentId, reason }, true);

// ---------------------------------------------------------------- تفويض المعيد
export const createDelegation = (p: { assistantName: string; lectureId: number; durationMinutes?: number }) =>
  request<{ ok: true; delegation: ServerDelegation; accessCode: string }>('POST', '/delegations', p, true);

export const fetchDelegations = (lectureId?: number) =>
  request<{ ok: true; delegations: ServerDelegation[] }>(
    'GET', `/delegations${lectureId ? `?lectureId=${lectureId}` : ''}`, undefined, true);

export const revokeDelegation = (delegationId: number) =>
  request<{ ok: true; delegation: ServerDelegation }>('POST', `/delegations/${delegationId}/revoke`, {}, true);

export const fetchAssistantLog = (lectureId: number) =>
  request<{ ok: true; logs: AssistantLogEntry[] }>('GET', `/lectures/${lectureId}/assistant-log`, undefined, true);
