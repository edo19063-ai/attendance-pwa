/**
 * تم نقل توليد رموز الحضور والتحقق منها إلى الخادم الآمن (مجلد server/).
 *
 * هذا الملف لم يعد يحتوي أي سر أو خوارزمية: كل ما كان هنا (الملح السري وSHA-256 وتوليد
 * التوكن) كان داخل حزمة المتصفح، أي يستطيع أي شخص قراءته وتزوير الرموز.
 * بقيت الأسماء فقط حتى لا ينكسر الاستيراد في الكود القديم داخل AttendanceContext،
 * وهي دوال معطّلة عمداً. احذف هذا الملف مع الكود القديم عند تنظيف الـ Context.
 */
export const DEFAULT_INTERVAL_SECONDS = 5;

const MOVED = 'تم نقل منطق الرموز إلى الخادم الآمن. استخدم src/services/api.ts';

/** رقم النافذة الزمنية (للعرض فقط، لا قيمة أمنية له). */
export function getTimeWindow(intervalSeconds = DEFAULT_INTERVAL_SECONDS, customTimestampMs?: number): number {
  const ts = customTimestampMs !== undefined ? customTimestampMs / 1000 : Date.now() / 1000;
  return Math.floor(ts / intervalSeconds);
}

export function getSecondsRemainingInWindow(intervalSeconds = DEFAULT_INTERVAL_SECONDS): number {
  const ts = Date.now() / 1000;
  return intervalSeconds - (ts % intervalSeconds);
}

/** معطّلة: التوليد يتم على الخادم فقط. */
export function generateToken(..._args: unknown[]): string {
  throw new Error(MOVED);
}

/** معطّلة: ترفض أي رمز دائماً. التحقق يتم على الخادم فقط. */
export function verifyToken(..._args: unknown[]): { isValid: boolean; windowDiff: number; message: string } {
  return { isValid: false, windowDiff: 999, message: MOVED };
}
