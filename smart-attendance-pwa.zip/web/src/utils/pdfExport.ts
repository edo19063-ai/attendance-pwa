import html2canvas from 'html2canvas';
import { jsPDF } from 'jspdf';

export interface PdfSummaryStat {
  label: string;
  value: string | number;
  accent?: 'blue' | 'emerald' | 'rose' | 'amber' | 'slate';
}

export interface PdfTableColumn {
  header: string;
  align?: 'right' | 'center' | 'left';
  width?: string;
}

export interface PdfTableCell {
  text: string;
  badgeColor?: 'emerald' | 'rose' | 'amber' | 'blue' | 'slate';
  mono?: boolean;
  bold?: boolean;
}

export interface PdfReportConfig {
  filename: string;
  title: string;
  subtitle?: string;
  metaItems?: Array<{ label: string; value: string }>;
  stats?: PdfSummaryStat[];
  columns: PdfTableColumn[];
  rows: PdfTableCell[][];
  footerNote?: string;
}

const escapeHtml = (value: string): string =>
  value
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');

const STAT_COLORS: Record<NonNullable<PdfSummaryStat['accent']>, { bg: string; border: string; text: string }> = {
  blue: { bg: '#eff6ff', border: '#bfdbfe', text: '#1d4ed8' },
  emerald: { bg: '#ecfdf5', border: '#a7f3d0', text: '#047857' },
  rose: { bg: '#fff1f2', border: '#fecdd3', text: '#be123c' },
  amber: { bg: '#fffbeb', border: '#fde68a', text: '#b45309' },
  slate: { bg: '#f8fafc', border: '#e2e8f0', text: '#0f172a' },
};

const BADGE_COLORS: Record<NonNullable<PdfTableCell['badgeColor']>, { bg: string; border: string; text: string }> = {
  emerald: { bg: '#dcfce7', border: '#86efac', text: '#166534' },
  rose: { bg: '#ffe4e6', border: '#fda4af', text: '#9f1239' },
  amber: { bg: '#fef3c7', border: '#fcd34d', text: '#92400e' },
  blue: { bg: '#dbeafe', border: '#93c5fd', text: '#1e40af' },
  slate: { bg: '#f1f5f9', border: '#cbd5e1', text: '#334155' },
};

function buildReportHtml(config: PdfReportConfig): string {
  const generatedAt = new Date().toLocaleString('ar-SA');

  const metaHtml =
    config.metaItems && config.metaItems.length > 0
      ? `<div class="meta-grid">
          ${config.metaItems
            .map(
              (m) =>
                `<div class="meta-item"><span class="meta-label">${escapeHtml(m.label)}:</span> <span class="meta-value">${escapeHtml(m.value)}</span></div>`
            )
            .join('')}
        </div>`
      : '';

  const statsHtml =
    config.stats && config.stats.length > 0
      ? `<div class="stats-grid" style="grid-template-columns: repeat(${Math.min(config.stats.length, 4)}, 1fr);">
          ${config.stats
            .map((st) => {
              const palette = STAT_COLORS[st.accent || 'slate'];
              return `<div class="stat-card" style="background:${palette.bg}; border-color:${palette.border};">
                <div class="stat-label">${escapeHtml(st.label)}</div>
                <div class="stat-value" style="color:${palette.text};">${escapeHtml(String(st.value))}</div>
              </div>`;
            })
            .join('')}
        </div>`
      : '';

  const theadHtml = `<tr>
    ${config.columns
      .map(
        (col) =>
          `<th style="text-align:${col.align || 'right'};${col.width ? `width:${col.width};` : ''}">${escapeHtml(col.header)}</th>`
      )
      .join('')}
  </tr>`;

  const tbodyHtml =
    config.rows.length === 0
      ? `<tr><td colspan="${config.columns.length}" style="text-align:center; padding:24px; color:#64748b;">لا توجد بيانات للعرض في هذا التقرير.</td></tr>`
      : config.rows
          .map(
            (row, rIdx) => `<tr style="background:${rIdx % 2 === 1 ? '#f8fafc' : '#ffffff'};">
              ${row
                .map((cell, cIdx) => {
                  const align = config.columns[cIdx]?.align || 'right';
                  const monoClass = cell.mono ? 'font-family: Consolas, monospace;' : '';
                  const boldClass = cell.bold ? 'font-weight: 700;' : '';
                  if (cell.badgeColor) {
                    const bc = BADGE_COLORS[cell.badgeColor];
                    return `<td style="text-align:${align};">
                      <span class="badge" style="background:${bc.bg}; border-color:${bc.border}; color:${bc.text}; ${monoClass}">${escapeHtml(cell.text)}</span>
                    </td>`;
                  }
                  return `<td style="text-align:${align}; ${monoClass} ${boldClass}">${escapeHtml(cell.text)}</td>`;
                })
                .join('')}
            </tr>`
          )
          .join('');

  return `<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
  <meta charset="UTF-8" />
  <style>
    * { box-sizing: border-box; }
    html, body {
      margin: 0;
      padding: 0;
      background: #ffffff;
      color: #0f172a;
      font-family: 'Cairo', 'Tahoma', 'Arial', sans-serif;
      direction: rtl;
      -webkit-font-smoothing: antialiased;
    }
    .page-wrap {
      width: 794px;
      padding: 28px 30px;
      background: #ffffff;
    }
    .header {
      border-bottom: 3px solid #1d4ed8;
      padding-bottom: 14px;
      margin-bottom: 16px;
      display: flex;
      justify-content: space-between;
      align-items: flex-start;
      gap: 16px;
    }
    .brand {
      font-size: 11px;
      font-weight: 700;
      color: #1d4ed8;
      margin-bottom: 4px;
    }
    .title {
      margin: 0;
      font-size: 20px;
      font-weight: 800;
      color: #0f172a;
    }
    .subtitle {
      margin: 4px 0 0 0;
      font-size: 12px;
      color: #475569;
    }
    .date-box {
      background: #f1f5f9;
      border: 1px solid #cbd5e1;
      border-radius: 8px;
      padding: 6px 10px;
      font-size: 10px;
      color: #334155;
      text-align: left;
      white-space: nowrap;
    }
    .meta-grid {
      display: flex;
      flex-wrap: wrap;
      gap: 8px 18px;
      background: #f8fafc;
      border: 1px solid #e2e8f0;
      border-radius: 10px;
      padding: 10px 14px;
      margin-bottom: 14px;
      font-size: 11px;
    }
    .meta-label { color: #64748b; }
    .meta-value { color: #0f172a; font-weight: 700; }
    .stats-grid {
      display: grid;
      gap: 10px;
      margin-bottom: 16px;
    }
    .stat-card {
      border: 1px solid #e2e8f0;
      border-radius: 10px;
      padding: 10px 12px;
    }
    .stat-label {
      font-size: 10px;
      color: #475569;
      margin-bottom: 4px;
    }
    .stat-value {
      font-size: 17px;
      font-weight: 800;
    }
    table {
      width: 100%;
      border-collapse: collapse;
      border: 1px solid #cbd5e1;
      font-size: 11px;
    }
    th {
      background: #1e293b;
      color: #ffffff;
      font-weight: 700;
      padding: 9px 10px;
      border: 1px solid #334155;
    }
    td {
      padding: 8px 10px;
      border: 1px solid #e2e8f0;
      color: #0f172a;
      vertical-align: middle;
    }
    .badge {
      display: inline-block;
      padding: 2px 8px;
      border-radius: 999px;
      border: 1px solid transparent;
      font-size: 10px;
      font-weight: 700;
    }
    .footer {
      margin-top: 16px;
      padding-top: 10px;
      border-top: 1px solid #e2e8f0;
      display: flex;
      justify-content: space-between;
      font-size: 10px;
      color: #64748b;
    }
  </style>
</head>
<body>
  <div class="page-wrap">
    <div class="header">
      <div>
        <div class="brand">منظومة الحضور والغياب الذكية · التقرير الرسمي</div>
        <h1 class="title">${escapeHtml(config.title)}</h1>
        ${config.subtitle ? `<p class="subtitle">${escapeHtml(config.subtitle)}</p>` : ''}
      </div>
      <div class="date-box">
        تاريخ الإصدار:<br />
        <strong>${escapeHtml(generatedAt)}</strong>
      </div>
    </div>

    ${metaHtml}
    ${statsHtml}

    <table>
      <thead>${theadHtml}</thead>
      <tbody>${tbodyHtml}</tbody>
    </table>

    <div class="footer">
      <span>${escapeHtml(config.footerNote || 'تم توليد هذا المستند آلياً من نظام الحضور الذكي')}</span>
      <span>Smart Student Attendance System</span>
    </div>
  </div>
</body>
</html>`;
}

export async function exportReportToPdf(config: PdfReportConfig): Promise<void> {
  const html = buildReportHtml(config);

  const iframe = document.createElement('iframe');
  iframe.style.position = 'fixed';
  iframe.style.left = '-10000px';
  iframe.style.top = '0';
  iframe.style.width = '794px';
  iframe.style.height = '1123px';
  iframe.style.border = '0';
  iframe.style.visibility = 'hidden';
  document.body.appendChild(iframe);

  try {
    const iframeDoc = iframe.contentDocument || iframe.contentWindow?.document;
    if (!iframeDoc) {
      throw new Error('تعذر تهيئة مستند PDF');
    }

    iframeDoc.open();
    iframeDoc.write(html);
    iframeDoc.close();

    // Wait briefly for layout & fonts inside the isolated iframe
    await new Promise((resolve) => setTimeout(resolve, 180));

    const targetEl = iframeDoc.querySelector('.page-wrap') as HTMLElement | null;
    if (!targetEl) {
      throw new Error('تعذر العثور على محتوى التقرير');
    }

    const canvas = await html2canvas(targetEl, {
      scale: 2,
      backgroundColor: '#ffffff',
      useCORS: true,
      logging: false,
      windowWidth: 794,
    });

    const imgData = canvas.toDataURL('image/png');
    const pdf = new jsPDF({
      orientation: 'portrait',
      unit: 'mm',
      format: 'a4',
    });

    const pageWidth = pdf.internal.pageSize.getWidth();
    const pageHeight = pdf.internal.pageSize.getHeight();
    const imgWidth = pageWidth;
    const imgHeight = (canvas.height * imgWidth) / canvas.width;

    let heightLeft = imgHeight;
    let position = 0;

    pdf.addImage(imgData, 'PNG', 0, position, imgWidth, imgHeight);
    heightLeft -= pageHeight;

    while (heightLeft > 2) {
      position = heightLeft - imgHeight;
      pdf.addPage();
      pdf.addImage(imgData, 'PNG', 0, position, imgWidth, imgHeight);
      heightLeft -= pageHeight;
    }

    const safeFilename = config.filename.endsWith('.pdf') ? config.filename : `${config.filename}.pdf`;
    pdf.save(safeFilename);
  } finally {
    document.body.removeChild(iframe);
  }
}
