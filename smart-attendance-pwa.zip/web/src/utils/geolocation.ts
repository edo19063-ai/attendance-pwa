/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface GeoCoordinates {
  latitude: number;
  longitude: number;
  accuracy?: number;
  timestamp?: number;
}

export interface GeofenceConfig {
  hallLat: number;
  hallLng: number;
  hallName: string;
  allowedRadiusMeters: number;
}

// إحداثيات قاعة المحاضرات الافتراضية
export const DEFAULT_GEOFENCE_CONFIG: GeofenceConfig = {
  hallLat: 32.123456,
  hallLng: 20.123456,
  hallName: 'القاعة A1 (كلية إدارة الأعمال والتقنية)',
  allowedRadiusMeters: 30, // 30 متراً كحد أقصى للتحقق من التواجد الفعلي داخل القاعة
};

/**
 * حساب المسافة بين نقطتين جغرافيتين بالمتر باستخدام معادلة Haversine
 * مطابق تماماً للصيغة المحددة في متطلبات النظام
 */
export function calculateDistance(
  lat1: number,
  lon1: number,
  lat2: number,
  lon2: number
): number {
  const R = 6371e3; // نصف قطر الأرض بالمتر
  const φ1 = (lat1 * Math.PI) / 180;
  const φ2 = (lat2 * Math.PI) / 180;
  const Δφ = ((lat2 - lat1) * Math.PI) / 180;
  const Δλ = ((lon2 - lon1) * Math.PI) / 180;

  const a =
    Math.sin(Δφ / 2) * Math.sin(Δφ / 2) +
    Math.cos(φ1) * Math.cos(φ2) * Math.sin(Δλ / 2) * Math.sin(Δλ / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));

  return Math.round(R * c * 10) / 10; // المسافة بالمتر مقربة لمنزلة واحدة
}

/**
 * التحقق مما إذا كانت إحداثيات الطالب تقع داخل النطاق المسموح للقاعة
 */
export function verifyGeofence(
  studentCoords: GeoCoordinates,
  config: GeofenceConfig = DEFAULT_GEOFENCE_CONFIG
): {
  isWithin: boolean;
  distanceMeters: number;
  allowedRadiusMeters: number;
  message: string;
} {
  const distance = calculateDistance(
    config.hallLat,
    config.hallLng,
    studentCoords.latitude,
    studentCoords.longitude
  );

  const isWithin = distance <= config.allowedRadiusMeters;

  return {
    isWithin,
    distanceMeters: distance,
    allowedRadiusMeters: config.allowedRadiusMeters,
    message: isWithin
      ? `✅ أنت داخل القاعة! (المسافة: ${distance}م من أصل ${config.allowedRadiusMeters}م)`
      : `❌ خارج نطاق القاعة! (المسافة: ${distance}م - المسموح به: ${config.allowedRadiusMeters}م)`,
  };
}

/**
 * جلب إحداثيات الطالب الحقيقية من المتصفح باستخدام navigator.geolocation
 */
export function getCurrentStudentPosition(): Promise<GeoCoordinates> {
  return new Promise((resolve, reject) => {
    if (!navigator.geolocation) {
      reject(new Error('متصفحك لا يدعم خاصية تحديد الموقع (Geolocation).'));
      return;
    }

    navigator.geolocation.getCurrentPosition(
      (position) => {
        resolve({
          latitude: position.coords.latitude,
          longitude: position.coords.longitude,
        });
      },
      (error) => {
        let msg = 'تعذر تحديد موقعك الحالي.';
        if (error.code === error.PERMISSION_DENIED) {
          msg = 'يرجى تفعيل خدمة تحديد الموقع (GPS) ومنح الإذن لتسجيل الحضور.';
        } else if (error.code === error.POSITION_UNAVAILABLE) {
          msg = 'إشارة الـ GPS غير متوفرة حالياً.';
        } else if (error.code === error.TIMEOUT) {
          msg = 'انتهت مهلة طلب تحديد الموقع.';
        }
        reject(new Error(msg));
      },
      {
        enableHighAccuracy: true,
        timeout: 10000,
        maximumAge: 0,
      }
    );
  });
}
