import {createRoot} from 'react-dom/client';
import App from './App.tsx';
import './index.css';

createRoot(document.getElementById('root')!).render(<App />);

// تسجيل Service Worker في النسخة المنشورة فقط (يجعل التطبيق قابلاً للتثبيت).
// لا يخزّن طلبات /api إطلاقاً: الرموز والبيانات الحساسة تأتي من الشبكة دائماً.
// داخل تطبيق الجوال (Capacitor) لا حاجة له: الملفات مضمّنة في التطبيق نفسه.
const isNativeApp = Boolean((window as unknown as { Capacitor?: { isNativePlatform?: () => boolean } }).Capacitor?.isNativePlatform?.());
if ('serviceWorker' in navigator && import.meta.env.PROD && !isNativeApp) {
  window.addEventListener('load', () => {
    navigator.serviceWorker.register('/sw.js').catch(() => {
      /* التثبيت اختياري؛ التطبيق يعمل بدونه */
    });
  });
}
