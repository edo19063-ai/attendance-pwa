import React, { useState } from 'react';
import {
  Database,
  Code2,
  Copy,
  Check,
  Table,
  Key,
  Layers,
  FileText,
  Monitor,
  Sparkles,
  MapPin,
  Award,
} from 'lucide-react';

type StudioTab =
  | 'schema'
  | 'code-sql'
  | 'code-sqlalchemy'
  | 'code-python'
  | 'code-js-offline'
  | 'code-html-academic'
  | 'code-html-geo'
  | 'code-html-v2'
  | 'code-html-dashboard'
  | 'code-html-screen';

export const DatabaseCodeStudioView: React.FC = () => {
  const [activeTab, setActiveTab] = useState<StudioTab>('schema');
  const [copiedKey, setCopiedKey] = useState<string | null>(null);

  const handleCopy = (key: string, content: string) => {
    navigator.clipboard?.writeText(content).catch(() => {});
    setCopiedKey(key);
    setTimeout(() => {
      setCopiedKey(null);
    }, 2000);
  };

  const schemaTables = [
    {
      name: 'Departments',
      arabicName: 'الأقسام والتخصصات',
      columns: [
        { name: 'department_id', type: 'INT', isPk: true, desc: 'المفتاح الأساسي (تلقائي)' },
        { name: 'department_name', type: 'VARCHAR(100)', isUnique: true, desc: 'اسم القسم أو التخصص (فريد)' },
      ],
    },
    {
      name: 'Students',
      arabicName: 'بيانات الطلاب',
      columns: [
        { name: 'student_id', type: 'INT', isPk: true, desc: 'المعرف الفريد للطالب' },
        { name: 'full_name', type: 'VARCHAR(150)', desc: 'الاسم الثلاثي أو الرباعي' },
        { name: 'university_id', type: 'VARCHAR(50)', isUnique: true, desc: 'الرقم الجامعي الفريد للطالب' },
        { name: 'email', type: 'VARCHAR(100)', isUnique: true, desc: 'البريد الإلكتروني الجامعي' },
        { name: 'photo_url', type: 'VARCHAR(255)', desc: 'رابط الصورة الشخصية الموثقة للطالب' },
        { name: 'secret_code', type: 'VARCHAR(10)', isUnique: true, desc: 'الكود السري الفريد الخاص بكل طالب' },
        { name: 'department_id', type: 'INT', isFk: true, desc: 'مفتاح أجنبي -> Departments' },
      ],
    },
    {
      name: 'Courses',
      arabicName: 'المقررات الدراسية',
      columns: [
        { name: 'course_id', type: 'INT', isPk: true, desc: 'المعرف الفريد للمقرر' },
        { name: 'course_name', type: 'VARCHAR(100)', desc: 'اسم المادة أو المقرر' },
        { name: 'course_code', type: 'VARCHAR(50)', isUnique: true, desc: 'رمز المقرر (مثل: CS201)' },
        { name: 'instructor_name', type: 'VARCHAR(100)', desc: 'اسم المحاضر / أستاذ المادة' },
      ],
    },
    {
      name: 'Course_Enrollments',
      arabicName: 'تسجيل الطلاب في المواد',
      columns: [
        { name: 'enrollment_id', type: 'INT', isPk: true, desc: 'معرف التسجيل' },
        { name: 'student_id', type: 'INT', isFk: true, desc: 'مفتاح أجنبي -> Students' },
        { name: 'course_id', type: 'INT', isFk: true, desc: 'مفتاح أجنبي -> Courses' },
        { name: 'semester', type: 'VARCHAR(20)', desc: 'الفصل الدراسي (مثل: Fall 2024)' },
      ],
      constraints: ['UNIQUE (student_id, course_id, semester)'],
    },
    {
      name: 'Lectures',
      arabicName: 'المحاضرات والحصص',
      columns: [
        { name: 'lecture_id', type: 'INT', isPk: true, desc: 'معرف المحاضرة' },
        { name: 'course_id', type: 'INT', isFk: true, desc: 'مفتاح أجنبي -> Courses' },
        { name: 'lecture_date', type: 'DATE', desc: 'تاريخ انعقاد المحاضرة (YYYY-MM-DD)' },
        { name: 'lecture_time', type: 'TIME', desc: 'وقت بدء المحاضرة' },
        { name: 'topic', type: 'VARCHAR(200)', desc: 'عنوان وموضوع المحاضرة' },
      ],
    },
    {
      name: 'Attendance',
      arabicName: 'سجل الحضور والغياب (المحور)',
      columns: [
        { name: 'attendance_id', type: 'INT', isPk: true, desc: 'معرف سجل الحضور' },
        { name: 'lecture_id', type: 'INT', isFk: true, desc: 'مفتاح أجنبي -> Lectures' },
        { name: 'student_id', type: 'INT', isFk: true, desc: 'مفتاح أجنبي -> Students' },
        { name: 'status', type: 'ENUM / VARCHAR(20)', desc: "حالة الحضور: ('Present', 'Absent', 'Late', 'Excused') أو ('حاضر', 'متأخر', 'غائب')" },
        { name: 'gps_verified', type: 'BOOLEAN', desc: 'حالة التحقق الجغرافي من القاعة (True / False)' },
        { name: 'notes', type: 'VARCHAR(255)', desc: 'ملاحظات أو المسافة بالمتر' },
        { name: 'recorded_at', type: 'TIMESTAMP', desc: 'وقت توثيق العملية الفعلي' },
      ],
      constraints: ['UNIQUE (lecture_id, student_id) -- يمنع تكرار التحضير'],
    },
    {
      name: 'Attendance_Excuses',
      arabicName: 'الأعذار الإلكترونية للطلاب',
      columns: [
        { name: 'excuse_id', type: 'INT', isPk: true, desc: 'المعرف الفريد للعذر' },
        { name: 'student_id', type: 'INT', isFk: true, desc: 'مفتاح أجنبي -> Students' },
        { name: 'lecture_id', type: 'INT', isFk: true, desc: 'مفتاح أجنبي -> Lectures' },
        { name: 'reason_text', type: 'TEXT', desc: 'نص سبب الغياب أو العذر' },
        { name: 'document_url', type: 'VARCHAR(255)', desc: 'رابط التقرير الطبي أو الوثيقة الثبوتية (اختياري)' },
        { name: 'status', type: 'VARCHAR(20)', desc: "حالة العذر: ('قيد المراجعة'، 'مقبول'، 'مرفوض')" },
        { name: 'submitted_at', type: 'TIMESTAMP', desc: 'وقت تقديم العذر' },
        { name: 'review_notes', type: 'VARCHAR(255)', desc: 'ملاحظات أستاذ المقرر عند المراجعة' },
      ],
      constraints: [
        'FOREIGN KEY (student_id) REFERENCES Students(student_id) ON DELETE CASCADE',
        'FOREIGN KEY (lecture_id) REFERENCES Lectures(lecture_id) ON DELETE CASCADE',
      ],
    },
    {
      name: 'Assistant_Audit_Logs',
      arabicName: 'سجل تدقيق وأمان عمليات المعيدين (TA Proxy Audit)',
      columns: [
        { name: 'log_id', type: 'INT', isPk: true, desc: 'معرف عملية التدقيق' },
        { name: 'lecture_id', type: 'INT', isFk: true, desc: 'مفتاح أجنبي -> Lectures' },
        { name: 'assistant_name', type: 'VARCHAR(100)', desc: 'اسم المعيد المفوض' },
        { name: 'action_performed', type: 'VARCHAR(255)', desc: 'الإجراء المعتمد (تفعيل باركود، تحضير، إغلاق)' },
        { name: 'ip_address', type: 'VARCHAR(45)', desc: 'عنوان بروتوكول الإنترنت للمنفذ' },
        { name: 'status', type: 'VARCHAR(20)', desc: "حالة الإجراء: ('نجاح'، 'تحذير'، 'فشل')" },
        { name: 'timestamp', type: 'TIMESTAMP', desc: 'وقت تنفيذ وتوثيق الإجراء بدقة' },
      ],
      constraints: ['FOREIGN KEY (lecture_id) REFERENCES Lectures(lecture_id) ON DELETE CASCADE'],
    },
    {
      name: 'Lecture_Feedbacks',
      arabicName: 'تقييمات واستيعاب المحاضرة (Live Lecture Pulse)',
      columns: [
        { name: 'feedback_id', type: 'INT', isPk: true, desc: 'معرف التقييم الفريد' },
        { name: 'lecture_id', type: 'INT', isFk: true, desc: 'مفتاح أجنبي -> Lectures' },
        { name: 'student_id', type: 'INT', isFk: true, desc: 'مفتاح أجنبي -> Students' },
        { name: 'understanding_score', type: 'INT', desc: 'درجة استيعاب الطالب للمحاضرة (1 إلى 10)' },
        { name: 'timestamp', type: 'TIMESTAMP', desc: 'وقت إرسال التقييم' },
      ],
      constraints: [
        'FOREIGN KEY (lecture_id) REFERENCES Lectures(lecture_id) ON DELETE CASCADE',
        'FOREIGN KEY (student_id) REFERENCES Students(student_id) ON DELETE CASCADE',
      ],
    },
    {
      name: 'Student_Participations',
      arabicName: 'نقاط التميز والمشاركة والتفاعل (Gamification & Participation)',
      columns: [
        { name: 'participation_id', type: 'INT', isPk: true, desc: 'معرف نقطة المشاركة' },
        { name: 'student_id', type: 'INT', isFk: true, desc: 'مفتاح أجنبي -> Students' },
        { name: 'course_id', type: 'INT', isFk: true, desc: 'مفتاح أجنبي -> Courses' },
        { name: 'points_added', type: 'INT', desc: 'عدد النقاط المضافة (افتراضياً: 1)' },
        { name: 'reason', type: 'VARCHAR(255)', desc: 'سبب منح النقطة (مشاركة، إجابة متميزة، مناقشة)' },
        { name: 'timestamp', type: 'TIMESTAMP', desc: 'توقيت منح النقطة' },
      ],
      constraints: [
        'FOREIGN KEY (student_id) REFERENCES Students(student_id) ON DELETE CASCADE',
        'FOREIGN KEY (course_id) REFERENCES Courses(course_id) ON DELETE CASCADE',
      ],
    },
    {
      name: 'Academic_Advisor_Alerts',
      arabicName: 'تنبيهات الإرشاد الأكاديمي والإنذار المبكر (Academic Advisor Alerts)',
      columns: [
        { name: 'alert_id', type: 'INT', isPk: true, desc: 'المعرف الفريد لتنبيه الإرشاد الأكاديمي' },
        { name: 'student_id', type: 'INT', isFk: true, desc: 'مفتاح أجنبي -> Students' },
        { name: 'advisor_name', type: 'VARCHAR(100)', desc: 'اسم المرشد المختص' },
        { name: 'absence_count', type: 'INT', desc: 'عدد غيابات الطالب الحالية' },
        { name: 'status', type: 'VARCHAR(50)', desc: "حالة التنبيه ('قيد المتابعة' / 'تم التدخل')" },
        { name: 'timestamp', type: 'TIMESTAMP', desc: 'توقيت وتاريخ إصدار التنبيه الأكاديمي' },
      ],
      constraints: ['FOREIGN KEY (student_id) REFERENCES Students(student_id) ON DELETE CASCADE'],
    },
  ];

  const codeFiles: Record<string, { filename: string; language: string; content: string }> = {
    'code-sql': {
      filename: 'schema.sql',
      language: 'sql',
      content: `-- إنشاء قاعدة البيانات وتحديدها
CREATE DATABASE IF NOT EXISTS attendance_system CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE attendance_system;

-- 1. جدول الأقسام
CREATE TABLE IF NOT EXISTS Departments (
    department_id INT PRIMARY KEY AUTO_INCREMENT,
    department_name VARCHAR(100) NOT NULL UNIQUE
);

-- 2. جدول الطلاب
CREATE TABLE IF NOT EXISTS Students (
    student_id INT PRIMARY KEY AUTO_INCREMENT,
    full_name VARCHAR(150) NOT NULL,
    university_id VARCHAR(50) NOT NULL UNIQUE,
    email VARCHAR(100) UNIQUE,
    photo_url VARCHAR(255),
    secret_code VARCHAR(10) NOT NULL UNIQUE,
    department_id INT,
    FOREIGN KEY (department_id) REFERENCES Departments(department_id) ON DELETE SET NULL ON UPDATE CASCADE
);

-- 3. جدول المقررات
CREATE TABLE IF NOT EXISTS Courses (
    course_id INT PRIMARY KEY AUTO_INCREMENT,
    course_name VARCHAR(100) NOT NULL,
    course_code VARCHAR(50) NOT NULL UNIQUE,
    instructor_name VARCHAR(100) NOT NULL
);

-- 4. جدول تسجيل الطلاب في المقررات
CREATE TABLE IF NOT EXISTS Course_Enrollments (
    enrollment_id INT PRIMARY KEY AUTO_INCREMENT,
    student_id INT NOT NULL,
    course_id INT NOT NULL,
    semester VARCHAR(20) NOT NULL,
    FOREIGN KEY (student_id) REFERENCES Students(student_id) ON DELETE CASCADE,
    FOREIGN KEY (course_id) REFERENCES Courses(course_id) ON DELETE CASCADE,
    UNIQUE (student_id, course_id, semester)
);

-- 5. جدول المحاضرات
CREATE TABLE IF NOT EXISTS Lectures (
    lecture_id INT PRIMARY KEY AUTO_INCREMENT,
    course_id INT NOT NULL,
    lecture_date DATE NOT NULL,
    lecture_time TIME NOT NULL,
    topic VARCHAR(200),
    FOREIGN KEY (course_id) REFERENCES Courses(course_id) ON DELETE CASCADE ON UPDATE CASCADE
);

-- 6. جدول الحضور والغياب (مع قيد منع التكرار والتحقق الجغرافي)
CREATE TABLE IF NOT EXISTS Attendance (
    attendance_id INT PRIMARY KEY AUTO_INCREMENT,
    lecture_id INT NOT NULL,
    student_id INT NOT NULL,
    status ENUM('Present', 'Absent', 'Late', 'Excused') DEFAULT 'Absent',
    gps_verified BOOLEAN DEFAULT FALSE,
    notes VARCHAR(255),
    recorded_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (lecture_id) REFERENCES Lectures(lecture_id) ON DELETE CASCADE,
    FOREIGN KEY (student_id) REFERENCES Students(student_id) ON DELETE CASCADE,
    UNIQUE (lecture_id, student_id)
);

-- 7. جدول الأعذار الإلكترونية للطلاب
CREATE TABLE IF NOT EXISTS Attendance_Excuses (
    excuse_id INT PRIMARY KEY AUTO_INCREMENT,
    student_id INT NOT NULL,
    lecture_id INT NOT NULL,
    reason_text TEXT NOT NULL,
    document_url VARCHAR(255),
    status ENUM('قيد المراجعة', 'مقبول', 'مرفوض') DEFAULT 'قيد المراجعة',
    review_notes VARCHAR(255),
    submitted_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (student_id) REFERENCES Students(student_id) ON DELETE CASCADE,
    FOREIGN KEY (lecture_id) REFERENCES Lectures(lecture_id) ON DELETE CASCADE
);

-- 8. جدول سجل تدقيق وأمان عمليات المعيدين (Audit Log)
CREATE TABLE IF NOT EXISTS Assistant_Audit_Logs (
    log_id INT PRIMARY KEY AUTO_INCREMENT,
    lecture_id INT NOT NULL,
    assistant_name VARCHAR(100) NOT NULL,
    action_performed VARCHAR(255) NOT NULL,
    ip_address VARCHAR(45),
    status ENUM('نجاح', 'تحذير', 'فشل') DEFAULT 'نجاح',
    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (lecture_id) REFERENCES Lectures(lecture_id) ON DELETE CASCADE
);

-- 9. جدول تقييم المحاضرة ودرجة الاستيعاب (Live Feedback)
CREATE TABLE IF NOT EXISTS Lecture_Feedbacks (
    feedback_id INT PRIMARY KEY AUTO_INCREMENT,
    lecture_id INT NOT NULL,
    student_id INT NOT NULL,
    understanding_score INT NOT NULL CHECK (understanding_score BETWEEN 1 AND 10),
    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (lecture_id) REFERENCES Lectures(lecture_id) ON DELETE CASCADE,
    FOREIGN KEY (student_id) REFERENCES Students(student_id) ON DELETE CASCADE
);

-- 10. جدول نقاط التميز والمشاركة والتفاعل للطالب (Participation Points)
CREATE TABLE IF NOT EXISTS Student_Participations (
    participation_id INT PRIMARY KEY AUTO_INCREMENT,
    student_id INT NOT NULL,
    course_id INT NOT NULL,
    points_added INT DEFAULT 1,
    reason VARCHAR(255) NOT NULL,
    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (student_id) REFERENCES Students(student_id) ON DELETE CASCADE,
    FOREIGN KEY (course_id) REFERENCES Courses(course_id) ON DELETE CASCADE
);

-- 11. جدول تنبيهات الإرشاد الأكاديمي والإنذار المبكر (Academic Advisor Alerts)
CREATE TABLE IF NOT EXISTS Academic_Advisor_Alerts (
    alert_id INT PRIMARY KEY AUTO_INCREMENT,
    student_id INT NOT NULL,
    advisor_name VARCHAR(100) NOT NULL,
    absence_count INT NOT NULL,
    status VARCHAR(50) DEFAULT 'قيد المتابعة',
    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (student_id) REFERENCES Students(student_id) ON DELETE CASCADE
);`,
    },
    'code-sqlalchemy': {
      filename: 'models.py',
      language: 'python',
      content: `"""
نظام الحضور والغياب الذكي - نماذج Flask-SQLAlchemy وقاعدة بيانات SQLite
Smart Student Attendance System - SQLAlchemy Models & Geofencing API
"""
from flask import Flask, jsonify, request
from flask_sqlalchemy import SQLAlchemy
from datetime import datetime
import math
import random
import string

app = Flask(__name__)
# إعداد الاتصال بقاعدة بيانات SQLite المحلية
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///attendance_system.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db = SQLAlchemy(app)

def generate_secret_code(length=6):
    chars = string.ascii_uppercase + string.digits
    return ''.join(random.choices(chars, k=length))

# 1. جدول الطلاب (Students)
class Student(db.Model):
    __tablename__ = 'students'
    student_id = db.Column(db.Integer, primary_key=True)
    full_name = db.Column(db.String(100), nullable=False)
    university_id = db.Column(db.String(50), unique=True, nullable=False)
    department = db.Column(db.String(100), nullable=False)
    photo_url = db.Column(db.String(255), nullable=True)  # رابط أو مسار صورة الطالب
    secret_code = db.Column(db.String(10), unique=True, nullable=False, default=generate_secret_code)  # الكود الخاص بكل طالب
    
    # علاقة مع سجلات الحضور والأعذار
    attendances = db.relationship('AttendanceRecord', backref='student', lazy=True)
    excuses = db.relationship('AttendanceExcuse', backref='student', lazy=True)

    def to_dict(self):
        return {
            'student_id': self.student_id,
            'full_name': self.full_name,
            'university_id': self.university_id,
            'department': self.department,
            'photo_url': self.photo_url or 'https://cdn-icons-png.flaticon.com/512/149/149071.png',
            'secret_code': self.secret_code
        }

# 2. جدول المقررات / المواد (Courses)
class Course(db.Model):
    __tablename__ = 'courses'
    course_id = db.Column(db.Integer, primary_key=True)
    course_name = db.Column(db.String(100), nullable=False)
    professor_name = db.Column(db.String(100), nullable=False)
    
    # علاقة مع المحاضرات
    lectures = db.relationship('Lecture', backref='course', lazy=True)

# 3. جدول المحاضرات أو الحصص (Lectures)
class Lecture(db.Model):
    __tablename__ = 'lectures'
    lecture_id = db.Column(db.Integer, primary_key=True)
    course_id = db.Column(db.Integer, db.ForeignKey('courses.course_id'), nullable=False)
    lecture_time = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)
    hall_name = db.Column(db.String(100), default='القاعة A1', nullable=False)
    hall_lat = db.Column(db.Float, default=32.123456, nullable=False)
    hall_lng = db.Column(db.Float, default=20.123456, nullable=False)
    allowed_radius_meters = db.Column(db.Integer, default=30, nullable=False)
    
    # علاقة مع سجلات الحضور والأعذار
    attendances = db.relationship('AttendanceRecord', backref='lecture', lazy=True)
    excuses = db.relationship('AttendanceExcuse', backref='lecture', lazy=True)

# 4. جدول سجل الحضور والغياب (Attendance Records) - الجدول المكمل
class AttendanceRecord(db.Model):
    __tablename__ = 'attendance_records'
    attendance_id = db.Column(db.Integer, primary_key=True)
    lecture_id = db.Column(db.Integer, db.ForeignKey('lectures.lecture_id'), nullable=False)
    student_id = db.Column(db.Integer, db.ForeignKey('students.student_id'), nullable=False)
    scan_timestamp = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)
    status = db.Column(db.String(20), default='حاضر', nullable=False)  # (حاضر، متأخر، غائب، Excused)
    gps_verified = db.Column(db.Boolean, default=False, nullable=False) # حالة التحقق الجغرافي
    distance_meters = db.Column(db.Float, nullable=True) # المسافة المحسوبة من القاعة بالمتر

# 5. جدول الأعذار الإلكترونية (Attendance Excuses)
class AttendanceExcuse(db.Model):
    __tablename__ = 'attendance_excuses'
    excuse_id = db.Column(db.Integer, primary_key=True)
    student_id = db.Column(db.Integer, db.ForeignKey('students.student_id'), nullable=False)
    lecture_id = db.Column(db.Integer, db.ForeignKey('lectures.lecture_id'), nullable=False)
    reason_text = db.Column(db.Text, nullable=False)
    document_url = db.Column(db.String(255), nullable=True)
    status = db.Column(db.String(20), default='قيد المراجعة', nullable=False)  # ('قيد المراجعة', 'مقبول', 'مرفوض')
    submitted_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)
    review_notes = db.Column(db.String(255), nullable=True)

    def to_dict(self):
        return {
            'excuse_id': self.excuse_id,
            'student_id': self.student_id,
            'lecture_id': self.lecture_id,
            'reason_text': self.reason_text,
            'document_url': self.document_url,
            'status': self.status,
            'submitted_at': self.submitted_at.isoformat(),
            'review_notes': self.review_notes
        }

# 6. جدول سجل التدقيق لعمليات المعيدين والمساعدين (Assistant Audit Logs)
class AssistantAuditLog(db.Model):
    __tablename__ = 'assistant_audit_logs'
    log_id = db.Column(db.Integer, primary_key=True)
    lecture_id = db.Column(db.Integer, db.ForeignKey('lectures.lecture_id'), nullable=False)
    assistant_name = db.Column(db.String(100), nullable=False)
    action_performed = db.Column(db.String(255), nullable=False)
    ip_address = db.Column(db.String(45), nullable=True)
    status = db.Column(db.String(20), default='نجاح', nullable=False)
    timestamp = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)

    def to_dict(self):
        return {
            'log_id': self.log_id,
            'lecture_id': self.lecture_id,
            'assistant_name': self.assistant_name,
            'action_performed': self.action_performed,
            'ip_address': self.ip_address,
            'status': self.status,
            'timestamp': self.timestamp.isoformat()
        }

# 7. جدول تقييم استيعاب المحاضرة (Lecture Feedback)
class LectureFeedback(db.Model):
    __tablename__ = 'lecture_feedbacks'
    feedback_id = db.Column(db.Integer, primary_key=True)
    lecture_id = db.Column(db.Integer, db.ForeignKey('lectures.lecture_id'), nullable=False)
    student_id = db.Column(db.Integer, db.ForeignKey('students.student_id'), nullable=False)
    understanding_score = db.Column(db.Integer, nullable=False) # من 1 إلى 10
    timestamp = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)

    def to_dict(self):
        return {
            'feedback_id': self.feedback_id,
            'lecture_id': self.lecture_id,
            'student_id': self.student_id,
            'understanding_score': self.understanding_score,
            'timestamp': self.timestamp.isoformat()
        }

# 8. جدول نقاط التميز والمشاركة والتفاعل (Student Participation Points)
class StudentParticipation(db.Model):
    __tablename__ = 'student_participations'
    participation_id = db.Column(db.Integer, primary_key=True)
    student_id = db.Column(db.Integer, db.ForeignKey('students.student_id'), nullable=False)
    course_id = db.Column(db.Integer, db.ForeignKey('courses.course_id'), nullable=False)
    points_added = db.Column(db.Integer, default=1, nullable=False)
    reason = db.Column(db.String(255), nullable=False)
    timestamp = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)

    def to_dict(self):
        return {
            'participation_id': self.participation_id,
            'student_id': self.student_id,
            'course_id': self.course_id,
            'points_added': self.points_added,
            'reason': self.reason,
            'timestamp': self.timestamp.isoformat()
        }

# 9. جدول تنبيهات الإرشاد الأكاديمي والإنذار المبكر (Academic Advisor Alerts)
class AcademicAdvisorAlert(db.Model):
    __tablename__ = 'academic_advisor_alerts'
    alert_id = db.Column(db.Integer, primary_key=True)
    student_id = db.Column(db.Integer, db.ForeignKey('students.student_id'), nullable=False)
    advisor_name = db.Column(db.String(100), nullable=False)  # اسم المرشد المختص
    absence_count = db.Column(db.Integer, nullable=False)     # عدد غيابات الطالب الحالية
    status = db.Column(db.String(50), default='قيد المتابعة')  # حالة التنبيه (قيد المتابعة / تم التدخل)
    timestamp = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)

    def to_dict(self):
        return {
            'alert_id': self.alert_id,
            'student_id': self.student_id,
            'advisor_name': self.advisor_name,
            'absence_count': self.absence_count,
            'status': self.status,
            'timestamp': self.timestamp.isoformat()
        }

# دالة حساب المسافة بمعادلة Haversine بالمتر
def calculate_distance(lat1, lon1, lat2, lon2):
    R = 6371000  # نصف قطر الأرض بالمتر
    phi1 = math.radians(lat1)
    phi2 = math.radians(lat2)
    delta_phi = math.radians(lat2 - lat1)
    delta_lambda = math.radians(lon2 - lon1)

    a = math.sin(delta_phi / 2)**2 + math.cos(phi1) * math.cos(phi2) * math.sin(delta_lambda / 2)**2
    c = 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a))
    return round(R * c)

# مسار تسجيل الحضور والتحقق الجغرافي (GPS Geofencing)
@app.route('/api/record-attendance', methods=['POST'])
def record_attendance():
    data = request.get_json() or {}
    university_id = data.get('university_id')
    lecture_id = data.get('lecture_id')
    student_lat = data.get('latitude')
    student_lng = data.get('longitude')
    
    student = Student.query.filter_by(university_id=university_id).first()
    if not student:
        return jsonify({'success': False, 'message': 'الرقم الجامعي غير مسجل'}), 404
        
    lecture = Lecture.query.get(lecture_id)
    if not lecture:
        return jsonify({'success': False, 'message': 'المحاضرة غير موجودة'}), 404
        
    # فحص المسافة الجغرافية وقيد الـ 30 متراً
    distance = None
    is_gps_verified = False
    if student_lat is not None and student_lng is not None:
        distance = calculate_distance(lecture.hall_lat, lecture.hall_lng, student_lat, student_lng)
        is_gps_verified = (distance <= lecture.allowed_radius_meters)
        
        if not is_gps_verified:
            return jsonify({
                'success': False,
                'message': f'فشل التسجيل: أنت خارج قاعة المحاضرة! (المسافة: {distance}م - المسموح به: {lecture.allowed_radius_meters}م)',
                'distance': distance,
                'gps_verified': False
            }), 403

    # إضافة سجل الحضور في قاعدة البيانات
    record = AttendanceRecord(
        lecture_id=lecture.lecture_id,
        student_id=student.student_id,
        status='حاضر',
        gps_verified=is_gps_verified,
        distance_meters=distance
    )
    db.session.add(record)
    db.session.commit()
    
    return jsonify({
        'success': True,
        'message': f'تم تسجيل حضور {student.full_name} بنجاح!',
        'distance': distance,
        'gps_verified': is_gps_verified
    })

# 1. مسار تقديم عذر إلكتروني جديد من قبل الطالب
@app.route('/api/submit-excuse', methods=['POST'])
def submit_excuse():
    data = request.json or {}
    student_id = data.get('student_id')
    lecture_id = data.get('lecture_id')
    reason_text = data.get('reason_text')
    document_url = data.get('document_url', '')

    if not student_id or not lecture_id or not reason_text:
        return jsonify({"error": "جميع الحقول الأساسية مطلوبة"}), 400

    new_excuse = AttendanceExcuse(
        student_id=student_id,
        lecture_id=lecture_id,
        reason_text=reason_text,
        document_url=document_url,
        status='قيد المراجعة'
    )
    
    db.session.add(new_excuse)
    db.session.commit()
    
    return jsonify({
        "message": "تم إرسال العذر بنجاح وهو الآن قيد المراجعة من الأستاذ",
        "excuse_id": new_excuse.excuse_id
    }), 201

# 2. مسار مراجعة وقبول أو رفض العذر (خاص بالأستاذ)
@app.route('/api/review-excuse/<int:excuse_id>', methods=['PUT'])
def review_excuse(excuse_id):
    excuse = AttendanceExcuse.query.get(excuse_id)
    if not excuse:
        return jsonify({"error": "العذر غير موجود"}), 404

    data = request.json or {}
    action = data.get('action')  # 'accept' or 'reject'
    review_notes = data.get('review_notes', '')

    if action not in ['accept', 'reject']:
        return jsonify({"error": "الإجراء غير صالح، يجب أن يكون 'accept' أو 'reject'"}), 400

    if action == 'accept':
        excuse.status = 'مقبول'
        excuse.review_notes = review_notes
        
        # تحديث حالة سجل الحضور للطالب إلى 'Excused'
        record = AttendanceRecord.query.filter_by(
            student_id=excuse.student_id,
            lecture_id=excuse.lecture_id
        ).first()

        if record:
            record.status = 'Excused'
        else:
            record = AttendanceRecord(
                lecture_id=excuse.lecture_id,
                student_id=excuse.student_id,
                status='Excused',
                gps_verified=False
            )
            db.session.add(record)
            
        message = "تم قبول العذر وتعديل حالة الحضور بنجاح"
    else:
        excuse.status = 'مرفوض'
        excuse.review_notes = review_notes
        message = "تم رفض العذر وبقاء حالة الغياب"

    db.session.commit()
    return jsonify({"message": message, "status": excuse.status})

# 3. مسار لوحة الشرف والتميز للطلاب الحاضرين بنسبة 100% مع التحقق الجغرافي
@app.route('/api/perfect-attendance/<int:lecture_id>', methods=['GET'])
def get_perfect_attendance(lecture_id):
    records = AttendanceRecord.query.filter_by(
        lecture_id=lecture_id,
        status='حاضر',
        gps_verified=True
    ).all()
    
    honored_students = []
    for r in records:
        student = Student.query.get(r.student_id)
        if student:
            honored_students.append({
                'student_id': student.student_id,
                'full_name': student.full_name,
                'university_id': student.university_id,
                'department': student.department,
                'distance_meters': r.distance_meters,
                'scan_timestamp': r.scan_timestamp.isoformat()
            })
            
    return jsonify({
        'lecture_id': lecture_id,
        'count': len(honored_students),
        'honored_students': honored_students
    })

# 4. مسار توثيق وتفويض المعيد في سجل التدقيق (TA Proxy Action API)
@app.route('/api/assistant-action', methods=['POST'])
def assistant_action():
    data = request.get_json() or {}
    lecture_id = data.get('lecture_id')
    assistant_name = data.get('assistant_name')
    action_performed = data.get('action_performed', 'فتح القاعة وتفعيل الباركود المتغير نيابة عن الأستاذ')
    ip_address = request.remote_addr or '192.168.1.100'

    if not lecture_id or not assistant_name:
        return jsonify({'error': 'رقم المحاضرة واسم المعيد مطلوبان'}), 400

    lecture = Lecture.query.get(lecture_id)
    if not lecture:
        return jsonify({'error': 'المحاضرة المحددة غير موجودة'}), 404

    # تسجيل العملية وتوثيقها في جدول التدقيق (Audit Log)
    audit_entry = AssistantAuditLog(
        lecture_id=lecture_id,
        assistant_name=assistant_name,
        action_performed=action_performed,
        ip_address=ip_address,
        status='نجاح'
    )
    db.session.add(audit_entry)
    db.session.commit()

    return jsonify({
        'success': True,
        'message': f'تم منح الصلاحية المؤقتة للمعيد: {assistant_name} وتوثيق العملية في سجل التدقيق بنجاح.',
        'log': audit_entry.to_dict()
    }), 201

# مسار استرجاع سجل تدقيق عمليات المعيدين والمساعدين
@app.route('/api/assistant-logs/<int:lecture_id>', methods=['GET'])
def get_assistant_logs(lecture_id):
    logs = AssistantAuditLog.query.filter_by(lecture_id=lecture_id).order_by(AssistantAuditLog.timestamp.desc()).all()
    return jsonify({
        'lecture_id': lecture_id,
        'count': len(logs),
        'logs': [log.to_dict() for log in logs]
    })

# 5. مسار تقديم تقييم فوري واستيعاب للمحاضرة من قبل الطالب
@app.route('/api/submit-feedback', methods=['POST'])
def submit_feedback():
    data = request.json or {}
    lecture_id = data.get('lecture_id')
    student_id = data.get('student_id')
    understanding_score = data.get('understanding_score')

    if not lecture_id or not student_id or understanding_score is None:
        return jsonify({"error": "جميع الحقول الأساسية مطلوبة (رقم المحاضرة، الطالب، درجة الاستيعاب)"}), 400

    new_feedback = LectureFeedback(
        lecture_id=lecture_id,
        student_id=student_id,
        understanding_score=int(understanding_score)
    )
    db.session.add(new_feedback)
    db.session.commit()

    return jsonify({"message": "شكراً لك! تم إرسال تقييمك للمحاضرة بنجاح."}), 201

# 6. مسار منح نقطة تميز ومشاركة وتفاعل للطالب من قبل الأستاذ
@app.route('/api/add-participation-point', methods=['POST'])
def add_participation_point():
    data = request.json or {}
    student_id = data.get('student_id')
    course_id = data.get('course_id')
    reason = data.get('reason', 'مشاركة وتفاعل إيجابي أثناء المحاضرة')

    if not student_id or not course_id:
        return jsonify({"error": "رقم الطالب ورقم المقرر مطلوبان"}), 400

    new_participation = StudentParticipation(
        student_id=student_id,
        course_id=course_id,
        points_added=1,
        reason=reason
    )
    db.session.add(new_participation)
    db.session.commit()

    return jsonify({"message": "تم منح نقطة التميز والمشاركة للطالب بنجاح!"}), 201

# 7. مسار إنشاء تنبيه إرشاد أكاديمي جديد (الإنذار المبكر)
@app.route('/api/academic-alerts', methods=['POST'])
def create_academic_alert():
    data = request.json or {}
    student_id = data.get('student_id')
    advisor_name = data.get('advisor_name', 'د. عبد السلام الورفلي')
    absence_count = data.get('absence_count', 3)

    if not student_id or not advisor_name:
        return jsonify({"error": "رقم الطالب واسم المرشد الأكاديمي مطلوبان"}), 400

    new_alert = AcademicAdvisorAlert(
        student_id=student_id,
        advisor_name=advisor_name,
        absence_count=int(absence_count),
        status='قيد المتابعة'
    )
    db.session.add(new_alert)
    db.session.commit()

    return jsonify({
        "message": "تم إصدار تنبيه الإرشاد الأكاديمي بنجاح",
        "alert": new_alert.to_dict()
    }), 201

# 8. مسار استرجاع وتحديث حالة تنبيه الإرشاد الأكاديمي
@app.route('/api/academic-alerts/<int:alert_id>', methods=['PUT'])
def update_academic_alert(alert_id):
    alert = AcademicAdvisorAlert.query.get(alert_id)
    if not alert:
        return jsonify({"error": "التنبيه غير موجود"}), 404

    data = request.json or {}
    new_status = data.get('status', 'تم التدخل')
    alert.status = new_status
    db.session.commit()

    return jsonify({
        "message": f"تم تحديث حالة التنبيه إلى ({new_status}) بنجاح",
        "alert": alert.to_dict()
    })

# 9. مسار التحقق من الكود الخاص بالطالب والصورة الشخصية وتسجيل الحضور بدقة
@app.route('/api/verify-student-code', methods=['POST'])
def verify_student_code():
    data = request.json or {}
    university_id = data.get('university_id')
    entered_code = data.get('secret_code')
    lecture_id = data.get('lecture_id')

    # البحث عن الطالب بالرقم الجامعي والكود الخاص به
    student = Student.query.filter_by(
        university_id=university_id,
        secret_code=entered_code
    ).first()

    if not student:
        return jsonify({
            'error': 'الرقم الجامعي أو الكود السري الخاص بالطالب غير صحيح!'
        }), 400

    # تسجيل الحضور في قاعدة البيانات
    record = AttendanceRecord(
        student_id=student.student_id,
        lecture_id=lecture_id,
        status='حاضر',
        gps_verified=True
    )
    db.session.add(record)
    db.session.commit()

    return jsonify({
        'message': 'تم التحقق وتسجيل الحضور بنجاح!',
        'student_name': student.full_name,
        'photo_url': student.photo_url or 'https://cdn-icons-png.flaticon.com/512/149/149071.png'
    }), 200

# 10. مسار تسجيل الحضور الذي يعيد بيانات وصورة الطالب للوحة الأستاذ
@app.route('/api/check-in', methods=['POST'])
def check_in():
    data = request.json or {}
    student_id = data.get('student_id')
    lecture_id = data.get('lecture_id')

    student = Student.query.get(student_id)
    if not student:
        return jsonify({'error': 'الطالب غير موجود'}), 404

    # تسجيل الحضور في قاعدة البيانات
    new_record = AttendanceRecord(
        student_id=student_id,
        lecture_id=lecture_id,
        status='حاضر',
        gps_verified=True
    )
    db.session.add(new_record)
    db.session.commit()

    # إرجاع رد يترتب عليه ظهور صورة الطالب في شاشة الأستاذ
    return jsonify({
        'message': 'تم تسجيل الحضور بنجاح',
        'student_name': student.full_name,
        'university_id': student.university_id,
        'photo_url': student.photo_url or 'https://cdn-icons-png.flaticon.com/512/149/149071.png'
    }), 200

# إنشاء الجداول وتغذية بيانات أولية للتجربة
with app.app_context():
    db.create_all()
    print("تم إنشاء قاعدة البيانات والجداول بنجاح!")
    
    # إضافة بيانات تجريبية إن لم تكن موجودة
    if not Student.query.first():
        s1 = Student(full_name='محمد علي أحمد', university_id='2023001', department='علوم الحاسب', secret_code='A7K9P2')
        s2 = Student(full_name='سارة خالد المنصور', university_id='2023002', department='هندسة البرمجيات', secret_code='B4M8X1')
        s3 = Student(full_name='عمر يوسف التميمي', university_id='2023003', department='نظم المعلومات', secret_code='C9R3N5')
        c1 = Course(course_name='قواعد البيانات المتقدمة', professor_name='د. أحمد عبد الرحمن')
        db.session.add_all([s1, s2, s3, c1])
        db.session.commit()
        
        l1 = Lecture(course_id=c1.course_id, hall_name='القاعة A1', hall_lat=32.123456, hall_lng=20.123456)
        db.session.add(l1)
        db.session.commit()
        print("تمت إضافة البيانات التجريبية الأولية بنجاح!")

if __name__ == '__main__':
    app.run(debug=True, port=5000)
`,
    },
    'code-python': {
      filename: 'app.py',
      language: 'python',
      content: `from flask import Flask, render_template, request, redirect, flash, url_for, jsonify
import mysql.connector
import re
import time
import hmac
import hashlib

app = Flask(__name__)
app.secret_key = 'attendance_super_secret_key_2024'

# مفتاح التشفير ومدة صلاحية الباركود
SECRET_SALT = "MyAttendanceUltraSecretKey2024"
TOKEN_INTERVAL = 5  # يتجدد كل 5 ثوانٍ لمنع الغش

db_config = {
    'host': 'localhost',
    'user': 'root',
    'password': '',
    'database': 'attendance_system'
}

def get_db_connection():
    return mysql.connector.connect(**db_config)

def get_time_window():
    return int(time.time() // TOKEN_INTERVAL)

def generate_token(lecture_id, window=None):
    if window is None:
        window = get_time_window()
    message = f"{lecture_id}:{window}:{SECRET_SALT}".encode()
    return hmac.new(SECRET_SALT.encode(), message, hashlib.sha256).hexdigest()[:16]

def is_token_valid(lecture_id, received_token):
    current_window = get_time_window()
    # قبول النافذة الحالية والسابقة لمراعاة تأخير الشبكة
    for w in [current_window, current_window - 1]:
        if hmac.compare_digest(generate_token(lecture_id, w), received_token):
            return True
    return False

@app.route('/')
def home():
    return redirect(url_for('live_screen', lecture_id=1))

@app.route('/lecture/<int:lecture_id>/live-screen')
def live_screen(lecture_id):
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)
    cursor.execute("""
        SELECT l.lecture_id, l.topic, c.course_name, c.course_code 
        FROM Lectures l JOIN Courses c ON l.course_id = c.course_id 
        WHERE l.lecture_id = %s
    """, (lecture_id,))
    lecture = cursor.fetchone()
    cursor.close()
    conn.close()
    return render_template('live_screen.html', lecture=lecture)

@app.route('/api/lecture/<int:lecture_id>/get-dynamic-token')
def get_dynamic_token(lecture_id):
    token = generate_token(lecture_id)
    seconds_left = TOKEN_INTERVAL - (int(time.time()) % TOKEN_INTERVAL)
    return jsonify({
        'token': token,
        'refresh_interval': TOKEN_INTERVAL,
        'seconds_left': seconds_left
    })

@app.route('/student/scan/<int:lecture_id>')
def student_scan_page(lecture_id):
    return render_template('student_scanner.html', lecture_id=lecture_id)

@app.route('/api/verify-and-attend', methods=['POST'])
def verify_and_attend():
    data = request.get_json()
    lecture_id = data.get('lecture_id')
    university_id = str(data.get('university_id', '')).strip()
    token = data.get('token')

    if not is_token_valid(lecture_id, token):
        return jsonify({'success': False, 'message': 'انتهت صلاحية الرمز! يرجى إعادة المسح من الشاشة.'}), 403

    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)
    try:
        cursor.execute("SELECT student_id, full_name FROM Students WHERE university_id = %s", (university_id,))
        student = cursor.fetchone()
        if not student:
            return jsonify({'success': False, 'message': 'الرقم الجامعي غير مسجل'}), 404

        query = """
            INSERT INTO Attendance (lecture_id, student_id, status, notes)
            VALUES (%s, %s, 'Present', 'تم التحضير عبر الباركود المتغير')
            ON DUPLICATE KEY UPDATE status = 'Present', recorded_at = CURRENT_TIMESTAMP
        """
        cursor.execute(query, (lecture_id, student['student_id']))
        conn.commit()
        return jsonify({'success': True, 'message': f'تم تسجيل حضور {student["full_name"]} بنجاح!'})
    finally:
        cursor.close()
        conn.close()

# ==========================================================
# مسار استقبال ومزامنة العمليات المخزنة في وضع عدم الاتصال (Offline Sync)
# ==========================================================
@app.route('/api/sync-offline-attendance', methods=['POST'])
def sync_offline_attendance():
    """
    يستقبل مصفوفة العمليات التي خُزنت في LocalStorage أثناء انقطاع الإنترنت،
    ويقوم بالتحقق من صحة التوكن وقت المسح (timestamp_ms) وحفظها دفعة واحدة في MySQL.
    """
    payload = request.get_json() or {}
    records = payload.get('records', [])

    if not records:
        return jsonify({'success': False, 'message': 'لا توجد سجلات للمزامنة'}), 400

    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)
    synced_count = 0
    errors = []

    try:
        for item in records:
            lecture_id = item.get('lecture_id')
            university_id = str(item.get('university_id', '')).strip()
            token = item.get('token')
            timestamp_ms = item.get('timestamp_ms')

            if not all([lecture_id, university_id, token]):
                continue

            # 1. التحقق الأمني: فحص صلاحية التوكن في نافذة وقت المسح الفعلي
            scan_time_sec = (timestamp_ms / 1000.0) if timestamp_ms else time.time()
            scan_window = int(scan_time_sec // TOKEN_INTERVAL)

            valid = False
            for w in [scan_window, scan_window - 1]:
                if hmac.compare_digest(generate_token(lecture_id, w), token):
                    valid = True
                    break

            if not valid:
                errors.append(f"الطالب {university_id}: توكن منتهي الصلاحية")
                continue

            # 2. التحقق من وجود الطالب
            cursor.execute("SELECT student_id, full_name FROM Students WHERE university_id = %s", (university_id,))
            student = cursor.fetchone()
            if not student:
                errors.append(f"الرقم {university_id} غير موجود")
                continue

            # 3. التحقق من تسجيل الطالب في المقرر
            cursor.execute("""
                SELECT ce.enrollment_id 
                FROM Course_Enrollments ce
                JOIN Lectures l ON ce.course_id = l.course_id
                WHERE l.lecture_id = %s AND ce.student_id = %s
            """, (lecture_id, student['student_id']))
            if not cursor.fetchone():
                errors.append(f"الطالب {student['full_name']} غير مسجل بالمقرر")
                continue

            # 4. إدراج أو تحديث الحضور
            upsert_query = """
                INSERT INTO Attendance (lecture_id, student_id, status, notes)
                VALUES (%s, %s, 'Present', 'تم التحضير بدون اتصال (تمت المزامنة)')
                ON DUPLICATE KEY UPDATE 
                    status = 'Present',
                    notes = 'تم التحضير بدون اتصال (تمت المزامنة)',
                    recorded_at = CURRENT_TIMESTAMP
            """
            cursor.execute(upsert_query, (lecture_id, student['student_id']))
            synced_count += 1

        conn.commit()
        return jsonify({
            'success': True,
            'synced_count': synced_count,
            'errors': errors,
            'message': f'تمت مزامنة {synced_count} عملية حضور بنجاح مع قاعدة البيانات!'
        })
    except Exception as e:
        conn.rollback()
        return jsonify({'success': False, 'message': f'خطأ أثناء المزامنة: {str(e)}'}), 500
    finally:
        cursor.close()
        conn.close()

if __name__ == '__main__':
    app.run(debug=True, port=5000)`,
    },
    'code-js-offline': {
      filename: 'offline_attendance.js',
      language: 'javascript',
      content: `/**
 * مدير وضع عدم الاتصال والمزامنة التلقائية (Offline Attendance Manager)
 * 1. يخزن عمليات المسح محلياً في LocalStorage عند انقطاع الإنترنت
 * 2. يستمع تلقائياً لحدث عودة الإنترنت (Online Event) لمزامنة البيانات مع خادم Flask
 */

const STORAGE_QUEUE_KEY = 'attendance_offline_queue';

// 1. فحص اتصال الإنترنت بالجهاز
function isDeviceOnline() {
    return navigator.onLine;
}

// 2. قراءة قائمة الانتظار من LocalStorage
function getOfflineQueue() {
    try {
        const raw = localStorage.getItem(STORAGE_QUEUE_KEY);
        return raw ? JSON.parse(raw) : [];
    } catch (e) {
        console.error("فشل قراءة LocalStorage:", e);
        return [];
    }
}

// 3. حفظ عملية مسح جديدة محلياً في LocalStorage
function saveScanOffline(lectureId, universityId, token) {
    const queue = getOfflineQueue();
    const newRecord = {
        id: 'scan_' + Date.now() + '_' + Math.random().toString(36).substr(2, 5),
        lecture_id: lectureId,
        university_id: universityId.trim(),
        token: token.trim(),
        timestamp_ms: Date.now(),
        scanned_at: new Date().toLocaleString('ar-SA'),
        status: 'pending'
    };

    queue.push(newRecord);
    localStorage.setItem(STORAGE_QUEUE_KEY, JSON.stringify(queue));

    console.log("📦 تم حفظ عملية المسح محلياً في LocalStorage:", newRecord);
    return newRecord;
}

// 4. الدالة الرئيسية للمسح: تفحص الاتصال وتقرر الإرسال المباشر أو الحفظ في LocalStorage
async function processStudentScan(lectureId, universityId, token) {
    if (!isDeviceOnline()) {
        const record = saveScanOffline(lectureId, universityId, token);
        return {
            success: true,
            isOffline: true,
            message: "تم حفظ التحضير محلياً بنجاح (وضع عدم الاتصال). ستتم المزامنة تلقائياً عند عودة النت."
        };
    }

    // إذا كان الجهاز متصلاً، أرسل الطلب المباشر
    try {
        const res = await fetch('/api/verify-and-attend', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ lecture_id: lectureId, university_id: universityId, token: token })
        });
        const data = await res.json();
        return { ...data, isOffline: false };
    } catch (err) {
        // في حال فشل الاتصال المفاجئ بالخادم، احفظ في LocalStorage كخطة بديلة
        console.warn("⚠️ تعذر الوصول للخادم، جاري الحفظ المحلي كخطة طوارئ...");
        saveScanOffline(lectureId, universityId, token);
        return {
            success: true,
            isOffline: true,
            message: "انقطع الاتصال بالسيرفر! تم حفظ العملية محلياً وستتم المزامنة لاحقاً."
        };
    }
}

// 5. مزامنة العمليات المخزنة مع خادم Flask (تُستدعى عند عودة النت أو يدوياً)
async function syncOfflineScans() {
    const queue = getOfflineQueue();
    const pending = queue.filter(item => item.status === 'pending');

    if (pending.length === 0) {
        console.log("لا توجد عمليات معلقة للمزامنة.");
        return { success: true, count: 0 };
    }

    if (!isDeviceOnline()) {
        console.warn("الجهاز لا يزال غير متصل بالإنترنت.");
        return { success: false, message: 'offline' };
    }

    console.log(\`🔄 جاري مزامنة \${pending.length} عمليات مخزنة مع الخادم...\`);

    try {
        const response = await fetch('/api/sync-offline-attendance', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ records: pending })
        });

        const result = await response.json();

        if (result.success) {
            // تفريغ القائمة المحلية بعد نجاح حفظها في MySQL
            localStorage.removeItem(STORAGE_QUEUE_KEY);
            console.log(\`✅ تمت مزامنة \${result.synced_count} عملية بنجاح!\`);
            return { success: true, count: result.synced_count };
        } else {
            console.error("فشل الخادم في إتمام المزامنة:", result.message);
            return { success: false, message: result.message };
        }
    } catch (error) {
        console.error("خطأ أثناء الاتصال بالخادم لمزامنة السجلات:", error);
        return { success: false, message: 'network_failure' };
    }
}

// 6. الاستماع التلقائي لحدث عودة الإنترنت (Online Event Listener)
window.addEventListener('online', () => {
    console.log("🌐 تم استعادة الاتصال بالإنترنت! بدء المزامنة التلقائية فوراً...");
    syncOfflineScans();
});

window.addEventListener('offline', () => {
    console.warn("⚠️ تم قطع الاتصال بالإنترنت. تم تفعيل وضع التخزين المحلي.");
});`,
    },
    'code-html-v2': {
      filename: 'live_screen_v2.html',
      language: 'html',
      content: `<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>منظومة الحضور الذكية - المظهر المطور</title>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/qrcodejs/1.0.0/qrcode.min.js"></script>
  
  <style>
    :root {
      --bg-color: #f8fafc;
      --card-bg: #ffffff;
      --text-color: #1e293b;
      --accent-color: #2563eb;
      --success-color: #10b981;
      --warning-color: #f59e0b;
      --danger-color: #ef4444;
      --border-color: #e2e8f0;
      --shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.05), 0 4px 6px -2px rgba(0, 0, 0, 0.02);
    }

    body.dark-theme {
      --bg-color: #0f172a;
      --card-bg: #1e293b;
      --text-color: #f8fafc;
      --accent-color: #3b82f6;
      --border-color: #334155;
      --shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.3);
    }

    body {
      background-color: var(--bg-color);
      color: var(--text-color);
      font-family: system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
      margin: 0;
      padding: 24px;
      transition: all 0.3s ease;
    }

    .container {
      max-width: 1200px;
      margin: 0 auto;
    }

    /* Top Bar */
    .header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 24px;
    }

    .btn {
      background: var(--card-bg);
      color: var(--text-color);
      border: 1px solid var(--border-color);
      padding: 10px 18px;
      border-radius: 10px;
      cursor: pointer;
      font-weight: 600;
      box-shadow: var(--shadow);
      transition: transform 0.2s;
    }

    .btn:hover { transform: translateY(-2px); }

    /* 2. KPI Cards Header */
    .kpi-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
      gap: 16px;
      margin-bottom: 24px;
    }

    .kpi-card {
      background: var(--card-bg);
      padding: 20px;
      border-radius: 14px;
      border: 1px solid var(--border-color);
      box-shadow: var(--shadow);
    }

    .kpi-title { font-size: 0.875rem; opacity: 0.7; font-weight: 500; }
    .kpi-value { font-size: 2rem; font-weight: 700; margin-top: 8px; }

    /* Main Grid */
    .main-grid {
      display: grid;
      grid-template-columns: 360px 1fr;
      gap: 24px;
    }

    @media (max-width: 900px) {
      .main-grid { grid-template-columns: 1fr; }
    }

    .card {
      background: var(--card-bg);
      border-radius: 16px;
      padding: 24px;
      border: 1px solid var(--border-color);
      box-shadow: var(--shadow);
    }

    /* 1. Pulsing QR Card */
    .qr-box {
      display: flex;
      flex-direction: column;
      align-items: center;
      text-align: center;
    }

    .qr-wrapper {
      position: relative;
      padding: 16px;
      background: white;
      border-radius: 16px;
      box-shadow: 0 0 0 4px rgba(37, 99, 235, 0.15);
      animation: pulse 5s infinite;
      margin: 16px 0;
    }

    @keyframes pulse {
      0% { box-shadow: 0 0 0 0px rgba(37, 99, 235, 0.4); }
      50% { box-shadow: 0 0 0 12px rgba(37, 99, 235, 0); }
      100% { box-shadow: 0 0 0 0px rgba(37, 99, 235, 0.4); }
    }

    .timer-bar {
      width: 100%;
      height: 6px;
      background: #e2e8f0;
      border-radius: 3px;
      overflow: hidden;
    }

    .timer-progress {
      height: 100%;
      background: var(--accent-color);
      width: 100%;
    }

    /* 3. Interactive Student Table */
    .table-container {
      width: 100%;
      border-collapse: collapse;
      margin-top: 16px;
    }

    .table-container th, .table-container td {
      padding: 12px;
      text-align: right;
      border-bottom: 1px solid var(--border-color);
    }

    .avatar {
      width: 34px;
      height: 34px;
      border-radius: 50%;
      background: var(--accent-color);
      color: white;
      display: inline-flex;
      align-items: center;
      justify-content: center;
      font-weight: bold;
      font-size: 0.85rem;
      margin-left: 8px;
    }

    .badge {
      padding: 4px 10px;
      border-radius: 20px;
      font-size: 0.75rem;
      font-weight: 600;
    }

    .badge-success { background: rgba(16, 185, 129, 0.15); color: var(--success-color); }

    /* Toast Notification */
    .toast {
      position: fixed;
      bottom: 24px;
      left: 24px;
      background: var(--card-bg);
      color: var(--text-color);
      padding: 14px 20px;
      border-radius: 12px;
      border-right: 4px solid var(--success-color);
      box-shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.2);
      display: none;
      animation: slideIn 0.3s ease;
    }

    @keyframes slideIn {
      from { transform: translateX(-100%); opacity: 0; }
      to { transform: translateX(0); opacity: 1; }
    }
  </style>
</head>
<body>

  <div class="container">
    <div class="header">
      <div>
        <h1 style="margin: 0; font-size: 1.5rem;">لوحة التحضير المباشرة</h1>
        <span style="opacity: 0.6; font-size: 0.875rem;">مادة: إدارة الأعمال | القاعة A1</span>
      </div>
      <button class="btn" onclick="toggleTheme()">المظهر 🌙/☀️</button>
    </div>

    <!-- KPI Cards -->
    <div class="kpi-grid">
      <div class="kpi-card">
        <div class="kpi-title">إجمالي الطلاب</div>
        <div class="kpi-value">50</div>
      </div>
      <div class="kpi-card">
        <div class="kpi-title">الحاضرون الآن</div>
        <div class="kpi-value" style="color: var(--success-color);" id="kpiPresent">0</div>
      </div>
      <div class="kpi-card">
        <div class="kpi-title">نسبة الحضور</div>
        <div class="kpi-value" id="kpiPercent">0%</div>
      </div>
    </div>

    <div class="main-grid">
      <!-- QR Card -->
      <div class="card qr-box">
        <h3 style="margin: 0;">رمز الحضور المتغير</h3>
        <span style="font-size: 0.8rem; opacity: 0.7; margin-top: 4px;">يتجدد التشفير آلياً كل 5 ثوانٍ</span>
        
        <div class="qr-wrapper">
          <div id="qrcode"></div>
        </div>

        <div class="timer-bar">
          <div id="timerProgress" class="timer-progress"></div>
        </div>
      </div>

      <!-- Live Table -->
      <div class="card">
        <h3 style="margin: 0 0 16px 0;">سجل الحضور الفوري</h3>
        <table class="table-container">
          <thead>
            <tr style="opacity: 0.6; font-size: 0.85rem;">
              <th>الطالب</th>
              <th>التوقيت</th>
              <th>الحالة</th>
            </tr>
          </thead>
          <tbody id="studentTable">
            <tr>
              <td colspan="3" style="text-align: center; opacity: 0.5; padding: 24px;">في انتظار مسح أول رمز...</td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  </div>

  <div id="toast" class="toast">✅ تم تسجيل حضور الطالب بنجاح!</div>

  <script>
    function toggleTheme() {
      document.body.classList.toggle('dark-theme');
    }

    // Dynamic QR & Timer Logic
    const qrcodeContainer = document.getElementById("qrcode");
    let qr = new QRCode(qrcodeContainer, { width: 180, height: 180 });

    function updateQR() {
      let token = "TOKEN_" + Math.random().toString(36).substring(2, 8).toUpperCase();
      qr.makeCode(token);
    }

    let duration = 5000;
    let elapsed = 0;
    let step = 100;
    let timerProgress = document.getElementById('timerProgress');

    updateQR();
    setInterval(() => {
      elapsed += step;
      let percentage = 100 - ((elapsed / duration) * 100);
      timerProgress.style.width = percentage + '%';

      if (elapsed >= duration) {
        elapsed = 0;
        updateQR();
      }
    }, step);

    // Dynamic Table & KPI Update Simulation
    let presentCount = 0;
    let totalCount = 50;

    function addStudent(name) {
      presentCount++;
      document.getElementById('kpiPresent').innerText = presentCount;
      document.getElementById('kpiPercent').innerText = Math.round((presentCount / totalCount) * 100) + '%';

      let tbody = document.getElementById('studentTable');
      if (presentCount === 1) tbody.innerHTML = '';

      let time = new Date().toLocaleTimeString('ar-LY', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
      let firstChar = name.charAt(0);

      let row = \`
        <tr>
          <td>
            <div style="display: flex; align-items: center;">
              <span class="avatar">\${firstChar}</span>
              <span>\${name}</span>
            </div>
          </td>
          <td>\${time}</td>
          <td><span class="badge badge-success">حاضر</span></td>
        </tr>
      \`;
      tbody.innerHTML = row + tbody.innerHTML;

      // Toast Notification
      let toast = document.getElementById('toast');
      toast.style.display = 'block';
      setTimeout(() => { toast.style.display = 'none'; }, 2500);
    }

    // Demo simulation
    setTimeout(() => addStudent("أحمد المصراطي"), 2000);
    setTimeout(() => addStudent("فاطمة الفيتوري"), 4500);
  </script>
</body>
</html>`,
    },
    'code-html-dashboard': {
      filename: 'dashboard_standalone.html',
      language: 'html',
      content: `<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>نظام متابعة الحضور الذكي</title>
  <!-- مكتبة لتوليد الباركود Dynamically -->
  <script src="https://cdnjs.cloudflare.com/ajax/libs/qrcodejs/1.0.0/qrcode.min.js"></script>
  
  <style>
    :root {
      --bg-color: #f4f6f9;
      --card-bg: #ffffff;
      --text-color: #333333;
      --accent-color: #2563eb;
      --progress-bg: #e2e8f0;
      --border-color: #e5e7eb;
    }

    /* 1. الوضع الليلي التلقائي (Dark Mode) */
    @media (prefers-color-scheme: dark) {
      :root {
        --bg-color: #0f172a;
        --card-bg: #1e293b;
        --text-color: #f8fafc;
        --accent-color: #3b82f6;
        --progress-bg: #334155;
        --border-color: #475569;
      }
    }

    body.dark-theme {
      --bg-color: #0f172a;
      --card-bg: #1e293b;
      --text-color: #f8fafc;
      --accent-color: #3b82f6;
      --progress-bg: #334155;
      --border-color: #475569;
    }

    body.light-theme {
      --bg-color: #f4f6f9;
      --card-bg: #ffffff;
      --text-color: #333333;
      --accent-color: #2563eb;
      --progress-bg: #e2e8f0;
      --border-color: #e5e7eb;
    }

    body {
      background-color: var(--bg-color);
      color: var(--text-color);
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      margin: 0;
      padding: 20px;
      transition: background-color 0.3s, color 0.3s;
    }

    /* 3. لوحة تحكم تفاعلية متجاوبة (Responsive Dashboard Layout) */
    .dashboard-container {
      max-width: 1100px;
      margin: 0 auto;
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 20px;
    }

    @media (max-width: 768px) {
      .dashboard-container {
        grid-template-columns: 1fr;
      }
    }

    .card {
      background-color: var(--card-bg);
      border-radius: 16px;
      padding: 24px;
      box-shadow: 0 4px 20px rgba(0, 0, 0, 0.08);
      border: 1px solid var(--border-color);
      text-align: center;
    }

    .header-bar {
      display: flex;
      justify-content: space-between;
      align-items: center;
      max-width: 1100px;
      margin: 0 auto 20px auto;
    }

    .theme-toggle {
      background: var(--accent-color);
      color: white;
      border: none;
      padding: 8px 16px;
      border-radius: 8px;
      cursor: pointer;
      font-weight: bold;
    }

    /* 2. شاشة عرض تفاعلية جماعية (Live Counter & Progress Bar) */
    .counter-box {
      font-size: 3rem;
      font-weight: bold;
      color: var(--accent-color);
      margin: 10px 0;
    }

    .progress-bar-container {
      background-color: var(--progress-bg);
      border-radius: 12px;
      height: 20px;
      width: 100%;
      overflow: hidden;
      margin-top: 15px;
    }

    .progress-bar-fill {
      background-color: var(--accent-color);
      height: 100%;
      width: 0%;
      transition: width 0.5s ease-in-out;
    }

    /* 4. المؤشر البصري الزمني للباركود المتغير */
    .qr-wrapper {
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      gap: 15px;
    }

    #qrcode {
      background: white;
      padding: 15px;
      border-radius: 12px;
      display: inline-block;
    }

    .timer-bar-container {
      width: 250px;
      height: 8px;
      background-color: var(--progress-bg);
      border-radius: 4px;
      overflow: hidden;
    }

    .timer-bar-fill {
      height: 100%;
      width: 100%;
      background-color: #ef4444; /* مؤشر أحمر ينقص */
      transition: width 0.1s linear;
    }

    .recent-list {
      list-style: none;
      padding: 0;
      margin-top: 20px;
      text-align: right;
      max-height: 150px;
      overflow-y: auto;
    }

    .recent-item {
      padding: 8px 12px;
      border-bottom: 1px solid var(--border-color);
      display: flex;
      justify-content: space-between;
      animation: fadeIn 0.3s ease;
    }

    @keyframes fadeIn {
      from { opacity: 0; transform: translateY(-5px); }
      to { opacity: 1; transform: translateY(0); }
    }
  </style>
</head>
<body>

  <!-- شريط العنوان والتحكم في الثيم -->
  <div class="header-bar">
    <h2>📊 شاشة المتابعة الحية للمحاضرة</h2>
    <button class="theme-toggle" onclick="toggleTheme()">🌓 تبديل الوضع</button>
  </div>

  <div class="dashboard-container">
    
    <!-- القسم 1: الباركود والمؤشر الزمني المتغير -->
    <div class="card qr-wrapper">
      <h3>امسح الباركود لتسجيل الحضور</h3>
      <p style="font-size: 0.9rem; color: #64748b;">يتغير الكود تلقائياً كل 5 ثوانٍ لحماية النظام من الغش</p>
      
      <div id="qrcode"></div>
      
      <!-- شريط المؤشر البصري الزمني -->
      <div class="timer-bar-container">
        <div id="timerFill" class="timer-bar-fill"></div>
      </div>
      <span id="timerText" style="font-size: 0.8rem; font-weight: bold;">5 ثوانٍ</span>
    </div>

    <!-- القسم 2: إحصائيات الحضور المباشرة وقائمة المسجلين -->
    <div class="card">
      <h3>نسبة الحضور الحالية</h3>
      
      <div class="counter-box">
        <span id="presentCount">0</span> / <span id="totalCount">40</span>
      </div>

      <div class="progress-bar-container">
        <div id="progressBar" class="progress-bar-fill"></div>
      </div>

      <h4 style="margin-top: 25px; text-align: right;">آخر المسجلين:</h4>
      <ul id="recentList" class="recent-list">
        <!-- يتم إدراج أسماء الطلاب هنا ديناميكياً -->
      </ul>
      
      <!-- زر تجريبي للمحاكاة أثناء التطوير -->
      <button onclick="simulateStudentScan()" style="margin-top: 15px; padding: 6px 12px; cursor: pointer; border-radius: 6px; border: 1px solid var(--border-color); background: var(--card-bg); color: var(--text-color);">
        + محاكاة مسح طالب جديد
      </button>
    </div>

  </div>

  <script>
    // --- 1. منطق الثيم (Dark / Light Mode) ---
    function toggleTheme() {
      const isDark = document.body.classList.toggle('dark-theme');
      if (!isDark) {
        document.body.classList.toggle('light-theme');
      }
    }

    // --- 2. إعداد الباركود والمؤشر الزمني (Dynamic QR & Timer) ---
    const qrElement = document.getElementById("qrcode");
    const qrcode = new QRCode(qrElement, {
      text: "INIT_TOKEN",
      width: 200,
      height: 200
    });

    const INTERVAL = 5; // مدة صلاحية الكود بالثواني
    let timeLeft = INTERVAL;
    const timerFill = document.getElementById('timerFill');
    const timerText = document.getElementById('timerText');

    function updateQRCode() {
      // توليد قيمة عشوائية جديدة تمثل الرمز الأمني المتغير (Dynamic OTP)
      const dynamicToken = "ATTEND_" + Math.random().toString(36).substring(2, 8).toUpperCase() + "_" + Date.now();
      qrcode.clear();
      qrcode.makeCode(dynamicToken);
    }

    // تشغيل العداد والمؤشر الزمني كل 100 ميلي ثانية
    setInterval(() => {
      timeLeft -= 0.1;
      
      if (timeLeft <= 0) {
        timeLeft = INTERVAL;
        updateQRCode(); // تجديد الكود فور انتهاء الوقت
      }

      // تحديث شريط التناقص والنص
      const percentage = (timeLeft / INTERVAL) * 100;
      timerFill.style.width = percentage + "%";
      timerText.innerText = Math.ceil(timeLeft) + " ثوانٍ";
    }, 100);

    // البداية الأولية
    updateQRCode();

    // --- 3. إدارة الإحصائيات وقائمة آخر المسجلين ---
    let presentStudents = 0;
    const totalStudents = 40;

    function addStudentToLiveList(studentName, studentId) {
      presentStudents++;
      
      // تحديث الأرقام
      document.getElementById('presentCount').innerText = presentStudents;
      
      // تحديث شريط التقدم
      const percentage = (presentStudents / totalStudents) * 100;
      document.getElementById('progressBar').style.width = percentage + "%";

      // إضافة الطالب لأعلى القائمة
      const list = document.getElementById('recentList');
      const item = document.createElement('li');
      item.className = 'recent-item';
      
      const time = new Date().toLocaleTimeString('ar-SA', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
      item.innerHTML = \`<span>✅ \${studentName} (\${studentId})</span> <span style="font-size: 0.8rem; color: #64748b;">\${time}</span>\`;
      
      list.insertBefore(item, list.firstChild);
    }

    // محاكاة تسجيل طالب عشوائي
    function simulateStudentScan() {
      if (presentStudents >= totalStudents) return;
      const dummyNames = ["أحمد المنصوري", "سارة العتيبي", "خالد الزهراني", "فاطمة الشمري", "محمد الغامدي"];
      const randomName = dummyNames[Math.floor(Math.random() * dummyNames.length)];
      const randomId = "44" + Math.floor(100000 + Math.random() * 900000);
      
      addStudentToLiveList(randomName, randomId);
    }
  </script>
</body>
</html>`,
    },
    'code-html-screen': {
      filename: 'templates/live_screen.html',
      language: 'html',
      content: `<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <title>باركود الحضور المباشر</title>
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@600;700&display=swap" rel="stylesheet">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/qrcodejs/1.0.0/qrcode.min.js"></script>
    <style>
        body { background: #0f172a; color: white; font-family: 'Cairo', sans-serif; display: flex; justify-content: center; align-items: center; min-height: 100vh; margin: 0; }
        .card { background: #1e293b; padding: 40px; border-radius: 24px; text-align: center; border: 1px solid #334155; }
        #qrcode { background: white; padding: 15px; border-radius: 16px; display: inline-block; }
        .bar { height: 8px; background: #ef4444; width: 100%; border-radius: 99px; transition: width 0.1s linear; margin-top: 15px; }
    </style>
</head>
<body>
<div class="card">
    <h1>{{ lecture.course_name }}</h1>
    <p>{{ lecture.topic }}</p>
    <div id="qrcode"></div>
    <div class="bar" id="progress"></div>
    <p>يتجدد الرمز تلقائياً كل 5 ثوانٍ لمنع الغش (<span id="cd">5</span>s)</p>
</div>
<script>
    const qrcode = new QRCode(document.getElementById('qrcode'), { width: 250, height: 250 });
    let left = 5;
    async function update() {
        const res = await fetch('/api/lecture/{{ lecture.lecture_id }}/get-dynamic-token');
        const data = await res.json();
        qrcode.clear();
        qrcode.makeCode(data.token);
        left = data.seconds_left;
    }
    setInterval(() => {
        left -= 0.1;
        if (left <= 0) { update(); left = 5; }
        document.getElementById('cd').innerText = Math.ceil(left);
        document.getElementById('progress').style.width = (left / 5 * 100) + '%';
    }, 100);
    update();
</script>
</body>
</html>`,
    },
    'code-html-geo': {
      filename: 'live_screen_geo.html',
      language: 'html',
      content: `<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>منظومة الحضور الذكية - مع التحقق الجغرافي</title>
  <!-- مكتبة لتوليد الباركود المتغير ديناميكياً -->
  <script src="https://cdnjs.cloudflare.com/ajax/libs/qrcodejs/1.0.0/qrcode.min.js"></script>
  
  <style>
    :root {
      --bg-color: #f8fafc;
      --card-bg: #ffffff;
      --text-color: #1e293b;
      --accent-color: #2563eb;
      --success-color: #10b981;
      --danger-color: #ef4444;
      --border-color: #e2e8f0;
      --shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.05), 0 4px 6px -2px rgba(0, 0, 0, 0.02);
    }

    body.dark-theme {
      --bg-color: #0f172a;
      --card-bg: #1e293b;
      --text-color: #f8fafc;
      --accent-color: #3b82f6;
      --border-color: #334155;
      --shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.3);
    }

    body {
      background-color: var(--bg-color);
      color: var(--text-color);
      font-family: system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
      margin: 0;
      padding: 24px;
      transition: all 0.3s ease;
    }

    .container { max-width: 1200px; margin: 0 auto; }

    .header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 24px;
    }

    .btn {
      background: var(--card-bg);
      color: var(--text-color);
      border: 1px solid var(--border-color);
      padding: 10px 18px;
      border-radius: 10px;
      cursor: pointer;
      font-weight: 600;
      box-shadow: var(--shadow);
      transition: transform 0.2s;
    }
    .btn:hover { transform: translateY(-2px); }
    .btn-primary { background: var(--accent-color); color: #fff; border: none; }

    .stats-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
      gap: 16px;
      margin-bottom: 24px;
    }

    .card {
      background: var(--card-bg);
      padding: 24px;
      border-radius: 16px;
      border: 1px solid var(--border-color);
      box-shadow: var(--shadow);
    }

    .stat-title { font-size: 0.875rem; color: #64748b; margin-bottom: 8px; }
    .stat-value { font-size: 2rem; font-weight: 700; }

    .main-grid {
      display: grid;
      grid-template-columns: 1fr 2fr;
      gap: 24px;
    }

    @media (max-width: 768px) {
      .main-grid { grid-template-columns: 1fr; }
    }

    .qr-card {
      display: flex;
      flex-direction: column;
      align-items: center;
      text-align: center;
    }

    #qrcode {
      padding: 16px;
      background: white;
      border-radius: 12px;
      box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1);
      margin: 16px 0;
    }

    .timer-bar {
      width: 100%;
      height: 6px;
      background: #e2e8f0;
      border-radius: 9999px;
      overflow: hidden;
      margin-top: 10px;
    }

    .timer-fill {
      height: 100%;
      background: var(--accent-color);
      width: 100%;
      transition: width 0.1s linear;
    }

    .table {
      width: 100%;
      border-collapse: collapse;
      text-align: right;
    }

    .table th, .table td {
      padding: 14px;
      border-bottom: 1px solid var(--border-color);
    }

    .badge {
      padding: 6px 12px;
      border-radius: 9999px;
      font-size: 0.8rem;
      font-weight: 600;
    }
    .badge-success { background: #dcfce7; color: #15803d; }
    .badge-danger { background: #fee2e2; color: #b91c1c; }

    .avatar {
      width: 36px;
      height: 36px;
      border-radius: 50%;
      background: #e0e7ff;
      color: var(--accent-color);
      display: inline-flex;
      align-items: center;
      justify-content: center;
      font-weight: bold;
    }
  </style>
</head>
<body class="light-theme">

  <div class="container">
    <div class="header">
      <div>
        <h1 style="margin: 0; font-size: 1.5rem;">لوحة التحضير الذكية (مع التحديد الجغرافي)</h1>
        <small style="color: #64748b;">نظام التحقق المكاني المشروط بالقاعة (GPS) والباركود المتغير</small>
      </div>
      <div>
        <button class="btn" onclick="toggleTheme()">🌓 تبديل المظهر</button>
      </div>
    </div>

    <div class="stats-grid">
      <div class="card">
        <div class="stat-title">إجمالي الطلاب</div>
        <div class="stat-value">50</div>
      </div>
      <div class="card">
        <div class="stat-title">الحاضرون داخل القاعة</div>
        <div class="stat-value" id="present-count" style="color: var(--success-color);">0</div>
      </div>
      <div class="card">
        <div class="stat-title">نسبة الحضور</div>
        <div class="stat-value" id="attendance-rate" style="color: var(--accent-color);">0%</div>
      </div>
    </div>

    <div class="main-grid">
      <div class="card qr-card">
        <h3 style="margin-top: 0;">رمز الحضور المتجدد</h3>
        <div style="font-size: 0.8rem; color: #ef4444; font-weight: bold; margin-bottom: 10px;">⚠️ يشترط التواجد داخل القاعة (GPS)</div>
        <div id="qrcode"></div>
        <div class="timer-bar">
          <div class="timer-fill" id="timer-progress"></div>
        </div>
        <small style="margin-top: 8px; color: #64748b;">تحديث خلال <span id="countdown">5</span> ثوانٍ</small>
        
        <button class="btn btn-primary" onclick="simulateStudentScan()" style="width: 100%; margin-top: 15px;">محاكاة طالب يحاول التسجيل (GPS)</button>
      </div>

      <div class="card">
        <h3 style="margin-top: 0; margin-bottom: 16px;">سجل الحضور الفوري والتحقق الجغرافي</h3>
        <table class="table">
          <thead>
            <tr>
              <th>الطالب</th>
              <th>التوقيت</th>
              <th>التحقق الجغرافي (GPS)</th>
              <th>الحالة</th>
            </tr>
          </thead>
          <tbody id="attendance-list">
          </tbody>
        </table>
      </div>
    </div>

    <!-- 🌟 لوحة الشرف والتميز (حضور 100%) -->
    <div class="card" style="margin-top: 20px;">
      <h3 style="color: var(--success-color); margin-top: 0;">🌟 لوحة الشرف والتميز (حضور 100%)</h3>
      <p style="font-size: 0.85rem; opacity: 0.7; margin-bottom: 0;">الطلاب الأكثر انضباطاً والتزاماً بمواعيد المحاضرات:</p>
      
      <div style="display: flex; gap: 10px; flex-wrap: wrap; margin-top: 15px;">
        <div style="background: rgba(16, 185, 129, 0.1); padding: 8px 14px; border-radius: 20px; border: 1px solid var(--success-color); font-size: 0.85rem; font-weight: bold;">
          🏆 أحمد المصراطي (منتظم دائماً)
        </div>
        <div style="background: rgba(16, 185, 129, 0.1); padding: 8px 14px; border-radius: 20px; border: 1px solid var(--success-color); font-size: 0.85rem; font-weight: bold;">
          🏆 فاطمة الفيتوري (حضور مبكر)
        </div>
      </div>
    </div>
  </div>

  <script>
    // إحداثيات قاعة المحاضرة المحددة (مثال: كلية تقنية المعلومات)
    const lectureLat = 32.123456; 
    const lectureLng = 20.123456;
    const allowedRadiusMeters = 30; // السماح بـ 30 متراً كحد أقصى من مركز القاعة

    // دالة حساب المسافة بين نقطتين جغرافيتين بالمتر (Haversine Formula)
    function calculateDistance(lat1, lon1, lat2, lon2) {
        const R = 6371e3; // نصف قطر الأرض بالمتر
        const phi1 = lat1 * Math.PI/180;
        const phi2 = lat2 * Math.PI/180;
        const deltaPhi = (lat2 - lat1) * Math.PI/180;
        const deltaLambda = (lon2 - lon1) * Math.PI/180;

        const a = Math.sin(deltaPhi/2) * Math.sin(deltaPhi/2) +
                  Math.cos(phi1) * Math.cos(phi2) *
                  Math.sin(deltaLambda/2) * Math.sin(deltaLambda/2);
        const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));

        return Math.round(R * c); // إرجاع المسافة بالأمتار
    }

    // دوال إدارة الثيم والمظهر
    function toggleTheme() {
      const body = document.body;
      if (body.classList.contains('light-theme')) {
        body.classList.replace('light-theme', 'dark-theme');
      } else {
        body.classList.replace('dark-theme', 'light-theme');
      }
    }

    // إدارة الباركود المتغير (TOTP Dynamic QR)
    const qrContainer = document.getElementById("qrcode");
    const qrcode = new QRCode(qrContainer, { width: 180, height: 180 });
    let timeLeft = 5;

    function updateQR() {
      const dynamicToken = "SECURE_" + Math.random().toString(36).substring(2, 8).toUpperCase();
      qrcode.clear();
      qrcode.makeCode(dynamicToken);
      timeLeft = 5;
    }

    setInterval(() => {
      timeLeft -= 0.1;
      if (timeLeft <= 0) {
        updateQR();
      }
      document.getElementById("countdown").innerText = Math.ceil(timeLeft);
      document.getElementById("timer-progress").style.width = ((timeLeft / 5) * 100) + "%";
    }, 100);

    updateQR();

    // محاكاة تسجيل الحضور مع فحص الموقع الجغرافي
    let presentCount = 0;
    const totalStudents = 50;

    function simulateStudentScan() {
      // محاكاة إحداثيات عشوائية للطالب: إما داخل القاعة (10-25م) أو خارجها (150-500م)
      const isInside = Math.random() > 0.35; 
      
      let studentLat, studentLng;
      if (isInside) {
        studentLat = lectureLat + (Math.random() - 0.5) * 0.0002;
        studentLng = lectureLng + (Math.random() - 0.5) * 0.0002;
      } else {
        studentLat = lectureLat + (Math.random() + 0.003);
        studentLng = lectureLng + (Math.random() + 0.003);
      }

      // حساب المسافة الفعلية
      const distance = calculateDistance(lectureLat, lectureLng, studentLat, studentLng);
      const isAllowed = distance <= allowedRadiusMeters;

      const dummyNames = ["أحمد محمود", "سارة خالد", "عمر يوسف", "فاطمة علي", "إبراهيم حسن"];
      const randomName = dummyNames[Math.floor(Math.random() * dummyNames.length)];
      const randomID = "20230" + Math.floor(Math.random() * 90 + 10);
      const now = new Date().toLocaleTimeString('ar-SA', { hour: '2-digit', minute: '2-digit', second: '2-digit' });

      const tbody = document.getElementById("attendance-list");
      const row = document.createElement("tr");

      if (isAllowed) {
        presentCount++;
        document.getElementById("present-count").innerText = presentCount;
        document.getElementById("attendance-rate").innerText = Math.round((presentCount / totalStudents) * 100) + "%";

        row.innerHTML = \`
          <td>
            <div style="display: flex; align-items: center; gap: 10px;">
              <div class="avatar">\${randomName[0]}</div>
              <div><strong>\${randomName}</strong><br><small style="color: #64748b;">\${randomID}</small></div>
            </div>
          </td>
          <td>\${now}</td>
          <td><span style="color: #10b981; font-weight: 500;">📍 ضمن النطاق (\${distance}م - مقبول)</span></td>
          <td><span class="badge badge-success">حاضر (داخل القاعة)</span></td>
        \`;
      } else {
        row.innerHTML = \`
          <td>
            <div style="display: flex; align-items: center; gap: 10px;">
              <div class="avatar" style="background: #fee2e2; color: #ef4444;">\${randomName[0]}</div>
              <div><strong>\${randomName}</strong><br><small style="color: #64748b;">\${randomID}</small></div>
            </div>
          </td>
          <td>\${now}</td>
          <td><span style="color: #ef4444; font-weight: 500;">❌ خارج النطاق (\${distance}م - خارج الكلية)</span></td>
          <td><span class="badge badge-danger">مرفوض (خارج النطاق)</span></td>
        \`;
      }

      tbody.insertBefore(row, tbody.firstChild);
    }
  </script>
</body>
</html>`,
    },
    'code-html-academic': {
      filename: 'academic_management.html',
      language: 'html',
      content: `<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <title>نظام إدارة الحضور والغياب الأكاديمي</title>
    <style>
        :root {
            --bg-color: #f4f6f9;
            --card-bg: #ffffff;
            --text-color: #333333;
            --accent-color: #3498db;
            --border-color: #dddddd;
        }
        body { font-family: Tahoma, sans-serif; background: var(--bg-color); color: var(--text-color); padding: 20px; }
        .card { background: var(--card-bg); padding: 20px; border-radius: 10px; box-shadow: 0 4px 6px rgba(0,0,0,0.05); margin-bottom: 20px; }
        .btn { padding: 10px 15px; border: none; border-radius: 6px; cursor: pointer; font-weight: bold; }
        input[type="text"] { padding: 10px; border-radius: 8px; border: 1px solid var(--border-color); width: 100%; box-sizing: border-box; }
    </style>
</head>
<body>

    <!-- 1. قسم وضع تفويض المساعد أو المعيد (TA Proxy Mode) -->
    <div class="card">
        <h3 style="color: var(--accent-color);">👥 وضع تفويض المساعد أو المعيد (TA Proxy Mode)</h3>
        <p style="font-size: 0.85rem; opacity: 0.7;">منح صلاحية مؤقتة لمعيد المادة لإدارة القاعة مع التوثيق الكامل في سجل التدقيق:</p>
        <div style="display: flex; gap: 10px; margin-top: 15px;">
            <input type="text" id="assistantNameInput" placeholder="أدخل اسم المعيد المفوض...">
            <button class="btn" style="background: var(--accent-color); color: white;" onclick="activateProxyMode()">تفعيل وتفويض</button>
        </div>
        <div id="proxyStatus" style="margin-top: 10px; font-size: 0.85rem; font-weight: bold;"></div>
    </div>

    <!-- 2. قسم التقييم الفوري للمحاضرة (يظهر للطالب) -->
    <div class="card" id="feedbackCard">
        <h3 style="color: var(--accent-color);">⭐ تقييم استيعاب محاضرة اليوم</h3>
        <p style="font-size: 0.85rem; opacity: 0.7;">ما مدى استيعابك لمحاضرة اليوم من 1 إلى 10؟</p>
        <div style="display: flex; gap: 10px; margin-top: 15px; align-items: center;">
            <input type="range" id="scoreRange" min="1" max="10" value="8" style="flex: 1;" oninput="document.getElementById('scoreVal').innerText = this.value">
            <span id="scoreVal" style="font-weight: bold; font-size: 1.2rem; color: var(--accent-color);">8</span>
        </div>
        <button class="btn" style="background: var(--accent-color); color: white; margin-top: 15px;" onclick="submitLectureFeedback()">إرسال التقييم</button>
        <div id="feedbackMsg" style="margin-top: 10px; font-weight: bold;"></div>
    </div>

    <!-- 3. قسم منح نقاط المشاركة للأستاذ -->
    <div class="card">
        <h3 style="color: var(--accent-color);">🏆 نظام نقاط التفاعل والمشاركة الأكاديمية</h3>
        <p style="font-size: 0.85rem; opacity: 0.7;">منح نقطة تميز إضافية للطالب المشارك في المحاضرة:</p>
        <div style="display: flex; gap: 10px; margin-top: 15px;">
            <input type="text" id="participatingStudentId" placeholder="رقم الطالب الجامعي...">
            <button class="btn" style="background: #27ae60; color: white;" onclick="awardPoint()">منح نقطة ⭐</button>
        </div>
        <div id="pointMsg" style="margin-top: 10px; font-weight: bold; font-size: 0.85rem;"></div>
    </div>

    <!-- 4. قسم تسجيل الحضور بالكود الخاص (يظهر للطالب) -->
    <div class="card" style="max-width: 400px; margin: auto;">
        <h3 style="color: #2c3e50; text-align: center;">🔐 تسجيل الحضور بالكود الشخصي</h3>
        <p style="font-size: 0.85rem; opacity: 0.7; text-align: center;">أدخل رقمك الجامعي وكودك السري الخاص لتسجيل حضورك:</p>
        
        <div style="display: flex; flex-direction: column; gap: 10px; margin-top: 15px;">
            <input type="text" id="studentUniId" placeholder="الرقم الجامعي (مثال: 2320063)">
            <input type="password" id="studentSecretCode" placeholder="الكود السري الخاص بك..." style="padding: 10px; border-radius: 8px; border: 1px solid #ddd; width: 100%; box-sizing: border-box;">
            <button class="btn" style="background: #2c3e50; color: white;" onclick="submitPersonalCode()">تأكيد وتسجيل الحضور</button>
        </div>
        <div id="codeMsg" style="margin-top: 10px; text-align: center; font-weight: bold; font-size: 0.85rem;"></div>
    </div>

    <!-- 5. قسم سجل الحضور الفني المباشر مع الصور (يظهر في لوحة الأستاذ) -->
    <div class="card" style="margin-top: 20px;">
        <h3 style="color: #3498db;">📸 بث الحضور المباشر بالصور</h3>
        <p style="font-size: 0.85rem; opacity: 0.7;">الطلاب الذين يسجلون حضورهم الآن ستظهر صورهم هنا فوراً:</p>
        
        <!-- حاوية عرض الطلاب الحاضرين بالصور -->
        <div id="liveAttendanceFeed" style="display: flex; gap: 15px; flex-wrap: wrap; margin-top: 15px;">
            <span style="color: gray; font-size: 0.9rem;">في انتظار تسجيل أول طالب...</span>
        </div>
    </div>

    <script>
        // دالة تفويض المعيد
        function activateProxyMode() {
            let assistantName = document.getElementById('assistantNameInput').value;
            if (!assistantName) { alert("الرجاء إدخال اسم المعيد أولاً."); return; }

            fetch('/api/assistant-action', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ lecture_id: 1, assistant_name: assistantName, action_performed: 'فتح القاعة وتفعيل الباركود' })
            })
            .then(res => res.json())
            .then(data => {
                document.getElementById('proxyStatus').innerHTML = '✅ تم منح الصلاحية للمعيد: <b>' + assistantName + '</b> وتوثيق العملية.';
            });
        }

        // دالة إرسال تقييم المحاضرة
        function submitLectureFeedback() {
            let score = document.getElementById('scoreRange').value;
            fetch('/api/submit-feedback', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ lecture_id: 1, student_id: 1, understanding_score: parseInt(score) })
            })
            .then(res => res.json())
            .then(data => {
                document.getElementById('feedbackMsg').innerHTML = '<span style="color: green;">✅ ' + data.message + '</span>';
            });
        }

        // دالة منح نقاط التفاعل
        function awardPoint() {
            let studentIdInput = document.getElementById('participatingStudentId').value;
            if (!studentIdInput) { alert("الرجاء إدخال رقم الطالب."); return; }

            fetch('/api/add-participation-point', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ student_id: parseInt(studentIdInput), course_id: 1, reason: 'مشاركة ممتازة' })
            })
            .then(res => res.json())
            .then(data => {
                document.getElementById('pointMsg').innerHTML = '<span style="color: #27ae60;">✅ ' + data.message + '</span>';
                document.getElementById('participatingStudentId').value = '';
            });
        }

        // دالة إرسال الكود الشخصي للخادم
        function submitPersonalCode() {
            let uniId = document.getElementById('studentUniId').value;
            let secretCode = document.getElementById('studentSecretCode').value;

            if (!uniId || !secretCode) {
                alert("الرجاء إدخال الرقم الجامعي والكود السري.");
                return;
            }

            fetch('/api/verify-student-code', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ university_id: uniId, secret_code: secretCode, lecture_id: 1 })
            })
            .then(res => res.json())
            .then(data => {
                let msgDiv = document.getElementById('codeMsg');
                if (data.error) {
                    msgDiv.innerHTML = \`<span style="color: #e74c3c;">❌ \${data.error}</span>\`;
                } else {
                    msgDiv.innerHTML = \`<span style="color: #27ae60;">✅ أهلاً بك يا \${data.student_name}، \${data.message}</span>\`;
                }
            });
        }

        // دالة محاكاة لتسجيل حضور الطالب وعرض صورته فوراً عند الأستاذ
        function simulateStudentCheckIn(studentId) {
            fetch('/api/check-in', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ student_id: studentId, lecture_id: 1 })
            })
            .then(res => res.json())
            .then(data => {
                if (data.student_name) {
                    let feedContainer = document.getElementById('liveAttendanceFeed');
                    if (feedContainer.innerHTML.includes('في انتظار')) {
                        feedContainer.innerHTML = '';
                    }

                    let studentCard = document.createElement('div');
                    studentCard.style.cssText = "display: flex; align-items: center; background: #f8f9fa; border: 1px solid #ddd; padding: 10px; border-radius: 8px; gap: 10px; animation: fadeIn 0.5s;";
                    studentCard.innerHTML = \`
                        <img src="\${data.photo_url}" alt="صورة الطالب" style="width: 45px; height: 45px; border-radius: 50%; object-fit: cover; border: 2px solid #3498db;">
                        <div>
                            <h4 style="margin: 0; font-size: 0.9rem; color: #333;">\${data.student_name}</h4>
                            <span style="font-size: 0.75rem; color: #27ae60; font-weight: bold;">● تم الحضور</span>
                        </div>
                    \`;
                    feedContainer.prepend(studentCard);
                }
            });
        }
    </script>
</body>
</html>`,
    },
  };

  return (
    <div className="max-w-6xl mx-auto p-4 sm:p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between gap-4 flex-wrap border-b border-slate-200 dark:border-slate-800 pb-4">
        <div>
          <h1 className="text-xl sm:text-2xl font-bold text-slate-900 dark:text-white tracking-tight">
            استوديو قاعدة البيانات والأكواد المصدرية
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1">
            مخطط الجداول العلاقات، القيود الأمنية، والأكواد المصدرية الكاملة للمشروع
          </p>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex items-center gap-2 border-b border-slate-200 dark:border-slate-800 pb-2 overflow-x-auto no-scrollbar">
        <button
          onClick={() => setActiveTab('schema')}
          className={`flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs sm:text-sm font-semibold transition-all whitespace-nowrap cursor-pointer ${
            activeTab === 'schema'
              ? 'bg-blue-600 text-white shadow-sm'
              : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-900'
          }`}
        >
          <Database className="w-4 h-4" />
          <span>مخطط الجداول (Schema)</span>
        </button>

        <button
          onClick={() => setActiveTab('code-sql')}
          className={`flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs sm:text-sm font-semibold transition-all whitespace-nowrap cursor-pointer ${
            activeTab === 'code-sql'
              ? 'bg-blue-600 text-white shadow-sm'
              : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-900'
          }`}
        >
          <Table className="w-4 h-4" />
          <span>schema.sql</span>
        </button>

        <button
          onClick={() => setActiveTab('code-sqlalchemy')}
          className={`flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs sm:text-sm font-semibold transition-all whitespace-nowrap cursor-pointer ${
            activeTab === 'code-sqlalchemy'
              ? 'bg-blue-600 text-white shadow-sm'
              : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-900'
          }`}
        >
          <Code2 className="w-4 h-4 text-emerald-400" />
          <span>models.py (Flask-SQLAlchemy)</span>
        </button>

        <button
          onClick={() => setActiveTab('code-python')}
          className={`flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs sm:text-sm font-semibold transition-all whitespace-nowrap cursor-pointer ${
            activeTab === 'code-python'
              ? 'bg-blue-600 text-white shadow-sm'
              : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-900'
          }`}
        >
          <Code2 className="w-4 h-4" />
          <span>app.py (Flask + Sync)</span>
        </button>

        <button
          onClick={() => setActiveTab('code-js-offline')}
          className={`flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs sm:text-sm font-semibold transition-all whitespace-nowrap cursor-pointer ${
            activeTab === 'code-js-offline'
              ? 'bg-blue-600 text-white shadow-sm'
              : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-900'
          }`}
        >
          <Layers className="w-4 h-4" />
          <span>offline_sync.js</span>
        </button>

        <button
          onClick={() => setActiveTab('code-html-academic')}
          className={`flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs sm:text-sm font-semibold transition-all whitespace-nowrap cursor-pointer ${
            activeTab === 'code-html-academic'
              ? 'bg-blue-600 text-white shadow-sm'
              : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-900'
          }`}
        >
          <Award className="w-4 h-4 text-emerald-400" />
          <span>academic_management.html (الواجهة الأكاديمية الشاملة)</span>
        </button>

        <button
          onClick={() => setActiveTab('code-html-geo')}
          className={`flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs sm:text-sm font-semibold transition-all whitespace-nowrap cursor-pointer ${
            activeTab === 'code-html-geo'
              ? 'bg-blue-600 text-white shadow-sm'
              : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-900'
          }`}
        >
          <MapPin className="w-4 h-4 text-emerald-400" />
          <span>live_screen_geo.html (مع التحقق الجغرافي GPS)</span>
        </button>

        <button
          onClick={() => setActiveTab('code-html-v2')}
          className={`flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs sm:text-sm font-semibold transition-all whitespace-nowrap cursor-pointer ${
            activeTab === 'code-html-v2'
              ? 'bg-blue-600 text-white shadow-sm'
              : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-900'
          }`}
        >
          <Sparkles className="w-4 h-4 text-amber-400" />
          <span>live_screen_v2.html (المطور)</span>
        </button>

        <button
          onClick={() => setActiveTab('code-html-dashboard')}
          className={`flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs sm:text-sm font-semibold transition-all whitespace-nowrap cursor-pointer ${
            activeTab === 'code-html-dashboard'
              ? 'bg-blue-600 text-white shadow-sm'
              : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-900'
          }`}
        >
          <Monitor className="w-4 h-4" />
          <span>dashboard_standalone.html</span>
        </button>

        <button
          onClick={() => setActiveTab('code-html-screen')}
          className={`flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs sm:text-sm font-semibold transition-all whitespace-nowrap cursor-pointer ${
            activeTab === 'code-html-screen'
              ? 'bg-blue-600 text-white shadow-sm'
              : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-900'
          }`}
        >
          <FileText className="w-4 h-4" />
          <span>live_screen.html</span>
        </button>
      </div>

      {/* Tab 1: Visual Schema */}
      {activeTab === 'schema' && (
        <div className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {schemaTables.map((tbl) => (
              <div
                key={tbl.name}
                className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl overflow-hidden shadow-sm flex flex-col"
              >
                <div className="p-3.5 bg-slate-50 dark:bg-slate-950/80 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between">
                  <div>
                    <h3 className="font-bold text-sm text-slate-900 dark:text-white font-mono">{tbl.name}</h3>
                    <span className="text-[11px] text-slate-500 dark:text-slate-400">{tbl.arabicName}</span>
                  </div>
                  <Layers className="w-4 h-4 text-blue-500 dark:text-blue-400" />
                </div>

                <div className="p-3 divide-y divide-slate-100 dark:divide-slate-800/60 flex-1">
                  {tbl.columns.map((col) => (
                    <div
                      key={col.name}
                      className="py-2 flex items-start justify-between text-xs gap-2"
                    >
                      <div>
                        <div className="flex items-center gap-1.5 font-mono">
                          {col.isPk && (
                            <span title="Primary Key">
                              <Key className="w-3 h-3 text-amber-500 dark:text-amber-400 shrink-0" />
                            </span>
                          )}
                          {col.isFk && (
                            <span className="text-[10px] bg-blue-500/10 text-blue-600 dark:text-blue-400 px-1 rounded font-bold">
                              FK
                            </span>
                          )}
                          <span className={col.isPk ? 'text-amber-600 dark:text-amber-300 font-bold' : 'text-slate-800 dark:text-slate-200'}>
                            {col.name}
                          </span>
                        </div>
                        <p className="text-[10px] text-slate-500 dark:text-slate-400 mt-0.5">{col.desc}</p>
                      </div>
                      <span className="text-[10px] font-mono text-slate-600 dark:text-slate-400 bg-slate-100 dark:bg-slate-800/80 px-1.5 py-0.5 rounded shrink-0">
                        {col.type}
                      </span>
                    </div>
                  ))}

                  {tbl.constraints && (
                    <div className="pt-2 text-[10px] text-emerald-600 dark:text-emerald-400 font-mono">
                      {tbl.constraints.map((c, i) => (
                        <div key={i}>{c}</div>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Code Tabs */}
      {activeTab !== 'schema' && codeFiles[activeTab] && (
        <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden shadow-xl">
          <div className="p-3.5 bg-slate-950 border-b border-slate-800 flex items-center justify-between">
            <span className="font-mono text-xs text-blue-400 font-bold">
              {codeFiles[activeTab].filename}
            </span>
            <button
              onClick={() => handleCopy(activeTab, codeFiles[activeTab].content)}
              className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-xs font-semibold text-slate-200 rounded-lg transition-colors cursor-pointer"
            >
              {copiedKey === activeTab ? (
                <>
                  <Check className="w-3.5 h-3.5 text-emerald-400" />
                  <span className="text-emerald-400">تم النسخ</span>
                </>
              ) : (
                <>
                  <Copy className="w-3.5 h-3.5" />
                  <span>نسخ الكود</span>
                </>
              )}
            </button>
          </div>
          <pre className="p-4 text-xs font-mono text-slate-200 overflow-x-auto text-left dir-ltr bg-slate-950/70 leading-relaxed max-h-[500px]">
            {codeFiles[activeTab].content}
          </pre>
        </div>
      )}
    </div>
  );
};
