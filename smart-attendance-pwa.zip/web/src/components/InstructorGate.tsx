import React, { useEffect, useState, useSyncExternalStore } from 'react';
import { Lock, Loader2, LogOut, UserCog, Users } from 'lucide-react';
import { useAttendance } from '../context/AttendanceContext';
import {
  errorMessage,
  getAuthInfo,
  isInstructorLoggedIn,
  login,
  loginAssistant,
  logout,
  subscribeAuth,
} from '../services/api';

interface InstructorGateProps {
  children: React.ReactNode;
  /** يسمح للمعيد المفوَّض (بتفويض مؤقت لمحاضرة واحدة) بدخول هذه الصفحة. */
  allowAssistant?: boolean;
}

const fieldClass =
  'w-full bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl px-3 py-2.5 text-sm text-slate-900 dark:text-white outline-none focus:border-blue-500';

/**
 * يحمي واجهات الإدارة: لا يُعرض المحتوى قبل تسجيل الدخول على الخادم.
 * المحاضر بكلمة المرور، والمعيد بكود تفويض مؤقت يخص محاضرة واحدة.
 * (الخادم هو من يفرض الصلاحيات فعلاً؛ هذا المكوّن للعرض فقط.)
 */
export const InstructorGate: React.FC<InstructorGateProps> = ({ children, allowAssistant = false }) => {
  const loggedIn = useSyncExternalStore(subscribeAuth, isInstructorLoggedIn, () => false);
  const info = useSyncExternalStore(subscribeAuth, getAuthInfo, () => null);
  const { lectures, selectedLectureId, selectedCourseId, setSelectedLectureId, setSelectedCourseId } = useAttendance();

  const [mode, setMode] = useState<'instructor' | 'assistant'>('instructor');
  const [secret, setSecret] = useState<string>('');
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState<boolean>(false);

  const assistantLectureId = info?.role === 'assistant' ? info.lectureId : undefined;
  const assistantExpiresAt = info?.role === 'assistant' ? info.expiresAt : undefined;

  // المعيد مقيَّد بمحاضرته: نثبّت اختيار المحاضرة والمقرر عليها
  useEffect(() => {
    if (assistantLectureId === undefined) return;
    const lec = lectures.find((l) => l.lecture_id === assistantLectureId);
    if (!lec) return;
    if (selectedLectureId !== lec.lecture_id) setSelectedLectureId(lec.lecture_id);
    if (selectedCourseId !== lec.course_id) setSelectedCourseId(lec.course_id);
  }, [assistantLectureId, lectures, selectedLectureId, selectedCourseId, setSelectedLectureId, setSelectedCourseId]);

  // خروج تلقائي عند نهاية مدة التفويض (والخادم يرفض الطلبات بعدها أصلاً)
  useEffect(() => {
    if (!assistantExpiresAt) return;
    const wait = Math.max(0, assistantExpiresAt - Date.now());
    const id = setTimeout(logout, Math.min(wait, 2_147_000_000));
    return () => clearTimeout(id);
  }, [assistantExpiresAt]);

  if (loggedIn && info) {
    if (info.role === 'assistant' && !allowAssistant) {
      return (
        <div className="max-w-sm mx-auto p-6 mt-10">
          <div className="bg-white dark:bg-slate-900 border border-amber-500/30 rounded-2xl p-6 shadow-sm space-y-3 text-center">
            <Users className="w-6 h-6 text-amber-500 mx-auto" />
            <h2 className="font-bold text-slate-900 dark:text-white">هذه الصفحة للمحاضر فقط</h2>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              أنت مسجّل كمعيد مفوَّض ({info.assistantName}) لمحاضرة #{info.lectureId}. صلاحيتك تشمل شاشة الحضور المباشر
              والتحضير اليدوي لتلك المحاضرة فقط.
            </p>
            <button
              type="button"
              onClick={logout}
              className="px-4 py-2 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-xs font-semibold rounded-lg text-slate-700 dark:text-slate-200 cursor-pointer"
            >
              تسجيل الخروج
            </button>
          </div>
        </div>
      );
    }

    return (
      <>
        <div className="max-w-6xl mx-auto px-4 sm:px-6 pt-3 flex items-center justify-end gap-3 flex-wrap">
          {info.role === 'assistant' && (
            <span className="text-[11px] bg-blue-500/10 text-blue-600 dark:text-blue-300 border border-blue-500/25 px-2.5 py-1 rounded-full font-semibold flex items-center gap-1.5">
              <Users className="w-3.5 h-3.5" />
              معيد مفوَّض: {info.assistantName} · محاضرة #{info.lectureId}
              {info.expiresAt ? ` · ينتهي ${new Date(info.expiresAt).toLocaleTimeString('ar-SA')}` : ''}
            </span>
          )}
          <button
            type="button"
            onClick={logout}
            className="flex items-center gap-1.5 text-xs text-slate-500 hover:text-rose-500 transition-colors cursor-pointer"
          >
            <LogOut className="w-3.5 h-3.5" />
            <span>{info.role === 'assistant' ? 'إنهاء جلسة المعيد' : 'تسجيل خروج المحاضر'}</span>
          </button>
        </div>
        {children}
      </>
    );
  }

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!secret.trim() || busy) return;
    setBusy(true);
    setError(null);
    try {
      if (mode === 'assistant') await loginAssistant(secret);
      else await login(secret);
      setSecret('');
    } catch (err) {
      setError(errorMessage(err, 'تعذر تسجيل الدخول'));
    } finally {
      setBusy(false);
    }
  };

  const tabClass = (active: boolean) =>
    `flex-1 py-2 rounded-lg text-xs font-bold flex items-center justify-center gap-1.5 cursor-pointer transition-colors ${
      active
        ? 'bg-white dark:bg-slate-700 text-blue-600 dark:text-blue-300 shadow-sm'
        : 'text-slate-500 dark:text-slate-400 hover:text-slate-700 dark:hover:text-slate-200'
    }`;

  return (
    <div className="max-w-sm mx-auto p-6 mt-10">
      <form
        onSubmit={submit}
        className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 shadow-sm space-y-4"
      >
        <div className="flex items-center gap-2">
          <Lock className="w-5 h-5 text-blue-500" />
          <h2 className="font-bold text-slate-900 dark:text-white">تسجيل الدخول</h2>
        </div>

        {allowAssistant && (
          <div className="flex gap-1 p-1 bg-slate-100 dark:bg-slate-800 rounded-xl">
            <button
              type="button"
              className={tabClass(mode === 'instructor')}
              onClick={() => {
                setMode('instructor');
                setError(null);
                setSecret('');
              }}
            >
              <UserCog className="w-3.5 h-3.5" />
              المحاضر
            </button>
            <button
              type="button"
              className={tabClass(mode === 'assistant')}
              onClick={() => {
                setMode('assistant');
                setError(null);
                setSecret('');
              }}
            >
              <Users className="w-3.5 h-3.5" />
              معيد مفوَّض
            </button>
          </div>
        )}

        <p className="text-xs text-slate-500 dark:text-slate-400">
          {mode === 'assistant'
            ? 'أدخل كود التفويض الذي سلّمه لك المحاضر. صلاحيتك مؤقتة وتخص محاضرة واحدة فقط.'
            : 'هذه الصفحة تتطلب كلمة مرور المحاضر. يتم التحقق منها على الخادم.'}
        </p>

        <input
          type={mode === 'assistant' ? 'text' : 'password'}
          value={secret}
          onChange={(e) => setSecret(mode === 'assistant' ? e.target.value.toUpperCase() : e.target.value)}
          autoComplete={mode === 'assistant' ? 'off' : 'current-password'}
          placeholder={mode === 'assistant' ? 'كود التفويض (مثال: 7-K3M9QX2WPA)' : 'كلمة مرور المحاضر'}
          dir={mode === 'assistant' ? 'ltr' : undefined}
          className={`${fieldClass} ${mode === 'assistant' ? 'font-mono tracking-wider' : ''}`}
        />

        {error && (
          <div className="p-2.5 rounded-lg text-xs font-medium bg-rose-500/10 text-rose-600 dark:text-rose-300 border border-rose-500/20">
            {error}
          </div>
        )}
        <button
          type="submit"
          disabled={busy || !secret.trim()}
          className="w-full px-4 py-2.5 bg-blue-600 hover:bg-blue-500 disabled:opacity-60 text-white rounded-xl text-sm font-bold flex items-center justify-center gap-2 cursor-pointer"
        >
          {busy && <Loader2 className="w-4 h-4 animate-spin" />}
          <span>دخول</span>
        </button>
      </form>
    </div>
  );
};
