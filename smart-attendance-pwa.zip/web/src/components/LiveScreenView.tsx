import React, { useState, useEffect, useRef, useMemo, useSyncExternalStore } from 'react';
import QRCode from 'qrcode';
import confetti from 'canvas-confetti';
import {
  ShieldCheck,
  Maximize2,
  Minimize2,
  Users,
  Timer,
  CheckCircle2,
  AlertCircle,
  ExternalLink,
  Sparkles,
  MapPin,
  Navigation,
  Compass,
  ShieldAlert,
  UserCheck,
  History,
  UserX,
  Lock,
} from 'lucide-react';
import { useAttendance } from '../context/AttendanceContext';
import { DEFAULT_STUDENT_PHOTO_URL } from '../data/initialData';
import type { RecentScanEvent } from '../types/attendance';
import {
  useLectureDetails,
  useLiveSession,
  useFeedbackStats,
  useDelegations,
  useAssistantLog,
} from '../hooks/useServerAttendance';
import { getAuthInfo, subscribeAuth } from '../services/api';

interface LiveScreenViewProps {
  onOpenScanner?: () => void;
}

export const LiveScreenView: React.FC<LiveScreenViewProps> = ({ onOpenScanner }) => {
  const {
    courses,
    lectures,
    selectedCourseId,
    selectedLectureId,
    students,
    enrollments,
  } = useAttendance();

  const [qrDataUrl, setQrDataUrl] = useState<string>('');
  const [secondsRemaining, setSecondsRemaining] = useState<number>(0);
  const [isFullscreen, setIsFullscreen] = useState<boolean>(false);
  const [simulatedStudentId, setSimulatedStudentId] = useState<number>(1);
  const [testResult, setTestResult] = useState<{ success: boolean; message: string } | null>(null);
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const [toastPhotoUrl, setToastPhotoUrl] = useState<string | null>(null);

  // TA Proxy Mode State
  const [assistantNameInput, setAssistantNameInput] = useState<string>('');
  const [delegationMinutes, setDelegationMinutes] = useState<number>(120);
  const [issuedCode, setIssuedCode] = useState<{ name: string; code: string } | null>(null);
  const [proxyStatus, setProxyStatus] = useState<string | null>(null);
  const [isActivatingProxy, setIsActivatingProxy] = useState<boolean>(false);
  const [showAuditLogsModal, setShowAuditLogsModal] = useState<boolean>(false);

  // Participation Award State matching user HTML #participatingStudentId & awardPoint()
  const [participatingStudentInput, setParticipatingStudentInput] = useState<string>('');
  const [pointMsg, setPointMsg] = useState<string | null>(null);

  const feedbackStats = useFeedbackStats(selectedLectureId);

  // من يستخدم الشاشة: المحاضر (صلاحية كاملة) أو معيد مفوَّض لمحاضرة واحدة
  const auth = useSyncExternalStore(subscribeAuth, getAuthInfo, () => null);
  const isInstructor = auth?.role === 'instructor';
  const {
    delegations: allDelegations,
    active: activeDelegations,
    error: delegationError,
    create: createDelegationFor,
    revoke: revokeDelegationById,
  } = useDelegations(selectedLectureId, isInstructor);
  const { logs: auditLogs, reload: reloadAuditLogs } = useAssistantLog(selectedLectureId);

  // نفس شكل الحالة القديمة كي تبقى واجهة اللافتة كما هي، لكن المصدر الآن تفويضات الخادم الحقيقية
  const taProxySession = useMemo(() => {
    if (auth?.role === 'assistant') {
      return {
        assistantName: auth.assistantName ?? '',
        actionSummary: auth.expiresAt ? `تفويض مؤقت ينتهي ${new Date(auth.expiresAt).toLocaleTimeString('ar-SA')}` : 'تفويض مؤقت',
      };
    }
    if (isInstructor && activeDelegations.length > 0) {
      const soonest = Math.min(...activeDelegations.map((d) => Date.parse(d.expiresAt)));
      return {
        assistantName: activeDelegations.map((d) => d.assistantName).join('، '),
        actionSummary: `ينتهي أقرب تفويض ${new Date(soonest).toLocaleTimeString('ar-SA')}`,
      };
    }
    return null;
  }, [auth, isInstructor, activeDelegations]);

  const handleAwardPoint = async (studentId: number, studentName: string) => {
    const res = await addPoint(studentId, 'مشاركة وتفاعل إيجابي في المحاضرة');
    if (!res.ok) {
      setToastMessage(`❌ ${res.message}`);
      return;
    }
    setToastMessage(`🌟 ${res.message}`);
    try {
      confetti({ particleCount: 35, spread: 55, origin: { y: 0.65 } });
    } catch {
      // ignore
    }
  };

  const handleAwardPointById = async () => {
    if (!participatingStudentInput.trim()) {
      setPointMsg('⚠️ الرجاء إدخال رقم الطالب الجامعي أو اختياره أولاً.');
      return;
    }
    const trimmed = participatingStudentInput.trim();
    const foundStudent = students.find(
      (s) => s.university_id === trimmed || String(s.student_id) === trimmed || s.full_name.includes(trimmed)
    );

    if (!foundStudent) {
      setPointMsg(`❌ لم يتم العثور على طالب مطابق للمدخل: ${trimmed}`);
      return;
    }

    const res = await addPoint(foundStudent.student_id, 'مشاركة ممتازة وتفاعل نشط');
    if (!res.ok) {
      setPointMsg(`❌ ${res.message}`);
      return;
    }
    setPointMsg(`✅ ${res.message} (${foundStudent.university_id})`);
    setParticipatingStudentInput('');
    try {
      confetti({ particleCount: 45, spread: 60, origin: { y: 0.65 } });
    } catch {
      // ignore
    }
  };

  const containerRef = useRef<HTMLDivElement>(null);
  const prevScanIdRef = useRef<string | null>(null);

  // مصدر البيانات: الخادم الآمن (الكشف يُحدَّث كل 3 ثوانٍ، والرمز يُجلب مع نهاية كل نافذة)
  const {
    lecture,
    course,
    studentsWithStatus,
    loaded: rosterLoaded,
    error: rosterError,
    updateStatus,
    addPoint,
  } = useLectureDetails(selectedLectureId, 3000);
  const {
    isOpen: sessionOpen,
    live,
    error: sessionError,
    busy: sessionBusy,
    open: openLiveSession,
    close: closeLiveSession,
  } = useLiveSession(selectedLectureId);
  const currentToken = live?.token ?? '';
  const totpInterval = live?.intervalSeconds ?? 5;

  // بث الحضور المباشر مشتق من سجلات الخادم (الأحدث أولاً)
  const recentScans: RecentScanEvent[] = useMemo(
    () =>
      studentsWithStatus
        .filter((r) => (r.status === 'Present' || r.status === 'Late') && r.recorded_at)
        .sort((a, b) => Date.parse(b.recorded_at as string) - Date.parse(a.recorded_at as string))
        .slice(0, 20)
        .map((r) => ({
          id: `${r.student.student_id}-${r.recorded_at}`,
          student_name: r.student.full_name,
          university_id: r.student.university_id,
          timestamp: new Date(r.recorded_at as string).toLocaleTimeString('ar-SA'),
          status: 'success' as const,
          message: r.status === 'Late' ? 'تم تسجيل الحضور (متأخر)' : 'تم تسجيل الحضور بنجاح',
          distance_meters: r.distance_meters ?? undefined,
          is_within_geofence: r.distance_meters != null ? true : undefined,
          photo_url: r.student.photo_url,
          verification_method: 'qr' as const,
        })),
    [studentsWithStatus]
  );

  const presentStudentsList = studentsWithStatus.filter((s) => s.status === 'Present');
  const presentCount = presentStudentsList.length;
  const totalCount = studentsWithStatus.length;
  const attendanceRate = totalCount > 0 ? Math.round((presentCount / totalCount) * 100) : 0;

  const enrolledStudents = enrollments
    .filter((e) => e.course_id === selectedCourseId)
    .map((e) => students.find((s) => s.student_id === e.student_id))
    .filter(Boolean);

  // رسم الـ QR كلما وصل رمز جديد من الخادم
  useEffect(() => {
    if (!live?.token) {
      setQrDataUrl('');
      return;
    }
    let cancelled = false;
    QRCode.toDataURL(live.token, {
      width: 320,
      margin: 1,
      color: { dark: '#0f172a', light: '#ffffff' },
      errorCorrectionLevel: 'M',
    })
      .then((url) => {
        if (!cancelled) setQrDataUrl(url);
      })
      .catch((err) => console.error('Failed to generate QR code:', err));
    return () => {
      cancelled = true;
    };
  }, [live?.token]);

  // العد التنازلي المحلي حتى انتهاء الرمز الحالي
  useEffect(() => {
    if (!live) {
      setSecondsRemaining(0);
      return;
    }
    const update = () => setSecondsRemaining(Math.max(0, (live.expiresAt - Date.now()) / 1000));
    update();
    const id = setInterval(update, 100);
    return () => clearInterval(id);
  }, [live]);

  // Handle Fullscreen toggle
  const toggleFullscreen = () => {
    if (!document.fullscreenElement) {
      containerRef.current?.requestFullscreen().catch(() => {});
      setIsFullscreen(true);
    } else {
      document.exitFullscreen().catch(() => {});
      setIsFullscreen(false);
    }
  };

  useEffect(() => {
    const handleFsChange = () => {
      setIsFullscreen(Boolean(document.fullscreenElement));
    };
    document.addEventListener('fullscreenchange', handleFsChange);
    return () => document.removeEventListener('fullscreenchange', handleFsChange);
  }, []);

  // إشعار عند وصول تسجيل حضور جديد (لا يُطلق عند أول تحميل أو عند تبديل المحاضرة)
  const feedInitRef = useRef<boolean>(false);
  useEffect(() => {
    if (!rosterLoaded) {
      feedInitRef.current = false;
      prevScanIdRef.current = null;
      return;
    }
    const latest = recentScans[0];
    if (!feedInitRef.current) {
      feedInitRef.current = true;
      prevScanIdRef.current = latest?.id ?? null;
      return;
    }
    const previousId = prevScanIdRef.current;
    prevScanIdRef.current = latest?.id ?? null;
    if (latest && previousId !== latest.id && latest.status === 'success') {
      setToastMessage(`✅ تم تسجيل حضور الطالب (${latest.student_name}) بنجاح!`);
      setToastPhotoUrl(latest.photo_url || DEFAULT_STUDENT_PHOTO_URL);
      try {
        confetti({ particleCount: 35, spread: 55, origin: { y: 0.7 } });
      } catch {
        // ignore
      }
      const timer = setTimeout(() => {
        setToastMessage(null);
        setToastPhotoUrl(null);
      }, 3500);
      return () => clearTimeout(timer);
    }
  }, [recentScans, rosterLoaded]);

  // تحضير يدوي من المحاضر (قرار موثّق على الخادم، لا يمكن للطالب تجاوزه بالمسح)
  const handleManualCheckIn = async () => {
    const student = students.find((s) => s.student_id === simulatedStudentId);
    if (!student) return;

    const res = await updateStatus(student.student_id, 'Present', 'تحضير يدوي من المحاضر');
    if (res.ok) {
      setTestResult({ success: true, message: `تم تحضير ${student.full_name} (${student.university_id}) يدوياً` });
      setToastPhotoUrl(student.photo_url || DEFAULT_STUDENT_PHOTO_URL);
      setToastMessage(`✅ تم تحضير الطالب: ${student.full_name}`);
    } else {
      setTestResult({ success: false, message: res.message || 'تعذر تسجيل الحضور' });
      setToastPhotoUrl(null);
      setToastMessage(res.message || 'تعذر تسجيل الحضور');
    }

    setTimeout(() => setTestResult(null), 4500);
    setTimeout(() => {
      setToastMessage(null);
      setToastPhotoUrl(null);
    }, 3500);
  };

  // إصدار تفويض حقيقي: كود دخول مستقل للمعيد، لمحاضرة واحدة، ينتهي تلقائياً ويمكن سحبه فوراً
  const handleActivateProxy = async () => {
    if (assistantNameInput.trim().length < 2) {
      setProxyStatus('⚠️ أدخل اسم المعيد (حرفان على الأقل).');
      return;
    }
    setIsActivatingProxy(true);
    try {
      const res = await createDelegationFor(assistantNameInput.trim(), delegationMinutes);
      if (res.ok) {
        setIssuedCode({ name: assistantNameInput.trim(), code: res.accessCode });
        setProxyStatus(`✅ تم إصدار تفويض للمعيد ${assistantNameInput.trim()} وتوثيقه في سجل التدقيق.`);
        setToastMessage(`تم تفويض المعيد: ${assistantNameInput.trim()}`);
        setAssistantNameInput('');
        reloadAuditLogs();
      } else {
        setProxyStatus(`❌ ${res.message}`);
      }
    } finally {
      setIsActivatingProxy(false);
    }
  };

  const handleRevokeDelegation = async (delegationId: number) => {
    const res = await revokeDelegationById(delegationId);
    if (res.ok) {
      setProxyStatus('تم سحب التفويض فوراً، ولم يعد كود المعيد صالحاً.');
      setToastMessage('تم سحب تفويض المعيد');
      reloadAuditLogs();
    } else {
      setProxyStatus(`❌ ${res.message}`);
    }
  };

  const handleDeactivateProxy = async () => {
    await Promise.all(activeDelegations.map((d) => revokeDelegationById(d.id)));
    setProxyStatus('تم إنهاء كل التفويضات واستعادة تحكم الأستاذ بالقاعة.');
    setToastMessage('تم إنهاء تفويض المعيد');
    reloadAuditLogs();
  };

  useEffect(() => {
    if (showAuditLogsModal) reloadAuditLogs();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [showAuditLogsModal]);

  const progressPercentage = (secondsRemaining / Math.max(1, totpInterval)) * 100;

  return (
    <div
      ref={containerRef}
      className={`min-h-[calc(100vh-120px)] bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 p-4 sm:p-6 transition-colors duration-200 relative ${
        isFullscreen ? 'fixed inset-0 z-50 p-8 overflow-y-auto bg-slate-50 dark:bg-slate-950' : ''
      }`}
    >
      {/* Active TA Proxy Banner */}
      {taProxySession && (
        <div className="max-w-6xl mx-auto mb-4 p-3 sm:p-4 bg-gradient-to-r from-blue-900/40 via-indigo-900/40 to-blue-900/40 border border-blue-500/40 rounded-2xl flex items-center justify-between gap-4 flex-wrap shadow-md animate-fade-in">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-blue-600 text-white flex items-center justify-center font-bold shrink-0 shadow-sm">
              <Users className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-xs font-bold text-blue-300">وضع تفويض المعيد مُفعّل (TA Proxy Active)</span>
                <span className="text-[10px] bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 px-2 py-0.5 rounded-full font-semibold">
                  موثق في سجل التدقيق
                </span>
              </div>
              <p className="text-xs text-slate-200 mt-0.5">
                القاعة تدار حالياً بتفويض للمعيد: <strong className="text-amber-300">{taProxySession.assistantName}</strong> · الإجراء: {taProxySession.actionSummary}
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={() => setShowAuditLogsModal(true)}
              className="px-3 py-1.5 bg-slate-800/90 hover:bg-slate-700 text-slate-200 border border-slate-700 rounded-lg text-xs font-semibold cursor-pointer flex items-center gap-1.5 transition-colors"
            >
              <History className="w-3.5 h-3.5 text-blue-400" />
              <span>سجل التدقيق ({auditLogs.length})</span>
            </button>
            {isInstructor && (
              <button
                onClick={handleDeactivateProxy}
                className="px-3 py-1.5 bg-rose-600 hover:bg-rose-500 text-white rounded-lg text-xs font-semibold cursor-pointer flex items-center gap-1.5 transition-colors shadow-sm"
              >
                <UserX className="w-3.5 h-3.5" />
                <span>إنهاء التفويض</span>
              </button>
            )}
          </div>
        </div>
      )}

      {/* Top Banner Info */}
      <div className="max-w-6xl mx-auto flex items-center justify-between gap-4 flex-wrap border-b border-slate-200 dark:border-slate-800 pb-4 mb-6">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-xl sm:text-2xl font-bold text-slate-900 dark:text-white tracking-tight">
              {course?.course_name || 'لوحة التحضير المباشرة'}
            </h1>
            <span className="text-xs bg-blue-500/10 text-blue-600 dark:text-blue-400 border border-blue-500/20 px-2 py-0.5 rounded font-mono font-semibold">
              {course?.course_code}
            </span>
          </div>
          <p className="text-sm text-slate-500 dark:text-slate-400 mt-1">
            {lecture?.topic || 'المحاضرة الحالية'} · المحاضر: {course?.instructor_name}
          </p>
        </div>

        <div className="flex items-center gap-3">
          {/* فترة التجديد يحددها الخادم (TOKEN_INTERVAL_SECONDS) ولا يمكن تغييرها من المتصفح */}
          <div className="flex items-center gap-1.5 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-lg px-3 py-1.5 text-xs shadow-sm">
            <Timer className="w-3.5 h-3.5 text-slate-400" />
            <span className="text-slate-500 dark:text-slate-400">تجديد كل:</span>
            <span className="text-blue-600 dark:text-blue-400 font-bold">{totpInterval} ثوانٍ</span>
          </div>

          {/* Fullscreen Button */}
          <button
            onClick={toggleFullscreen}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-white dark:bg-slate-900 hover:bg-slate-100 dark:hover:bg-slate-800 border border-slate-200 dark:border-slate-800 rounded-lg text-xs font-semibold text-slate-700 dark:text-slate-300 transition-colors shadow-sm cursor-pointer"
          >
            {isFullscreen ? <Minimize2 className="w-3.5 h-3.5" /> : <Maximize2 className="w-3.5 h-3.5" />}
            <span>{isFullscreen ? 'إنهاء ملء الشاشة' : 'ملء الشاشة'}</span>
          </button>
        </div>
      </div>

      {/* 2. Top KPI Cards Header (مطابق للنموذج المطور) */}
      <div className="max-w-6xl mx-auto grid grid-cols-1 sm:grid-cols-3 gap-4 mb-6">
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 shadow-sm">
          <div className="text-xs text-slate-500 dark:text-slate-400 font-medium">إجمالي الطلاب</div>
          <div className="text-3xl font-extrabold font-mono text-slate-900 dark:text-white mt-2">
            {totalCount}
          </div>
          <p className="text-[11px] text-slate-400 mt-1">الطلاب المسجلون بالقاعة</p>
        </div>

        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 shadow-sm">
          <div className="text-xs text-slate-500 dark:text-slate-400 font-medium">الحاضرون الآن</div>
          <div className="text-3xl font-extrabold font-mono text-emerald-600 dark:text-emerald-400 mt-2">
            {presentCount}
          </div>
          <p className="text-[11px] text-slate-400 mt-1">تم توثيق حضورهم بنجاح</p>
        </div>

        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 shadow-sm">
          <div className="text-xs text-slate-500 dark:text-slate-400 font-medium">نسبة الحضور</div>
          <div className="text-3xl font-extrabold font-mono text-blue-600 dark:text-blue-400 mt-2">
            {attendanceRate}%
          </div>
          <div className="w-full bg-slate-100 dark:bg-slate-800 h-2 rounded-full overflow-hidden mt-2.5">
            <div
              className="h-full bg-gradient-to-r from-blue-600 to-emerald-500 rounded-full transition-all duration-500"
              style={{ width: `${attendanceRate}%` }}
            />
          </div>
        </div>
      </div>

      {/* Main Grid: Left QR Display + Right Live Attendees */}
      <div className="max-w-6xl mx-auto grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Main Display: 1. Pulsing QR Box (5 cols) */}
        <div className="lg:col-span-5 bg-white dark:bg-slate-900/90 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 sm:p-7 flex flex-col items-center text-center shadow-sm dark:shadow-xl relative overflow-hidden">
          {/* Background subtle radial glow */}
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-64 h-64 bg-blue-600/10 rounded-full blur-3xl pointer-events-none" />

          {/* Header Tag */}
          <div className="flex items-center gap-2 text-xs font-semibold text-emerald-700 dark:text-emerald-400 bg-emerald-500/10 border border-emerald-500/20 px-3 py-1 rounded-full mb-3">
            <ShieldCheck className="w-3.5 h-3.5" />
            <span>نظام الحماية من تصوير الشاشة (Dynamic QR)</span>
          </div>

          <h2 className="text-lg sm:text-xl font-bold text-slate-900 dark:text-white mb-1">
            رمز الحضور المتغير
          </h2>
          <div className="flex items-center gap-1.5 text-xs font-bold text-rose-600 dark:text-rose-400 bg-rose-500/10 border border-rose-500/20 px-3 py-1 rounded-full mb-2">
            <MapPin className="w-3.5 h-3.5" />
            <span>⚠️ يشترط التواجد داخل القاعة (GPS) - النطاق المسموح به: {lecture?.allowed_radius_meters ?? 30}م</span>
          </div>
          <p className="text-xs text-slate-500 dark:text-slate-400 max-w-xs mb-3">
            يتجدد التشفير آلياً كل <span className="text-blue-600 dark:text-blue-400 font-bold">{totpInterval} ثوانٍ</span> لمنع الغش وتصوير الشاشة
          </p>

          {/* QR Container with Pulse Ring Animation */}
          <div className="relative p-4 bg-white rounded-2xl shadow-xl border border-slate-200 dark:border-slate-700 qr-pulse-wrapper my-2">
            {sessionOpen && qrDataUrl ? (
              <img
                src={qrDataUrl}
                alt="باركود الحضور المباشر"
                className="w-52 h-52 sm:w-60 sm:h-60 object-contain"
              />
            ) : (
              <div className="w-52 h-52 sm:w-60 sm:h-60 flex items-center justify-center text-center text-slate-500 text-sm px-4">
                {sessionOpen === false
                  ? 'جلسة الحضور مغلقة. افتحها ليظهر الرمز للطلاب.'
                  : sessionError
                  ? 'تعذر جلب الرمز من الخادم...'
                  : 'جاري جلب الرمز من الخادم...'}
              </div>
            )}
          </div>

          {/* Visual Timer Bar Container */}
          <div className="w-full max-w-xs mt-4">
            <div className="w-full bg-slate-200 dark:bg-slate-800 h-2 rounded-full overflow-hidden p-0.5 shadow-inner">
              <div
                className="h-full rounded-full transition-all duration-100 bg-blue-600 dark:bg-blue-500"
                style={{ width: `${progressPercentage}%` }}
              />
            </div>
            <small className="block mt-2 text-xs text-slate-500 dark:text-slate-400 font-mono font-medium">
              تحديث خلال <span className="font-bold text-blue-600 dark:text-blue-400">{secondsRemaining.toFixed(1)}</span> ثوانٍ
            </small>
          </div>

          {/* Monospace token display */}
          <div className="mt-3 flex items-center gap-2 text-xs text-slate-500">
            <span>رمز الأمان:</span>
            <code className="font-mono bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 px-2 py-0.5 rounded border border-slate-300 dark:border-slate-700">
              {currentToken || '...'}
            </code>
          </div>

          {/* التحكم بجلسة الحضور (على الخادم) */}
          {(sessionError || rosterError) && (
            <div className="w-full mt-3 p-2.5 rounded-lg text-xs font-medium bg-rose-500/10 text-rose-700 dark:text-rose-300 border border-rose-500/20">
              {sessionError || rosterError}
            </div>
          )}
          {sessionOpen === false ? (
            <button
              onClick={openLiveSession}
              disabled={sessionBusy}
              className="w-full mt-4 px-4 py-2.5 bg-emerald-600 hover:bg-emerald-500 disabled:opacity-60 text-white rounded-xl text-xs font-bold flex items-center justify-center gap-2 shadow-sm transition-all cursor-pointer"
            >
              <Navigation className="w-4 h-4" />
              <span>{sessionBusy ? 'جارٍ الفتح...' : 'فتح جلسة الحضور'}</span>
            </button>
          ) : sessionOpen ? (
            <button
              onClick={closeLiveSession}
              disabled={sessionBusy}
              className="w-full mt-4 px-4 py-2.5 bg-rose-600 hover:bg-rose-500 disabled:opacity-60 text-white rounded-xl text-xs font-bold flex items-center justify-center gap-2 shadow-sm transition-all cursor-pointer"
            >
              <UserX className="w-4 h-4" />
              <span>{sessionBusy ? 'جارٍ الإغلاق...' : 'إغلاق جلسة الحضور'}</span>
            </button>
          ) : null}

          {/* Direct Link to Mobile Scanner */}
          {onOpenScanner && (
            <div className="mt-4 pt-3 border-t border-slate-100 dark:border-slate-800/80 w-full flex items-center justify-center">
              <button
                onClick={onOpenScanner}
                className="flex items-center gap-2 text-xs font-medium text-blue-600 dark:text-blue-400 hover:underline cursor-pointer"
              >
                <span>فتح ماسح الطالب لاختبار المسح الآن</span>
                <ExternalLink className="w-3.5 h-3.5" />
              </button>
            </div>
          )}
        </div>

        {/* Right Column: 3. Live Photo Feed, Interactive Student Table & Quick Simulation (7 cols) */}
        <div className="lg:col-span-7 space-y-6">
          {/* 📸 قسم سجل الحضور الفني المباشر مع الصور (يظهر في لوحة الأستاذ) */}
          <div className="bg-white dark:bg-slate-900/90 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 sm:p-6 shadow-sm dark:shadow-xl">
            <div className="flex items-center justify-between gap-2 flex-wrap mb-1">
              <h3 className="font-bold text-sm sm:text-base text-blue-600 dark:text-blue-400 flex items-center gap-2">
                <span>📸 بث الحضور المباشر بالصور</span>
              </h3>
              <button
                type="button"
                onClick={handleManualCheckIn}
                className="px-3 py-1.5 bg-blue-600 hover:bg-blue-500 text-white rounded-lg text-[11px] font-bold flex items-center gap-1.5 shadow-sm transition-colors cursor-pointer"
              >
                <UserCheck className="w-3.5 h-3.5" />
                <span>+ تحضير الطالب المحدد يدوياً</span>
              </button>
            </div>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              الطلاب الذين يسجلون حضورهم الآن ستظهر صورهم هنا فوراً:
            </p>

            {/* حاوية عرض الطلاب الحاضرين بالصور (#liveAttendanceFeed) */}
            <div id="liveAttendanceFeed" className="flex gap-3.5 flex-wrap mt-4">
              {(() => {
                const checkedInFeed = recentScans.filter((s) => s.status === 'success');
                if (checkedInFeed.length === 0) {
                  return (
                    <span className="text-slate-400 dark:text-slate-500 text-xs sm:text-sm py-2">
                      في انتظار تسجيل أول طالب...
                    </span>
                  );
                }
                return checkedInFeed.map((scan) => (
                  <div
                    key={scan.id}
                    className="flex items-center gap-2.5 bg-slate-50 dark:bg-slate-800/70 border border-slate-200 dark:border-slate-700/80 px-3 py-2.5 rounded-xl shadow-xs animate-fade-in"
                  >
                    <img
                      src={scan.photo_url || DEFAULT_STUDENT_PHOTO_URL}
                      alt={scan.student_name}
                      onError={(e) => {
                        e.currentTarget.src = DEFAULT_STUDENT_PHOTO_URL;
                      }}
                      className="w-11 h-11 rounded-full object-cover border-2 border-blue-500 shrink-0 bg-slate-200 dark:bg-slate-700"
                    />
                    <div>
                      <h4 className="text-xs sm:text-sm font-bold text-slate-800 dark:text-white leading-tight">
                        {scan.student_name}
                      </h4>
                      <div className="flex items-center gap-2 mt-0.5">
                        <span className="text-[11px] text-emerald-600 dark:text-emerald-400 font-bold">
                          ● تم الحضور
                        </span>
                        <span className="text-[10px] text-slate-400 font-mono">{scan.timestamp}</span>
                      </div>
                    </div>
                  </div>
                ));
              })()}
            </div>
          </div>

          {/* Interactive Live Student Table with GPS Column */}
          <div className="bg-white dark:bg-slate-900/90 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 sm:p-6 shadow-sm dark:shadow-xl">
            <div className="flex items-center justify-between mb-4 pb-3 border-b border-slate-100 dark:border-slate-800">
              <div className="flex items-center gap-2">
                <Users className="w-4 h-4 text-blue-500" />
                <h3 className="font-bold text-sm text-slate-900 dark:text-white">سجل الحضور الفوري والتحقق الجغرافي</h3>
              </div>
              <span className="text-xs bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border border-emerald-500/20 px-2.5 py-0.5 rounded-full font-bold">
                مباشر LIVE ({presentCount})
              </span>
            </div>

            {/* Latest Checked-In Student Photo Spotlight (/api/check-in response) */}
            {recentScans[0]?.status === 'success' && (
              <div className="mb-4 p-3.5 rounded-xl bg-gradient-to-l from-emerald-500/10 via-blue-500/5 to-transparent border border-emerald-500/30 flex items-center justify-between gap-3 flex-wrap animate-fade-in">
                <div className="flex items-center gap-3">
                  <img
                    src={recentScans[0].photo_url || DEFAULT_STUDENT_PHOTO_URL}
                    alt={recentScans[0].student_name}
                    onError={(e) => {
                      e.currentTarget.src = DEFAULT_STUDENT_PHOTO_URL;
                    }}
                    className="w-12 h-12 rounded-full object-cover border-2 border-emerald-400 shadow-md shrink-0 bg-slate-800"
                  />
                  <div>
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="text-xs font-bold text-slate-900 dark:text-white">
                        {recentScans[0].student_name}
                      </span>
                      <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-700 dark:text-emerald-300 border border-emerald-500/30 font-bold">
                        تم تسجيل الحضور بنجاح
                      </span>
                    </div>
                    <p className="text-[11px] text-slate-500 dark:text-slate-400 font-mono mt-0.5">
                      الرقم الجامعي: {recentScans[0].university_id} · التوقيت: {recentScans[0].timestamp}
                    </p>
                  </div>
                </div>
                <span className="text-[10px] font-mono text-emerald-600 dark:text-emerald-400 bg-emerald-500/10 px-2 py-1 rounded border border-emerald-500/20">
                  photo_url verified
                </span>
              </div>
            )}

            {recentScans.length === 0 && presentStudentsList.length === 0 ? (
              <div className="py-12 text-center text-slate-400 dark:text-slate-500 text-xs">
                في انتظار مسح أول رمز...
              </div>
            ) : (
              <div className="overflow-x-auto max-h-[320px] overflow-y-auto pr-1">
                <table className="w-full text-right border-collapse text-xs">
                  <thead>
                    <tr className="text-slate-400 border-b border-slate-100 dark:border-slate-800 pb-2">
                      <th className="pb-2.5 font-medium">الطالب</th>
                      <th className="pb-2.5 font-medium">التوقيت</th>
                      <th className="pb-2.5 font-medium">التحقق الجغرافي (GPS)</th>
                      <th className="pb-2.5 font-medium">نقاط التفاعل</th>
                      <th className="pb-2.5 font-medium text-left">الحالة</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 dark:divide-slate-800/60">
                    {/* If recent scans exist, display them; otherwise fallback to present students */}
                    {(recentScans.length > 0 ? recentScans : presentStudentsList.map((p) => ({
                      id: String(p.student.student_id),
                      student_name: p.student.full_name,
                      university_id: p.student.university_id,
                      timestamp: p.recorded_at ? p.recorded_at.split(' ')[1] || p.recorded_at : 'الآن',
                      status: 'success' as const,
                      distance_meters: 10,
                      is_within_geofence: true,
                      photo_url: p.student.photo_url,
                      verification_method: 'qr' as const,
                      message: 'ضمن نطاق القاعة',
                    }))).map((item) => {
                      const firstChar = item.student_name ? item.student_name.trim().charAt(0) : 'ط';
                      const isSuccess = item.status === 'success';
                      const isOutOfRange = item.status === 'out_of_range';
                      const isExpired = item.status === 'expired';
                      const matchedStudent = students.find(
                        (s) => s.university_id === item.university_id || String(s.student_id) === item.id
                      );
                      const studentPoints = matchedStudent
                        ? (studentsWithStatus.find((r) => r.student.student_id === matchedStudent.student_id)?.points ?? 0)
                        : 0;
                      const avatarSrc = item.photo_url || matchedStudent?.photo_url || DEFAULT_STUDENT_PHOTO_URL;

                      return (
                        <tr key={item.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/40 transition-colors">
                          <td className="py-3">
                            <div className="flex items-center gap-2.5">
                              {avatarSrc ? (
                                <img
                                  src={avatarSrc}
                                  alt={item.student_name}
                                  onError={(e) => {
                                    e.currentTarget.src = DEFAULT_STUDENT_PHOTO_URL;
                                  }}
                                  className={`w-8 h-8 rounded-full object-cover shrink-0 shadow-sm border-2 ${
                                    isSuccess ? 'border-emerald-500/70' : isOutOfRange ? 'border-rose-500/70' : 'border-slate-500/50'
                                  }`}
                                />
                              ) : (
                                <span className={`w-8 h-8 rounded-full text-white flex items-center justify-center font-bold text-xs shrink-0 shadow-sm ${
                                  isSuccess ? 'bg-blue-600' : isOutOfRange ? 'bg-rose-600' : 'bg-slate-600'
                                }`}>
                                  {firstChar}
                                </span>
                              )}
                              <div>
                                <div className="font-semibold text-slate-900 dark:text-white flex items-center gap-1.5 flex-wrap">
                                  <span>{item.student_name}</span>
                                  {item.verification_method === 'secret_code' && (
                                    <span className="text-[10px] px-1.5 py-0.2 rounded bg-indigo-500/15 text-indigo-500 dark:text-indigo-300 border border-indigo-500/30 font-bold">
                                      🔑 كود سري
                                    </span>
                                  )}
                                </div>
                                <div className="text-[10px] text-slate-400 font-mono">
                                  {item.university_id}
                                </div>
                              </div>
                            </div>
                          </td>
                          <td className="py-3 font-mono text-slate-500 dark:text-slate-400 text-xs whitespace-nowrap">
                            {item.timestamp}
                          </td>
                          <td className="py-3 whitespace-nowrap">
                            {isSuccess ? (
                              <span className="text-emerald-600 dark:text-emerald-400 font-semibold flex items-center gap-1">
                                <span>📍 ضمن النطاق</span>
                                <span className="font-mono text-[11px]">({item.distance_meters ? `${item.distance_meters}م` : '8م'} - مقبول)</span>
                              </span>
                            ) : isOutOfRange ? (
                              <span className="text-rose-600 dark:text-rose-400 font-semibold flex items-center gap-1">
                                <span>❌ خارج النطاق</span>
                                <span className="font-mono text-[11px]">({item.distance_meters ? `${item.distance_meters}م` : '450م'} - خارج الكلية)</span>
                              </span>
                            ) : (
                              <span className="text-slate-400 text-[11px]">
                                {isExpired ? 'غير متاح (رمز منتهي)' : 'غير محدد'}
                              </span>
                            )}
                          </td>
                          <td className="py-3 whitespace-nowrap">
                            <div className="flex items-center gap-1.5">
                              <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[11px] font-bold bg-amber-500/15 text-amber-600 dark:text-amber-400 border border-amber-500/25">
                                <span>🌟</span>
                                <span>{studentPoints}</span>
                              </span>
                              {matchedStudent && (
                                <button
                                  type="button"
                                  onClick={() => handleAwardPoint(matchedStudent.student_id, matchedStudent.full_name)}
                                  className="px-2 py-0.5 rounded-md text-[10px] font-bold bg-blue-50 dark:bg-blue-900/30 text-blue-600 dark:text-blue-400 hover:bg-blue-100 dark:hover:bg-blue-900/50 transition-colors border border-blue-200 dark:border-blue-800"
                                  title="منح نقطة تميز ومشاركة (+1)"
                                >
                                  +1 🌟
                                </button>
                              )}
                            </div>
                          </td>
                          <td className="py-3 text-left whitespace-nowrap">
                            {isSuccess ? (
                              <span className="inline-block px-2.5 py-1 rounded-full text-[11px] font-bold bg-emerald-500/15 text-emerald-600 dark:text-emerald-400 border border-emerald-500/25">
                                حاضر (داخل القاعة)
                              </span>
                            ) : isOutOfRange ? (
                              <span className="inline-block px-2.5 py-1 rounded-full text-[11px] font-bold bg-rose-500/15 text-rose-600 dark:text-rose-400 border border-rose-500/25">
                                مرفوض (خارج النطاق)
                              </span>
                            ) : isExpired ? (
                              <span className="inline-block px-2.5 py-1 rounded-full text-[11px] font-bold bg-amber-500/15 text-amber-600 dark:text-amber-400 border border-amber-500/25">
                                رمز منتهي
                              </span>
                            ) : (
                              <span className="inline-block px-2.5 py-1 rounded-full text-[11px] font-bold bg-slate-500/15 text-slate-400 border border-slate-500/25">
                                فشل التحقق
                              </span>
                            )}
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            )}
          </div>

          {/* 📊 مؤشر استيعاب المحاضرة الفوري (Live Lecture Pulse) */}
          <div className="bg-white dark:bg-slate-900/90 border border-indigo-500/30 rounded-2xl p-5 shadow-sm dark:shadow-xl bg-gradient-to-r from-indigo-500/5 via-purple-500/5 to-transparent">
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center gap-2">
                <span className="text-base">📊</span>
                <h3 className="font-bold text-sm text-indigo-600 dark:text-indigo-400">مؤشر استيعاب المحاضرة الفوري (Live Lecture Pulse)</h3>
              </div>
              <span className="text-xs font-mono font-bold bg-indigo-500/10 text-indigo-600 dark:text-indigo-400 border border-indigo-500/20 px-2.5 py-0.5 rounded-full">
                {feedbackStats.count > 0 ? `${feedbackStats.count} تقييمات طلاب` : 'في انتظار التقييم'}
              </span>
            </div>
            <p className="text-xs text-slate-500 dark:text-slate-400 mb-3">
              متوسط تقييم درجة فهم واستيعاب الطلاب للمحاضرة في الوقت الفعلي (من 1 إلى 10):
            </p>

            <div className="space-y-2.5">
              <div className="flex items-baseline justify-between">
                <div className="flex items-baseline gap-1.5">
                  <span className="text-2xl font-black text-slate-900 dark:text-white font-mono">
                    {feedbackStats.average.toFixed(1)}
                  </span>
                  <span className="text-xs text-slate-400 font-bold">/ 10</span>
                </div>
                <span className="text-xs font-semibold text-slate-600 dark:text-slate-300">
                  {feedbackStats.count === 0
                    ? 'في انتظار التقييم الأول من شاشة الطالب ⏳'
                    : feedbackStats.average >= 8
                    ? 'استيعاب ممتاز ومتقن 🤩'
                    : feedbackStats.average >= 6
                    ? 'استيعاب جيد جداً 👍'
                    : 'استيعاب متوسط - يحتاج تركيز إضافي 💡'}
                </span>
              </div>
              
              {/* Progress bar */}
              <div className="w-full bg-slate-100 dark:bg-slate-800 rounded-full h-2.5 overflow-hidden">
                <div 
                  className={`h-full rounded-full transition-all duration-500 ${
                    feedbackStats.average >= 8 ? 'bg-gradient-to-r from-emerald-500 to-teal-400' :
                    feedbackStats.average >= 6 ? 'bg-gradient-to-r from-blue-500 to-indigo-500' :
                    feedbackStats.average > 0 ? 'bg-gradient-to-r from-amber-500 to-orange-400' : 'bg-slate-300'
                  }`}
                  style={{ width: `${Math.min(100, Math.max(5, (feedbackStats.average / 10) * 100))}%` }}
                />
              </div>

              <div className="flex items-center justify-between text-[11px] text-slate-400 pt-0.5">
                <span>1 (صعوبة في الفهم)</span>
                <span className="text-slate-500 dark:text-slate-400 font-medium">مستند لجدول Lecture_Feedbacks ومسار API</span>
                <span>10 (استيعاب كامل ومتقن)</span>
              </div>
            </div>
          </div>

          {/* 🌟 لوحة الشرف والتميز (حضور 100%) */}
          <div className="bg-white dark:bg-slate-900/90 border border-emerald-500/30 rounded-2xl p-5 shadow-sm dark:shadow-xl bg-gradient-to-r from-emerald-500/5 to-transparent">
            <div className="flex items-center gap-2 mb-1">
              <span className="text-base">🌟</span>
              <h3 className="font-bold text-sm text-emerald-600 dark:text-emerald-400">لوحة الشرف والتميز (حضور 100%)</h3>
            </div>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              الطلاب الأكثر انضباطاً والتزاماً بمواعيد المحاضرات والتحقق الجغرافي:
            </p>

            <div className="flex gap-2 flex-wrap mt-3">
              <div className="bg-emerald-500/10 text-emerald-700 dark:text-emerald-300 px-3 py-1.5 rounded-full border border-emerald-500/30 text-xs font-bold flex items-center gap-1.5 shadow-sm">
                <span>🏆</span>
                <span>أحمد المصراطي (منتظم دائماً)</span>
              </div>
              <div className="bg-emerald-500/10 text-emerald-700 dark:text-emerald-300 px-3 py-1.5 rounded-full border border-emerald-500/30 text-xs font-bold flex items-center gap-1.5 shadow-sm">
                <span>🏆</span>
                <span>فاطمة الفيتوري (حضور مبكر)</span>
              </div>
              {presentStudentsList.slice(0, 2).map((item) => (
                <div key={item.student.student_id} className="bg-blue-500/10 text-blue-700 dark:text-blue-300 px-3 py-1.5 rounded-full border border-blue-500/30 text-xs font-bold flex items-center gap-1.5 shadow-sm">
                  <span>⭐</span>
                  <span>{item.student.full_name} (حاضر بالقاعة)</span>
                </div>
              ))}
            </div>
          </div>

          {/* تفويض المعيد: صلاحية حقيقية مؤقتة بكود مستقل (يفرضها الخادم) */}
          <div className="card bg-white dark:bg-slate-900/90 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 shadow-sm dark:shadow-lg mt-5">
            <div className="flex items-center justify-between gap-2 mb-1 flex-wrap">
              <h3 className="font-bold text-sm sm:text-base text-blue-600 dark:text-blue-400 flex items-center gap-2">
                <span>👥 تفويض المعيد (صلاحية مؤقتة مستقلة)</span>
              </h3>
              {taProxySession ? (
                <span className="text-[11px] bg-emerald-500/15 text-emerald-600 dark:text-emerald-400 border border-emerald-500/30 px-2.5 py-0.5 rounded-full font-bold flex items-center gap-1">
                  <UserCheck className="w-3.5 h-3.5" />
                  مُفوض: {taProxySession.assistantName}
                </span>
              ) : (
                <span className="text-[11px] bg-slate-100 dark:bg-slate-800 text-slate-500 dark:text-slate-400 px-2.5 py-0.5 rounded-full font-medium">
                  صلاحية الأستاذ الرئيسية
                </span>
              )}
            </div>

            {isInstructor ? (
              <>
                <p className="text-xs text-slate-500 dark:text-slate-400">
                  أصدر كوداً خاصاً بالمعيد لإدارة <strong>هذه المحاضرة فقط</strong> (الحضور والتحضير اليدوي والنقاط) لمدة محددة.
                  لا يرى المعيد التقارير ولا الأعذار ولا الأكواد السرية، ويمكنك سحب التفويض في أي لحظة:
                </p>

                <div className="flex flex-col sm:flex-row gap-2.5 mt-3.5">
                  <input
                    type="text"
                    id="assistantNameInput"
                    value={assistantNameInput}
                    onChange={(e) => setAssistantNameInput(e.target.value)}
                    placeholder="اسم المعيد..."
                    maxLength={60}
                    className="flex-1 p-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white text-xs sm:text-sm outline-none focus:border-blue-500 transition-colors"
                  />
                  <select
                    value={delegationMinutes}
                    onChange={(e) => setDelegationMinutes(Number(e.target.value))}
                    className="bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl p-2.5 text-xs text-slate-800 dark:text-slate-200 outline-none"
                    aria-label="مدة التفويض"
                  >
                    <option value={30}>30 دقيقة</option>
                    <option value={60}>ساعة</option>
                    <option value={120}>ساعتان</option>
                    <option value={180}>3 ساعات</option>
                    <option value={240}>4 ساعات</option>
                  </select>
                  <button
                    className="px-4 py-2.5 bg-blue-600 hover:bg-blue-500 disabled:opacity-50 text-white rounded-xl text-xs sm:text-sm font-semibold transition-all cursor-pointer flex items-center justify-center gap-2 shadow-sm whitespace-nowrap"
                    onClick={handleActivateProxy}
                    disabled={isActivatingProxy}
                  >
                    <UserCheck className="w-4 h-4" />
                    <span>{isActivatingProxy ? 'جاري الإصدار...' : 'إصدار كود تفويض'}</span>
                  </button>
                </div>

                <div className="flex items-center gap-1.5 flex-wrap mt-2.5 text-[11px]">
                  <span className="text-slate-400">معيدون مقترحون:</span>
                  {['م. عمر خالد الدوسري', 'م. ريم الترهوني', 'م. سالم محمود'].map((name) => (
                    <button
                      key={name}
                      type="button"
                      onClick={() => setAssistantNameInput(name)}
                      className="px-2 py-0.5 bg-slate-100 dark:bg-slate-800 hover:bg-blue-500/10 hover:text-blue-500 text-slate-600 dark:text-slate-300 rounded-md border border-slate-200 dark:border-slate-700 transition-colors cursor-pointer"
                    >
                      + {name}
                    </button>
                  ))}
                </div>

                {issuedCode && (
                  <div className="mt-3 p-3 rounded-xl bg-amber-500/10 border border-amber-500/30 text-xs space-y-1.5">
                    <div className="font-bold text-amber-700 dark:text-amber-300">🔑 كود تفويض المعيد {issuedCode.name}</div>
                    <code
                      className="inline-block font-mono text-base font-bold tracking-widest bg-white dark:bg-slate-900 border border-amber-500/30 px-3 py-1 rounded-lg text-slate-900 dark:text-amber-300 select-all"
                      dir="ltr"
                    >
                      {issuedCode.code}
                    </code>
                    <div className="flex items-center gap-3 flex-wrap">
                      <button
                        type="button"
                        onClick={() => navigator.clipboard?.writeText(issuedCode.code).catch(() => {})}
                        className="text-blue-600 dark:text-blue-400 hover:underline font-semibold cursor-pointer"
                      >
                        نسخ الكود
                      </button>
                      <button type="button" onClick={() => setIssuedCode(null)} className="text-slate-500 hover:underline cursor-pointer">
                        إخفاء
                      </button>
                    </div>
                    <p className="text-slate-600 dark:text-slate-400">
                      يظهر هذا الكود مرة واحدة فقط ولا يمكن استرجاعه. سلّمه للمعيد الآن؛ يدخل به من تبويب «معيد مفوَّض».
                    </p>
                  </div>
                )}

                {allDelegations.length > 0 && (
                  <div className="mt-3 space-y-1.5">
                    <div className="text-[11px] font-semibold text-slate-500 dark:text-slate-400">تفويضات هذه المحاضرة:</div>
                    {allDelegations.slice(0, 6).map((d) => (
                      <div
                        key={d.id}
                        className="flex items-center justify-between gap-2 p-2 rounded-lg border border-slate-200 dark:border-slate-800 text-[11px]"
                      >
                        <div>
                          <span className="font-bold text-slate-800 dark:text-slate-200">{d.assistantName}</span>
                          <span className="text-slate-400 mr-2">
                            {d.status === 'active' ? `ينتهي ${new Date(d.expiresAt).toLocaleTimeString('ar-SA')}` : d.status === 'revoked' ? 'مسحوب' : 'منتهٍ'}
                          </span>
                        </div>
                        {d.status === 'active' ? (
                          <button
                            type="button"
                            onClick={() => handleRevokeDelegation(d.id)}
                            className="px-2 py-0.5 bg-rose-600 hover:bg-rose-500 text-white rounded-md font-bold cursor-pointer"
                          >
                            سحب
                          </button>
                        ) : (
                          <span
                            className={`px-2 py-0.5 rounded-full font-bold border ${
                              d.status === 'revoked'
                                ? 'bg-rose-500/10 text-rose-600 border-rose-500/20'
                                : 'bg-slate-500/10 text-slate-500 border-slate-500/20'
                            }`}
                          >
                            {d.status === 'revoked' ? 'مسحوب' : 'منتهٍ'}
                          </span>
                        )}
                      </div>
                    ))}
                  </div>
                )}
                {delegationError && <p className="mt-2 text-[11px] text-rose-500">⚠️ {delegationError}</p>}
              </>
            ) : (
              <p className="text-xs text-slate-600 dark:text-slate-300 mt-2">
                أنت تعمل الآن بتفويض مؤقت من المحاضر لهذه المحاضرة فقط. تنتهي صلاحيتك تلقائياً، ويمكن للمحاضر سحبها في أي لحظة،
                وكل إجراء تقوم به موثّق في سجل التدقيق.
              </p>
            )}

            {proxyStatus && (
              <div className="mt-2.5 p-3 rounded-xl text-xs font-semibold bg-emerald-500/10 text-emerald-800 dark:text-emerald-300 border border-emerald-500/25 animate-fade-in">
                {proxyStatus}
              </div>
            )}

            <div className="mt-3.5 pt-2 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between text-xs text-slate-500 dark:text-slate-400">
              <span className="flex items-center gap-1">
                <Lock className="w-3.5 h-3.5 text-blue-500" />
                <span>توثيق آلي على الخادم لكل إجراء</span>
              </span>
              <button
                type="button"
                onClick={() => setShowAuditLogsModal(true)}
                className="text-blue-600 dark:text-blue-400 hover:underline flex items-center gap-1 font-semibold cursor-pointer"
              >
                <History className="w-3.5 h-3.5" />
                <span>عرض سجل العمليات والتدقيق ({auditLogs.length})</span>
              </button>
            </div>
          </div>

          {/* 3. قسم منح نقاط المشاركة للأستاذ (Award Participation Point by Student ID) */}
          <div className="card bg-white dark:bg-slate-900/90 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 shadow-sm dark:shadow-lg mt-5">
            <h3 className="font-bold text-sm sm:text-base text-blue-600 dark:text-blue-400 flex items-center gap-2" style={{ color: 'var(--accent-color, #2563eb)' }}>
              <span>🏆 نظام نقاط التفاعل والمشاركة الأكاديمية</span>
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-1" style={{ fontSize: '0.85rem', opacity: 0.7 }}>
              منح نقطة تميز إضافية للطالب المشارك في المحاضرة:
            </p>

            <div className="flex gap-2.5 mt-3.5" style={{ display: 'flex', gap: '10px', marginTop: '15px' }}>
              <input
                type="text"
                id="participatingStudentId"
                value={participatingStudentInput}
                onChange={(e) => setParticipatingStudentInput(e.target.value)}
                placeholder="رقم الطالب الجامعي (مثال: 2023001)..."
                className="flex-1 p-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white text-xs sm:text-sm outline-none focus:border-blue-500 font-mono transition-colors"
                style={{ padding: '10px', borderRadius: '8px', border: '1px solid var(--border-color, #e2e8f0)', width: '100%', boxSizing: 'border-box' }}
              />
              <button
                className="btn px-4 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs sm:text-sm font-bold transition-all cursor-pointer flex items-center justify-center gap-1.5 shadow-sm whitespace-nowrap shrink-0"
                style={{ background: '#27ae60', color: 'white' }}
                onClick={handleAwardPointById}
              >
                <span>منح نقطة ⭐</span>
              </button>
            </div>

            {/* Quick Student Suggestions */}
            <div className="flex items-center gap-1.5 flex-wrap mt-2.5 text-[11px]">
              <span className="text-slate-400">طلاب مقترحون:</span>
              {students.slice(0, 4).map((s) => (
                <button
                  key={s.student_id}
                  type="button"
                  onClick={() => setParticipatingStudentInput(s.university_id)}
                  className="px-2 py-0.5 bg-slate-100 dark:bg-slate-800 hover:bg-blue-500/10 hover:text-blue-500 text-slate-600 dark:text-slate-300 rounded-md border border-slate-200 dark:border-slate-700 transition-colors cursor-pointer font-mono"
                >
                  {s.university_id} ({s.full_name.split(' ')[0]})
                </button>
              ))}
            </div>

            {/* Notification matching id="pointMsg" */}
            <div
              id="pointMsg"
              style={{ marginTop: '10px', fontWeight: 'bold', fontSize: '0.85rem' }}
            >
              {pointMsg && (
                <div className={`p-2.5 rounded-lg text-xs font-semibold animate-fade-in ${
                  pointMsg.startsWith('✅')
                    ? 'bg-emerald-500/10 text-emerald-700 dark:text-emerald-300 border border-emerald-500/25'
                    : 'bg-amber-500/10 text-amber-700 dark:text-amber-300 border border-amber-500/25'
                }`}>
                  {pointMsg}
                </div>
              )}
            </div>
          </div>

          {/* التحضير اليدوي السريع */}
          <div className="bg-white dark:bg-slate-900/90 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 shadow-sm dark:shadow-lg">
            <div className="flex items-center gap-2 mb-2">
              <UserCheck className="w-4 h-4 text-indigo-500" />
              <h3 className="font-bold text-sm text-slate-900 dark:text-white">التحضير اليدوي السريع</h3>
            </div>
            <p className="text-xs text-slate-500 dark:text-slate-400 mb-3">
              سجّل حضور طالب نيابةً عنه عند الحاجة. القرار يُحفظ على الخادم ويُسجَّل في سجل التدقيق، ولا يمكن تغييره بالمسح لاحقاً.
            </p>

            <div className="space-y-3">
              <div>
                <label className="text-[11px] text-slate-500 dark:text-slate-400 block mb-1">اختر الطالب:</label>
                <select
                  value={simulatedStudentId}
                  onChange={(e) => setSimulatedStudentId(Number(e.target.value))}
                  className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg p-2 text-xs text-slate-900 dark:text-white outline-none focus:border-blue-500"
                >
                  {enrolledStudents.map((s) => s && (
                    <option key={s.student_id} value={s.student_id} className="bg-white dark:bg-slate-900 text-slate-900 dark:text-white">
                      {s.full_name} ({s.university_id})
                    </option>
                  ))}
                </select>
              </div>

              <button
                onClick={handleManualCheckIn}
                className="w-full px-3 py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors shadow-sm cursor-pointer"
              >
                <UserCheck className="w-3.5 h-3.5" />
                <span>تحضير الطالب كحاضر</span>
              </button>

              {testResult && (
                <div
                  className={`p-2.5 rounded-lg text-xs font-medium flex items-center gap-2 animate-fade-in ${
                    testResult.success
                      ? 'bg-emerald-500/10 text-emerald-700 dark:text-emerald-300 border border-emerald-500/20'
                      : 'bg-rose-500/10 text-rose-700 dark:text-rose-300 border border-rose-500/20'
                  }`}
                >
                  {testResult.success ? (
                    <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-500" />
                  ) : (
                    <AlertCircle className="w-4 h-4 shrink-0 text-rose-500" />
                  )}
                  <span>{testResult.message}</span>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Floating Toast Notification with Student Photo */}
      {toastMessage && (
        <div className="fixed bottom-6 left-6 z-50 bg-white dark:bg-slate-900 text-slate-900 dark:text-white px-4 py-3 rounded-xl border-r-4 border-emerald-500 shadow-2xl animate-slide-in-left flex items-center gap-3 text-xs font-semibold">
          {toastPhotoUrl ? (
            <img
              src={toastPhotoUrl}
              alt="صورة الطالب"
              onError={(e) => {
                e.currentTarget.src = DEFAULT_STUDENT_PHOTO_URL;
              }}
              className="w-9 h-9 rounded-full object-cover border-2 border-emerald-500 shrink-0"
            />
          ) : (
            <CheckCircle2 className="w-4 h-4 text-emerald-500 shrink-0" />
          )}
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Assistant Audit Log Modal (سجل تدقيق وأمان عمليات المعيدين) */}
      {showAuditLogsModal && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl max-w-2xl w-full max-h-[85vh] flex flex-col shadow-2xl overflow-hidden animate-scale-up">
            <div className="p-4 sm:p-5 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-xl bg-blue-600/10 text-blue-600 dark:text-blue-400 flex items-center justify-center">
                  <History className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-bold text-sm sm:text-base text-slate-900 dark:text-white">
                    سجل تدقيق عمليات المعيدين والمساعدين (Audit Trail)
                  </h3>
                  <p className="text-xs text-slate-500 dark:text-slate-400">
                    توثيق كامل للأنشطة المرخصة وإسناد الصلاحيات بالقاعة
                  </p>
                </div>
              </div>
              <button
                onClick={() => setShowAuditLogsModal(false)}
                className="w-8 h-8 rounded-lg bg-slate-100 dark:bg-slate-800 text-slate-500 hover:text-slate-900 dark:hover:text-white flex items-center justify-center text-sm font-bold cursor-pointer transition-colors"
              >
                ✕
              </button>
            </div>

            <div className="p-4 overflow-y-auto flex-1 divide-y divide-slate-100 dark:divide-slate-800/60">
              {auditLogs.length === 0 ? (
                <div className="py-8 text-center text-xs text-slate-400">لا توجد عمليات مسجلة في سجل التدقيق حتى الآن.</div>
              ) : (
                auditLogs.map((log) => (
                  <div key={log.log_id} className="py-3 first:pt-0 last:pb-0 flex items-start justify-between gap-3 text-xs">
                    <div className="space-y-1">
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-slate-900 dark:text-white">{log.assistant_name}</span>
                        <span className="text-[10px] bg-blue-500/10 text-blue-600 dark:text-blue-400 border border-blue-500/20 px-2 py-0.2 rounded-full font-semibold">
                          محاضرة #{log.lecture_id}
                        </span>
                        {log.ip_address && (
                          <span className="text-[10px] text-slate-400 font-mono">
                            IP: {log.ip_address}
                          </span>
                        )}
                      </div>
                      <p className="text-slate-600 dark:text-slate-300 font-medium">
                        {log.action_performed}
                      </p>
                    </div>
                    <div className="text-left shrink-0">
                      <span className="inline-block px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border border-emerald-500/20 mb-1">
                        {log.status}
                      </span>
                      <div className="text-[10px] text-slate-400 font-mono">
                        {log.timestamp}
                      </div>
                    </div>
                  </div>
                ))
              )}
            </div>

            <div className="p-3.5 bg-slate-50 dark:bg-slate-800/50 border-t border-slate-200 dark:border-slate-800 flex items-center justify-between text-xs text-slate-500">
              <span>إجمالي السجلات الموثقة: {auditLogs.length}</span>
              <button
                onClick={() => setShowAuditLogsModal(false)}
                className="px-4 py-1.5 bg-blue-600 hover:bg-blue-500 text-white rounded-lg font-semibold cursor-pointer transition-colors"
              >
                إغلاق النافذة
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
