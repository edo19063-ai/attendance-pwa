import React, { useState, useEffect } from 'react';
import QRCode from 'qrcode';
import {
  Share2,
  Copy,
  Check,
  ExternalLink,
  QrCode,
  Smartphone,
  Monitor,
  ClipboardList,
  BarChart3,
  Globe,
  Server,
  Sparkles,
} from 'lucide-react';

const SHARED_BASE_URL = 'https://ais-pre-z5mta25jf3bjhdnqhl4ssa-993577425777.europe-west2.run.app';

export const UrlsShareView: React.FC = () => {
  const [copiedIndex, setCopiedIndex] = useState<number | null>(null);
  const [scannerQrUrl, setScannerQrUrl] = useState<string>('');

  // Dynamically resolve base URL or fallback to the provided Cloud Run URL
  const baseUrl = typeof window !== 'undefined' && window.location.origin.includes('run.app')
    ? window.location.origin
    : SHARED_BASE_URL;

  const links = [
    {
      title: 'الرابط الرئيسي الشامل للنظام (Main App URL)',
      desc: 'يفتح النظام الكامل مع شريط التنقل العلوي وجميع الخصائص',
      url: baseUrl,
      icon: <Globe className="w-5 h-5 text-blue-400" />,
      badge: 'الرابط الأساسي',
      color: 'blue',
    },
    {
      title: 'رابط شاشة الأستاذ المباشرة للبروجيكتور (Live Screen)',
      desc: 'يعرض الباركود المتغير كل 5 ثوانٍ مع مؤشر التوقيت وسجل الحضور المباشر',
      url: `${baseUrl}?view=live-screen&lecture=1`,
      icon: <Monitor className="w-5 h-5 text-emerald-400" />,
      badge: 'شاشة القاعة',
      color: 'emerald',
    },
    {
      title: 'رابط مسح الطالب بهاتف الجوال (Student Scanner)',
      desc: 'الرابط المخصص لفتحه بهواتف الطلاب لمسح الشاشة وتسجيل الحضور الفوري',
      url: `${baseUrl}?view=scanner&lecture=1`,
      icon: <Smartphone className="w-5 h-5 text-purple-400" />,
      badge: 'هاتف الطالب',
      color: 'purple',
    },
    {
      title: 'رابط كشف الحضور والغياب اليدوي (Manual Attendance)',
      desc: 'جدول أسماء الطلاب وراديو الأزرار (حاضر / غائب / عذر) وحفظ السجل',
      url: `${baseUrl}?view=manual&lecture=1`,
      icon: <ClipboardList className="w-5 h-5 text-amber-400" />,
      badge: 'الجدول اليدوي',
      color: 'amber',
    },
    {
      title: 'رابط التقارير والاستعلامات وحساب نسب الحرمان (Reports & SQL)',
      desc: 'حساب نسب الحضور والغياب وقائمة المتجاوزين لـ 3 غيابات أو 25% وسجلات الأيام',
      url: `${baseUrl}?view=reports&course=1`,
      icon: <BarChart3 className="w-5 h-5 text-rose-400" />,
      badge: 'التقارير والإحصائيات',
      color: 'rose',
    },
  ];

  // Generate QR Code for the Student Scanner Link
  useEffect(() => {
    const studentScannerUrl = `${baseUrl}?view=scanner&lecture=1`;
    QRCode.toDataURL(studentScannerUrl, {
      width: 240,
      margin: 1,
      color: { dark: '#0f172a', light: '#ffffff' },
    })
      .then(setScannerQrUrl)
      .catch(console.error);
  }, [baseUrl]);

  const handleCopy = (index: number, url: string) => {
    navigator.clipboard?.writeText(url).catch(() => {});
    setCopiedIndex(index);
    setTimeout(() => {
      setCopiedIndex(null);
    }, 2000);
  };

  return (
    <div className="max-w-6xl mx-auto p-4 sm:p-6 space-y-8">
      {/* Hero Header */}
      <div className="bg-gradient-to-r from-blue-900/40 via-slate-900 to-slate-900 border border-blue-500/30 rounded-3xl p-6 sm:p-8 shadow-2xl relative overflow-hidden">
        <div className="max-w-2xl space-y-3 relative z-10">
          <div className="inline-flex items-center gap-2 px-3 py-1 bg-blue-500/10 border border-blue-500/20 rounded-full text-xs font-semibold text-blue-400">
            <Sparkles className="w-3.5 h-3.5" />
            <span>الرابط النهائي لنظام الحضور الذكي</span>
          </div>

          <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
            روابط الوصول والمشاركة المباشرة للنظام
          </h1>

          <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
            تم تشغيل ونشر نظام الحضور والغياب بالباركود المتغير بالكامل. يمكنك نسخ أي من الروابط أدناه لاستخدامها مباشرة على البروجيكتور أو مشاركتها مع الطلاب لفتحها من هواتفهم المحمولة.
          </p>

          <div className="pt-2 flex items-center gap-2 flex-wrap">
            <div className="flex items-center gap-2 bg-slate-950/80 border border-slate-700/80 rounded-xl px-3.5 py-2 font-mono text-xs text-emerald-400">
              <span className="truncate max-w-xs sm:max-w-md">{baseUrl}</span>
            </div>
            <button
              onClick={() => handleCopy(-1, baseUrl)}
              className="flex items-center gap-1.5 px-4 py-2 bg-blue-600 hover:bg-blue-500 text-white rounded-xl text-xs font-bold transition-all shadow-md cursor-pointer"
            >
              {copiedIndex === -1 ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
              <span>{copiedIndex === -1 ? 'تم النسخ!' : 'نسخ الرابط الأساسي'}</span>
            </button>
          </div>
        </div>
      </div>

      {/* Grid: Links on the Left + Scanner QR for Phones on the Right */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Links List (8 cols) */}
        <div className="lg:col-span-8 space-y-4">
          <div className="flex items-center gap-2 mb-2">
            <Share2 className="w-4 h-4 text-blue-500 dark:text-blue-400" />
            <h2 className="text-sm font-bold text-slate-900 dark:text-white">الروابط المباشرة لصفحات النظام المحددة</h2>
          </div>

          {links.map((item, idx) => (
            <div
              key={idx}
              className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 hover:border-slate-300 dark:hover:border-slate-700/80 rounded-2xl p-4 sm:p-5 transition-all shadow-sm dark:shadow-md flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4"
            >
              <div className="flex items-start gap-3.5 flex-1 min-w-0">
                <div className="p-2.5 rounded-xl bg-slate-100 dark:bg-slate-800 shrink-0 mt-0.5">
                  {item.icon}
                </div>
                <div className="min-w-0 flex-1">
                  <div className="flex items-center gap-2 flex-wrap mb-1">
                    <h3 className="font-bold text-sm text-slate-900 dark:text-white">{item.title}</h3>
                    <span className="text-[10px] bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 px-2 py-0.5 rounded font-medium border border-slate-200 dark:border-slate-700">
                      {item.badge}
                    </span>
                  </div>
                  <p className="text-xs text-slate-500 dark:text-slate-400 mb-2">{item.desc}</p>
                  <code className="text-[11px] font-mono text-slate-700 dark:text-slate-300 bg-slate-100 dark:bg-slate-950 px-2 py-1 rounded block truncate max-w-full text-left dir-ltr border border-slate-200 dark:border-slate-800/80">
                    {item.url}
                  </code>
                </div>
              </div>

              <div className="flex items-center gap-2 self-end sm:self-center shrink-0">
                <button
                  onClick={() => handleCopy(idx, item.url)}
                  className="flex items-center gap-1.5 px-3 py-2 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-200 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-semibold transition-colors cursor-pointer"
                  title="نسخ الرابط"
                >
                  {copiedIndex === idx ? (
                    <>
                      <Check className="w-3.5 h-3.5 text-emerald-500 dark:text-emerald-400" />
                      <span className="text-emerald-500 dark:text-emerald-400">تم النسخ</span>
                    </>
                  ) : (
                    <>
                      <Copy className="w-3.5 h-3.5" />
                      <span>نسخ</span>
                    </>
                  )}
                </button>

                <a
                  href={item.url}
                  target="_blank"
                  rel="noreferrer"
                  className="flex items-center gap-1 px-3 py-2 bg-blue-500/10 hover:bg-blue-500/20 text-blue-600 dark:text-blue-400 border border-blue-500/20 rounded-xl text-xs font-semibold transition-colors"
                  title="فتح في نافذة جديدة"
                >
                  <ExternalLink className="w-3.5 h-3.5" />
                  <span>فتح</span>
                </a>
              </div>
            </div>
          ))}
        </div>

        {/* Right QR Box: Scan to Open Mobile Scanner (4 cols) */}
        <div className="lg:col-span-4 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 shadow-sm dark:shadow-xl text-center space-y-4">
          <div className="inline-flex items-center justify-center p-2.5 bg-purple-500/10 border border-purple-500/20 rounded-2xl text-purple-600 dark:text-purple-400">
            <QrCode className="w-6 h-6" />
          </div>

          <div>
            <h3 className="font-bold text-base text-slate-900 dark:text-white">امسح لفتح الماسح على هاتفك</h3>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
              وجّه كاميرا هاتفك الذكي نحو هذا الباركود ليفتح صفحة مسح الطالب مباشرة على جوالك:
            </p>
          </div>

          <div className="p-3 bg-white rounded-2xl inline-block shadow-md mx-auto border border-slate-100 dark:border-transparent">
            {scannerQrUrl ? (
              <img
                src={scannerQrUrl}
                alt="QR Code لفتح ماسح الطالب على الهاتف"
                className="w-48 h-48 object-contain"
              />
            ) : (
              <div className="w-48 h-48 flex items-center justify-center text-slate-400 text-xs">
                جاري توليد الرمز...
              </div>
            )}
          </div>

          <div className="text-[11px] text-slate-600 dark:text-slate-400 bg-slate-50 dark:bg-slate-950 p-3 rounded-xl border border-slate-200 dark:border-slate-800 text-right space-y-1">
            <div className="font-bold text-slate-800 dark:text-slate-200">تعليمات استخدام الهاتف:</div>
            <div>1. افتح تطبيق كاميرا الهاتف أو متصفح Chrome / Safari.</div>
            <div>2. امسح هذا الرمز ليفتح رابط مسح الطالب.</div>
            <div>3. ثم وجّه كاميرا الهاتف نحو شاشة العرض (البروجيكتور).</div>
          </div>
        </div>
      </div>

      {/* Deployment & Execution Notes */}
      <div className="bg-white/80 dark:bg-slate-900/60 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 space-y-4 shadow-sm">
        <div className="flex items-center gap-2">
          <Server className="w-4 h-4 text-emerald-500 dark:text-emerald-400" />
          <h2 className="text-sm font-bold text-slate-900 dark:text-white">تشغيل المشروع محلياً باستخدام Python و MySQL (اختياري)</h2>
        </div>

        <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed">
          تم تجميع كامل أكواد البايثون وقاعدة البيانات في تبويب <strong>"قاعدة البيانات والكود"</strong>. إن أردت تشغيلها على خادم محلي خاص بك:
        </p>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
          <div className="bg-slate-50 dark:bg-slate-950 p-3.5 rounded-xl border border-slate-200 dark:border-slate-800 space-y-1">
            <div className="font-bold text-slate-900 dark:text-white">1. استيراد قاعدة البيانات</div>
            <p className="text-slate-500 dark:text-slate-400 text-[11px]">
              قم باستيراد ملف <code className="text-blue-500 dark:text-blue-400">schema.sql</code> في phpMyAdmin أو MySQL Workbench.
            </p>
          </div>

          <div className="bg-slate-50 dark:bg-slate-950 p-3.5 rounded-xl border border-slate-200 dark:border-slate-800 space-y-1">
            <div className="font-bold text-slate-900 dark:text-white">2. تثبيت المكتبات وتشغيل بايثون</div>
            <p className="text-slate-500 dark:text-slate-400 text-[11px]">
              نفّذ: <code className="text-emerald-600 dark:text-emerald-400">pip install flask mysql-connector-python</code> ثم <code className="text-emerald-600 dark:text-emerald-400">python app.py</code>
            </p>
          </div>

          <div className="bg-slate-50 dark:bg-slate-950 p-3.5 rounded-xl border border-slate-200 dark:border-slate-800 space-y-1">
            <div className="font-bold text-slate-900 dark:text-white">3. مشاركة الرابط عبر الإنترنت</div>
            <p className="text-slate-500 dark:text-slate-400 text-[11px]">
              أسهل طريقة للحصول على رابط خارجي لهواتف الطلاب: <code className="text-amber-600 dark:text-amber-400">npx untun tunnel http://localhost:5000</code>
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
