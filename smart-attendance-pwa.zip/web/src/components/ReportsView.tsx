import React, { useState } from 'react';
import {
  BarChart3,
  AlertTriangle,
  Calendar,
  Percent,
  Download,
  Filter,
  CheckCircle2,
  XCircle,
  Clock,
  FileCode,
  BellRing,
  ShieldAlert,
  Loader2,
} from 'lucide-react';
import { useAttendance } from '../context/AttendanceContext';
import { exportReportToPdf } from '../utils/pdfExport';
import { useCourseReport, useLectureDetails, filterAbsenceThreshold, useAdvisorAlerts } from '../hooks/useServerAttendance';

type ReportTab = 'attendance-pct' | 'absence-threshold' | 'daily-log';

export const ReportsView: React.FC = () => {
  const {
    courses,
    lectures,
    selectedCourseId,
    setSelectedCourseId,
  } = useAttendance();

  // تنبيهات الإرشاد محفوظة على الخادم (هذه الشاشة للمحاضر فقط)
  const { alerts: advisorAlerts, create: createAdvisorAlert } = useAdvisorAlerts();

  const [activeTab, setActiveTab] = useState<ReportTab>('attendance-pct');
  const [minAbsences, setMinAbsences] = useState<number>(3);
  const [minAbsencePct, setMinAbsencePct] = useState<number>(25);
  const [selectedLectureIdForLog, setSelectedLectureIdForLog] = useState<number>(3);
  const [showSqlModal, setShowSqlModal] = useState<boolean>(false);
  const [warningSentFor, setWarningSentFor] = useState<string | null>(null);
  const [isExportingPdf, setIsExportingPdf] = useState<boolean>(false);
  const [pdfNotice, setPdfNotice] = useState<string | null>(null);

  const selectedCourse = courses.find((c) => c.course_id === selectedCourseId);
  // مصدر البيانات: الخادم الآمن
  const {
    summaries: courseSummaries,
    loading: reportLoading,
    error: reportError,
    refresh: refreshReport,
  } = useCourseReport(selectedCourseId);
  const thresholdStudents = filterAbsenceThreshold(courseSummaries, minAbsences, minAbsencePct);
  const lectureLogDetails = useLectureDetails(selectedLectureIdForLog);

  // Averages for Tab 1
  const avgAttendance =
    courseSummaries.length > 0
      ? Math.round(
          courseSummaries.reduce((acc, curr) => acc + curr.attendance_percentage, 0) /
            courseSummaries.length
        )
      : 0;

  const handleSendWarning = (studentName: string) => {
    setWarningSentFor(studentName);
    setTimeout(() => {
      setWarningSentFor(null);
    }, 3000);
  };

  const handleExportPdf = async () => {
    setIsExportingPdf(true);
    try {
      const courseLabel = selectedCourse ? `${selectedCourse.course_name} (${selectedCourse.course_code})` : 'المقرر';
      const courseCode = selectedCourse?.course_code || 'COURSE';

      if (activeTab === 'attendance-pct') {
        await exportReportToPdf({
          filename: `attendance_report_${courseCode}.pdf`,
          title: 'تقرير نسب الحضور والغياب للطلاب',
          subtitle: `إحصائية شاملة لجميع الطلاب المسجلين في مقرر ${courseLabel}`,
          metaItems: [
            { label: 'المقرر', value: courseLabel },
            { label: 'أستاذ المادة', value: selectedCourse?.instructor_name || '—' },
            { label: 'إجمالي المحاضرات', value: String(courseSummaries[0]?.total_lectures || 0) },
          ],
          stats: [
            { label: 'متوسط الحضور العام', value: `${avgAttendance}%`, accent: 'emerald' },
            { label: 'إجمالي الطلاب', value: `${courseSummaries.length} طالب`, accent: 'slate' },
            {
              label: 'المنتظمون (>= 75%)',
              value: `${courseSummaries.filter((s) => s.attendance_percentage >= 75).length} طالب`,
              accent: 'blue',
            },
          ],
          columns: [
            { header: '#', align: 'center', width: '40px' },
            { header: 'اسم الطالب', align: 'right' },
            { header: 'الرقم الجامعي', align: 'center' },
            { header: 'المحاضرات', align: 'center' },
            { header: 'حاضر', align: 'center' },
            { header: 'غائب', align: 'center' },
            { header: 'تأخر', align: 'center' },
            { header: 'بعذر', align: 'center' },
            { header: 'نسبة الحضور', align: 'center' },
            { header: 'نسبة الغياب', align: 'center' },
          ],
          rows: courseSummaries.map((s, idx) => [
            { text: String(idx + 1), mono: true },
            { text: s.full_name, bold: true },
            { text: s.university_id, mono: true },
            { text: String(s.total_lectures), mono: true },
            { text: String(s.present_count), badgeColor: 'emerald', mono: true },
            { text: String(s.absent_count), badgeColor: 'rose', mono: true },
            { text: String(s.late_count), badgeColor: 'amber', mono: true },
            { text: String(s.excused_count), badgeColor: 'blue', mono: true },
            {
              text: `${s.attendance_percentage}%`,
              badgeColor: s.attendance_percentage >= 75 ? 'emerald' : s.attendance_percentage >= 50 ? 'amber' : 'rose',
              mono: true,
            },
            { text: `${s.absent_percentage}%`, mono: true, bold: true },
          ]),
        });
      } else if (activeTab === 'absence-threshold') {
        await exportReportToPdf({
          filename: `absence_warnings_${courseCode}.pdf`,
          title: 'تقرير المتجاوزين لحد الغياب (إنذار الحرمان)',
          subtitle: `كشف الطلاب المستحقين للإنذار الأكاديمي وفق حد الغياب (${minAbsences} مرات أو ≥ ${minAbsencePct}%)`,
          metaItems: [
            { label: 'المقرر', value: courseLabel },
            { label: 'أستاذ المادة', value: selectedCourse?.instructor_name || '—' },
            { label: 'عدد المستحقين للإنذار', value: `${thresholdStudents.length} طالب` },
          ],
          stats: [
            { label: 'عدد الطلاب المتجاوزين', value: thresholdStudents.length, accent: 'rose' },
            { label: 'حد الغياب المعتمد', value: `> ${minAbsences} محاضرات`, accent: 'amber' },
            { label: 'نسبة الخطر المعتمدة', value: `≥ ${minAbsencePct}%`, accent: 'blue' },
          ],
          columns: [
            { header: '#', align: 'center', width: '40px' },
            { header: 'اسم الطالب', align: 'right' },
            { header: 'الرقم الجامعي', align: 'center' },
            { header: 'إجمالي المحاضرات', align: 'center' },
            { header: 'مرات الغياب', align: 'center' },
            { header: 'الحضور', align: 'center' },
            { header: 'نسبة الغياب', align: 'center' },
            { header: 'التصنيف', align: 'center' },
          ],
          rows: thresholdStudents.map((st, idx) => [
            { text: String(idx + 1), mono: true },
            { text: st.full_name, bold: true },
            { text: st.university_id, mono: true },
            { text: String(st.total_lectures), mono: true },
            { text: String(st.absent_count), badgeColor: 'rose', mono: true },
            { text: String(st.present_count), badgeColor: 'emerald', mono: true },
            { text: `${st.absent_percentage}%`, badgeColor: 'rose', mono: true },
            { text: 'مهدد بالحرمان', badgeColor: 'amber' },
          ]),
        });
      } else {
        const lec = lectureLogDetails.lecture;
        const students = lectureLogDetails.studentsWithStatus;
        const pCount = students.filter((s) => s.status === 'Present').length;
        const aCount = students.filter((s) => s.status === 'Absent').length;
        const lCount = students.filter((s) => s.status === 'Late').length;
        const eCount = students.filter((s) => s.status === 'Excused').length;

        await exportReportToPdf({
          filename: `lecture_${selectedLectureIdForLog}_attendance_${courseCode}.pdf`,
          title: `سجل حضور المحاضرة #${lec?.lecture_id || selectedLectureIdForLog}`,
          subtitle: lec?.topic || courseLabel,
          metaItems: [
            { label: 'المقرر', value: courseLabel },
            { label: 'المحاضر', value: lectureLogDetails.course?.instructor_name || '—' },
            { label: 'التاريخ', value: lec?.lecture_date || '—' },
            { label: 'الوقت', value: lec?.lecture_time || '—' },
          ],
          stats: [
            { label: 'حاضر', value: pCount, accent: 'emerald' },
            { label: 'غائب', value: aCount, accent: 'rose' },
            { label: 'متأخر', value: lCount, accent: 'amber' },
            { label: 'بعذر', value: eCount, accent: 'blue' },
          ],
          columns: [
            { header: '#', align: 'center', width: '40px' },
            { header: 'اسم الطالب', align: 'right' },
            { header: 'الرقم الجامعي', align: 'center' },
            { header: 'حالة الحضور', align: 'center' },
            { header: 'الملاحظات', align: 'right' },
            { header: 'وقت التسجيل', align: 'center' },
          ],
          rows: students.map((item, idx) => [
            { text: String(idx + 1), mono: true },
            { text: item.student.full_name, bold: true },
            { text: item.student.university_id, mono: true },
            {
              text:
                item.status === 'Present'
                  ? 'حاضر'
                  : item.status === 'Absent'
                  ? 'غائب'
                  : item.status === 'Late'
                  ? 'متأخر'
                  : 'بعذر',
              badgeColor:
                item.status === 'Present'
                  ? 'emerald'
                  : item.status === 'Absent'
                  ? 'rose'
                  : item.status === 'Late'
                  ? 'amber'
                  : 'blue',
            },
            { text: item.notes || '—' },
            { text: item.recorded_at || '—', mono: true },
          ]),
        });
      }
      setPdfNotice('تم تصدير وتنزيل ملف التقرير بصيغة PDF بنجاح!');
      setTimeout(() => setPdfNotice(null), 3500);
    } finally {
      setIsExportingPdf(false);
    }
  };

  const sqlQueries: Record<ReportTab, { title: string; query: string }> = {
    'attendance-pct': {
      title: 'استعلام 1: حساب نسبة الحضور والغياب لكل طالب في مقرر معين',
      query: `SELECT 
    s.university_id AS 'الرقم الجامعي',
    s.full_name AS 'اسم الطالب',
    c.course_name AS 'المادة',
    COUNT(a.attendance_id) AS 'إجمالي المحاضرات',
    SUM(CASE WHEN a.status = 'Present' THEN 1 ELSE 0 END) AS 'مرات الحضور',
    SUM(CASE WHEN a.status = 'Absent' THEN 1 ELSE 0 END) AS 'مرات الغياب',
    SUM(CASE WHEN a.status = 'Late' THEN 1 ELSE 0 END) AS 'مرات التأخر',
    SUM(CASE WHEN a.status = 'Excused' THEN 1 ELSE 0 END) AS 'بعذر',
    ROUND((SUM(CASE WHEN a.status = 'Present' THEN 1 ELSE 0 END) * 100.0) / NULLIF(COUNT(a.attendance_id), 0), 2) AS 'نسبة الحضور %',
    ROUND((SUM(CASE WHEN a.status = 'Absent' THEN 1 ELSE 0 END) * 100.0) / NULLIF(COUNT(a.attendance_id), 0), 2) AS 'نسبة الغياب %'
FROM Course_Enrollments ce
JOIN Students s ON ce.student_id = s.student_id
JOIN Courses c ON ce.course_id = c.course_id
LEFT JOIN Lectures l ON l.course_id = c.course_id
LEFT JOIN Attendance a ON a.lecture_id = l.lecture_id AND a.student_id = s.student_id
WHERE c.course_id = ${selectedCourseId}
GROUP BY s.student_id, s.university_id, s.full_name, c.course_name
ORDER BY 'نسبة الغياب %' DESC;`,
    },
    'absence-threshold': {
      title: 'استعلام 2: استخراج الطلاب الذين تجاوزوا حد غياب معين (أكثر من 3 مرات)',
      query: `SELECT 
    s.university_id AS 'الرقم الجامعي',
    s.full_name AS 'اسم الطالب',
    c.course_code AS 'رمز المادة',
    c.course_name AS 'اسم المادة',
    COUNT(a.attendance_id) AS 'إجمالي المحاضرات',
    SUM(CASE WHEN a.status = 'Absent' THEN 1 ELSE 0 END) AS 'عدد مرات الغياب',
    ROUND((SUM(CASE WHEN a.status = 'Absent' THEN 1 ELSE 0 END) * 100.0) / COUNT(a.attendance_id), 2) AS 'نسبة الغياب %'
FROM Attendance a
JOIN Students s ON a.student_id = s.student_id
JOIN Lectures l ON a.lecture_id = l.lecture_id
JOIN Courses c ON l.course_id = c.course_id
WHERE c.course_id = ${selectedCourseId}
GROUP BY s.student_id, s.university_id, s.full_name, c.course_id, c.course_code, c.course_name
HAVING SUM(CASE WHEN a.status = 'Absent' THEN 1 ELSE 0 END) > ${minAbsences}
ORDER BY 'عدد مرات الغياب' DESC;`,
    },
    'daily-log': {
      title: 'استعلام 3: عرض سجل حضور محاضرة ليوم وتاريخ معين',
      query: `SELECT 
    c.course_name AS 'المادة',
    c.course_code AS 'رمز المادة',
    l.lecture_date AS 'التاريخ',
    l.lecture_time AS 'الوقت',
    l.topic AS 'عنوان المحاضرة',
    s.university_id AS 'الرقم الجامعي',
    s.full_name AS 'اسم الطالب',
    a.status AS 'حالة الحضور',
    a.notes AS 'الملاحظات',
    a.recorded_at AS 'وقت التسجيل'
FROM Attendance a
JOIN Lectures l ON a.lecture_id = l.lecture_id
JOIN Courses c ON l.course_id = c.course_id
JOIN Students s ON a.student_id = s.student_id
WHERE l.lecture_id = ${selectedLectureIdForLog}
ORDER BY s.full_name ASC;`,
    },
  };

  return (
    <div className="max-w-6xl mx-auto p-4 sm:p-6 space-y-6">
      {/* Top Banner */}
      <div className="flex items-center justify-between gap-4 flex-wrap border-b border-slate-200 dark:border-slate-800 pb-4">
        <div>
          <h1 className="text-xl sm:text-2xl font-bold text-slate-900 dark:text-white tracking-tight">
            التقارير والاستعلامات الذكية
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1">
            مبنية ومطابقة للاستعلامات الثلاثة في قاعدة البيانات (SQL Queries)
          </p>
        </div>

        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2 bg-slate-100 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-lg px-3 py-1.5 text-xs">
            <Filter className="w-3.5 h-3.5 text-slate-500 dark:text-slate-400" />
            <span className="text-slate-500 dark:text-slate-400">المقرر:</span>
            <select
              value={selectedCourseId}
              onChange={(e) => setSelectedCourseId(Number(e.target.value))}
              className="bg-transparent text-slate-900 dark:text-white font-medium outline-none cursor-pointer"
            >
              {courses.map((c) => (
                <option key={c.course_id} value={c.course_id} className="bg-white dark:bg-slate-900 text-slate-900 dark:text-white">
                  {c.course_name} ({c.course_code})
                </option>
              ))}
            </select>
          </div>

          <button
            onClick={handleExportPdf}
            disabled={isExportingPdf}
            className="flex items-center gap-1.5 px-3.5 py-1.5 bg-rose-600 hover:bg-rose-500 disabled:opacity-60 text-white text-xs font-bold rounded-lg transition-colors shadow-sm cursor-pointer"
          >
            {isExportingPdf ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Download className="w-3.5 h-3.5" />}
            <span>{isExportingPdf ? 'جاري تجهيز PDF...' : 'تصدير ملف PDF'}</span>
          </button>

          <button
            onClick={() => setShowSqlModal(!showSqlModal)}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-100 dark:bg-slate-900 hover:bg-slate-200 dark:hover:bg-slate-800 border border-slate-200 dark:border-slate-800 text-xs font-medium text-blue-600 dark:text-blue-400 rounded-lg transition-colors cursor-pointer"
          >
            <FileCode className="w-3.5 h-3.5" />
            <span>{showSqlModal ? 'إخفاء كود SQL' : 'عرض كود SQL'}</span>
          </button>
        </div>
      </div>

      {(reportError || lectureLogDetails.error) && (
        <div className="p-3 bg-rose-500/10 border border-rose-500/20 text-rose-700 dark:text-rose-300 rounded-xl text-xs font-semibold flex items-center justify-between gap-2">
          <span>⚠️ تعذر تحميل البيانات من الخادم: {reportError || lectureLogDetails.error}</span>
          <button
            type="button"
            onClick={() => {
              refreshReport();
              lectureLogDetails.refresh();
            }}
            className="underline cursor-pointer shrink-0"
          >
            إعادة المحاولة
          </button>
        </div>
      )}
      {reportLoading && courseSummaries.length === 0 && !reportError && (
        <div className="text-xs text-slate-500">⏳ جارٍ تحميل التقرير من الخادم...</div>
      )}

      {/* PDF Export Notice */}
      {pdfNotice && (
        <div className="p-3 bg-emerald-500/10 border border-emerald-500/20 text-emerald-700 dark:text-emerald-300 rounded-xl text-xs font-semibold flex items-center gap-2 animate-fade-in">
          <CheckCircle2 className="w-4 h-4 text-emerald-500 dark:text-emerald-400" />
          <span>{pdfNotice}</span>
        </div>
      )}

      {/* SQL Code Preview Collapsible */}
      {showSqlModal && (
        <div className="bg-slate-950 border border-blue-500/30 rounded-2xl p-5 shadow-xl animate-fade-in">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-bold text-blue-400 font-mono">
              {sqlQueries[activeTab].title}
            </span>
            <span className="text-[10px] bg-blue-500/10 text-blue-400 px-2 py-0.5 rounded font-mono">
              MySQL / MariaDB
            </span>
          </div>
          <pre className="bg-slate-900 p-4 rounded-xl text-xs font-mono text-emerald-400 overflow-x-auto text-left dir-ltr leading-relaxed">
            {sqlQueries[activeTab].query}
          </pre>
        </div>
      )}

      {/* Notification Toast */}
      {warningSentFor && (
        <div className="p-3 bg-amber-500/10 border border-amber-500/20 text-amber-600 dark:text-amber-300 rounded-xl text-xs font-semibold flex items-center gap-2 animate-fade-in">
          <BellRing className="w-4 h-4 text-amber-500 dark:text-amber-400" />
          <span>تم إرسال إشعار إنذار بالغياب والحرمان الأكاديمي للطالب ({warningSentFor}) بنجاح!</span>
        </div>
      )}

      {/* Report Type Tabs */}
      <div className="flex items-center gap-2 border-b border-slate-200 dark:border-slate-800 pb-2 overflow-x-auto no-scrollbar">
        <button
          onClick={() => setActiveTab('attendance-pct')}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs sm:text-sm font-semibold transition-all whitespace-nowrap cursor-pointer ${
            activeTab === 'attendance-pct'
              ? 'bg-blue-600 text-white shadow-sm shadow-blue-500/20'
              : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-900'
          }`}
        >
          <Percent className="w-4 h-4" />
          <span>1. نسب الحضور والغياب للطلاب</span>
        </button>

        <button
          onClick={() => setActiveTab('absence-threshold')}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs sm:text-sm font-semibold transition-all whitespace-nowrap cursor-pointer ${
            activeTab === 'absence-threshold'
              ? 'bg-rose-600 text-white shadow-sm shadow-rose-500/20'
              : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-900'
          }`}
        >
          <AlertTriangle className="w-4 h-4" />
          <span>2. المتجاوزون لحد الغياب (إنذار الحرمان)</span>
          {thresholdStudents.length > 0 && (
            <span className="bg-white/20 text-white px-1.5 py-0.2 rounded-full text-[10px] font-mono">
              {thresholdStudents.length}
            </span>
          )}
        </button>

        <button
          onClick={() => setActiveTab('daily-log')}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs sm:text-sm font-semibold transition-all whitespace-nowrap cursor-pointer ${
            activeTab === 'daily-log'
              ? 'bg-emerald-600 text-white shadow-sm shadow-emerald-500/20'
              : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-900'
          }`}
        >
          <Calendar className="w-4 h-4" />
          <span>3. سجل حضور محاضرة وتاريخ معين</span>
        </button>
      </div>

      {/* ============================================================== */}
      {/* TAB 1: Attendance Percentage per Student (Query 1) */}
      {/* ============================================================== */}
      {activeTab === 'attendance-pct' && (
        <div className="space-y-6">
          {/* Summary KPIs */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-4 shadow-sm">
              <span className="text-xs text-slate-500 dark:text-slate-400">متوسط الحضور العام للمقرر</span>
              <div className="text-2xl font-bold font-mono text-emerald-600 dark:text-emerald-400 mt-1">
                {avgAttendance}%
              </div>
              <p className="text-[11px] text-slate-500 mt-1">
                من إجمالي {courseSummaries[0]?.total_lectures || 0} محاضرات مرصودة
              </p>
            </div>

            <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-4 shadow-sm">
              <span className="text-xs text-slate-500 dark:text-slate-400">إجمالي الطلاب المسجلين</span>
              <div className="text-2xl font-bold font-mono text-slate-900 dark:text-white mt-1">
                {courseSummaries.length} طالب
              </div>
              <p className="text-[11px] text-slate-500 mt-1">
                مقرر: {selectedCourse?.course_name}
              </p>
            </div>

            <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-4 shadow-sm">
              <span className="text-xs text-slate-500 dark:text-slate-400">الطلاب المنتظمون (&ge; 75%)</span>
              <div className="text-2xl font-bold font-mono text-blue-600 dark:text-blue-400 mt-1">
                {courseSummaries.filter((s) => s.attendance_percentage >= 75).length} طالب
              </div>
              <p className="text-[11px] text-slate-500 mt-1">حالة أكاديمية ممتازة</p>
            </div>
          </div>

          {/* Table */}
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl overflow-hidden shadow-sm dark:shadow-xl">
            <div className="overflow-x-auto">
              <table className="w-full text-right border-collapse text-xs sm:text-sm">
                <thead>
                  <tr className="bg-slate-100/70 dark:bg-slate-950/70 border-b border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-400 font-semibold">
                    <th className="py-3 px-4 w-12 text-center">#</th>
                    <th className="py-3 px-4">اسم الطالب</th>
                    <th className="py-3 px-4">الرقم الجامعي</th>
                    <th className="py-3 px-4 text-center">المحاضرات</th>
                    <th className="py-3 px-4 text-center text-emerald-600 dark:text-emerald-400">حاضر</th>
                    <th className="py-3 px-4 text-center text-rose-600 dark:text-rose-400">غائب</th>
                    <th className="py-3 px-4 text-center text-amber-600 dark:text-amber-400">تأخر</th>
                    <th className="py-3 px-4 text-center text-blue-600 dark:text-blue-400">بعذر</th>
                    <th className="py-3 px-4 min-w-[160px]">نسبة الحضور</th>
                    <th className="py-3 px-4 text-center">نسبة الغياب</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 dark:divide-slate-800/80">
                  {courseSummaries.map((s, idx) => (
                    <tr key={s.student_id} className="hover:bg-slate-50 dark:hover:bg-slate-800/40 transition-colors">
                      <td className="py-3 px-4 text-center font-mono text-slate-400 dark:text-slate-500">{idx + 1}</td>
                      <td className="py-3 px-4 font-semibold text-slate-900 dark:text-white">{s.full_name}</td>
                      <td className="py-3 px-4 font-mono text-slate-700 dark:text-slate-300">{s.university_id}</td>
                      <td className="py-3 px-4 text-center font-mono text-slate-800 dark:text-slate-200">{s.total_lectures}</td>
                      <td className="py-3 px-4 text-center font-mono font-bold text-emerald-600 dark:text-emerald-400">
                        {s.present_count}
                      </td>
                      <td className="py-3 px-4 text-center font-mono font-bold text-rose-600 dark:text-rose-400">
                        {s.absent_count}
                      </td>
                      <td className="py-3 px-4 text-center font-mono text-amber-600 dark:text-amber-400">
                        {s.late_count}
                      </td>
                      <td className="py-3 px-4 text-center font-mono text-blue-600 dark:text-blue-400">
                        {s.excused_count}
                      </td>
                      <td className="py-3 px-4">
                        <div className="flex items-center gap-2">
                          <div className="flex-1 bg-slate-200 dark:bg-slate-800 h-2 rounded-full overflow-hidden">
                            <div
                              className={`h-full rounded-full ${
                                s.attendance_percentage >= 75
                                  ? 'bg-emerald-500'
                                  : s.attendance_percentage >= 50
                                  ? 'bg-amber-500'
                                  : 'bg-rose-500'
                              }`}
                              style={{ width: `${s.attendance_percentage}%` }}
                            />
                          </div>
                          <span className="font-mono text-xs font-bold text-slate-900 dark:text-white w-10 text-left">
                            {s.attendance_percentage}%
                          </span>
                        </div>
                      </td>
                      <td className="py-3 px-4 text-center font-mono text-xs font-semibold text-rose-600 dark:text-rose-400">
                        {s.absent_percentage}%
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* ============================================================== */}
      {/* TAB 2: Students Exceeding Absence Threshold (Query 2) */}
      {/* ============================================================== */}
      {activeTab === 'absence-threshold' && (
        <div className="space-y-6">
          {/* Controls Bar */}
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 shadow-sm dark:shadow-lg flex items-center justify-between gap-6 flex-wrap">
            <div className="flex items-center gap-6 flex-wrap">
              <div>
                <label className="text-xs text-slate-500 dark:text-slate-400 block mb-1">
                  شرط عدد مرات الغياب (&gt; X مرات):
                </label>
                <div className="flex items-center gap-2">
                  <input
                    type="range"
                    min="1"
                    max="6"
                    value={minAbsences}
                    onChange={(e) => setMinAbsences(Number(e.target.value))}
                    className="w-32 accent-rose-500 cursor-pointer"
                  />
                  <span className="text-sm font-bold font-mono text-rose-600 dark:text-rose-400">{minAbsences} مرات</span>
                </div>
              </div>

              <div>
                <label className="text-xs text-slate-500 dark:text-slate-400 block mb-1">
                  أو تجاوز نسبة الغياب (&ge; X%):
                </label>
                <div className="flex items-center gap-2">
                  <input
                    type="range"
                    min="15"
                    max="40"
                    step="5"
                    value={minAbsencePct}
                    onChange={(e) => setMinAbsencePct(Number(e.target.value))}
                    className="w-32 accent-rose-500 cursor-pointer"
                  />
                  <span className="text-sm font-bold font-mono text-rose-600 dark:text-rose-400">{minAbsencePct}%</span>
                </div>
              </div>
            </div>

            <div className="text-xs text-slate-500 dark:text-slate-400">
              عدد الطلاب المستحقين للإنذار:{' '}
              <span className="font-bold font-mono text-rose-600 dark:text-rose-400 text-base">
                {thresholdStudents.length}
              </span>
            </div>
          </div>

          {/* Warning List */}
          {thresholdStudents.length === 0 ? (
            <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-10 text-center space-y-2">
              <CheckCircle2 className="w-10 h-10 text-emerald-500 dark:text-emerald-400 mx-auto" />
              <h3 className="text-sm font-bold text-slate-900 dark:text-white">لا يوجد طلاب متجاوزين لحد الغياب</h3>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                جميع الطلاب ملتزمون ضمن النسبة المسموح بها في هذا المقرر.
              </p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {thresholdStudents.map((st) => (
                <div
                  key={st.student_id}
                  className="bg-white dark:bg-slate-900 border border-rose-200 dark:border-rose-900/40 rounded-2xl p-5 shadow-sm dark:shadow-lg relative overflow-hidden flex flex-col justify-between space-y-4"
                >
                  <div className="flex items-start justify-between gap-3">
                    <div>
                      <div className="flex items-center gap-2">
                        <h3 className="font-bold text-base text-slate-900 dark:text-white">{st.full_name}</h3>
                        <span className="text-[10px] bg-rose-500/10 text-rose-600 dark:text-rose-400 border border-rose-500/20 px-2 py-0.5 rounded font-semibold">
                          مهدد بالحرمان
                        </span>
                      </div>
                      <p className="text-xs text-slate-500 dark:text-slate-400 font-mono mt-0.5">
                        الرقم الجامعي: {st.university_id} · مقرر {st.course_code}
                      </p>
                    </div>

                    <div className="text-left font-mono shrink-0">
                      <span className="text-xl font-bold text-rose-600 dark:text-rose-400">{st.absent_percentage}%</span>
                      <span className="block text-[10px] text-slate-500">نسبة الغياب</span>
                    </div>
                  </div>

                  <div className="grid grid-cols-3 gap-2 py-2 border-y border-slate-100 dark:border-slate-800/80 text-center text-xs">
                    <div>
                      <span className="text-[11px] text-slate-500 dark:text-slate-400">المحاضرات</span>
                      <div className="font-mono font-bold text-slate-900 dark:text-white mt-0.5">{st.total_lectures}</div>
                    </div>
                    <div>
                      <span className="text-[11px] text-rose-600 dark:text-rose-400 font-semibold">مرات الغياب</span>
                      <div className="font-mono font-bold text-rose-600 dark:text-rose-400 mt-0.5">{st.absent_count}</div>
                    </div>
                    <div>
                      <span className="text-[11px] text-emerald-600 dark:text-emerald-400 font-semibold">الحضور</span>
                      <div className="font-mono font-bold text-emerald-600 dark:text-emerald-400 mt-0.5">{st.present_count}</div>
                    </div>
                  </div>

                  <div className="flex items-center justify-between gap-2 pt-1 flex-wrap">
                    <span className="text-[11px] text-slate-500">
                      تجاوز الحد الأكاديمي المسموح ({minAbsences} غيابات)
                    </span>
                    <div className="flex items-center gap-1.5">
                      <button
                        onClick={() => handleSendWarning(st.full_name)}
                        className="flex items-center gap-1.5 px-3 py-1.5 bg-rose-600 hover:bg-rose-500 text-white rounded-lg text-xs font-semibold transition-colors cursor-pointer"
                      >
                        <BellRing className="w-3.5 h-3.5" />
                        <span>إنذار الطالب</span>
                      </button>
                      <button
                        onClick={async () => {
                          const res = await createAdvisorAlert(
                            st.student_id,
                            'د. عبد السلام الورفلي',
                            st.absent_count,
                            `تنبيه صادر من تقارير الغياب لمقرر ${st.course_code}`
                          );
                          setWarningSentFor(
                            res.success
                              ? `تم رفع تنبيه للمرشد الأكاديمي عن الطالب: ${st.full_name}`
                              : `❌ ${res.message}`
                          );
                          setTimeout(() => setWarningSentFor(null), 3500);
                        }}
                        className="flex items-center gap-1.5 px-2.5 py-1.5 bg-amber-500/15 hover:bg-amber-500/25 text-amber-700 dark:text-amber-300 border border-amber-500/30 rounded-lg text-xs font-semibold transition-colors cursor-pointer"
                        title="إحالة فورية إلى المرشد الأكاديمي المختص"
                      >
                        <ShieldAlert className="w-3.5 h-3.5 text-amber-500" />
                        <span>إحالة للمرشد</span>
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* ============================================================== */}
      {/* TAB 3: Daily Lecture Log by Date (Query 3) */}
      {/* ============================================================== */}
      {activeTab === 'daily-log' && (
        <div className="space-y-6">
          {/* Lecture Picker Strip */}
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-4 flex items-center justify-between gap-4 flex-wrap shadow-sm">
            <div className="flex items-center gap-3 flex-wrap">
              <Calendar className="w-4 h-4 text-blue-500 dark:text-blue-400" />
              <span className="text-xs text-slate-500 dark:text-slate-400">اختر المحاضرة / التاريخ المطلوب:</span>
              <select
                value={selectedLectureIdForLog}
                onChange={(e) => setSelectedLectureIdForLog(Number(e.target.value))}
                className="bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs text-slate-900 dark:text-white rounded-lg px-3 py-1.5 outline-none cursor-pointer"
              >
                {lectures
                  .filter((l) => l.course_id === selectedCourseId)
                  .map((l) => (
                    <option key={l.lecture_id} value={l.lecture_id} className="bg-white dark:bg-slate-900 text-slate-900 dark:text-white">
                      محاضرة #{l.lecture_id} بتاريخ: {l.lecture_date} — {l.topic}
                    </option>
                  ))}
              </select>
            </div>

            <div className="text-xs text-slate-500 dark:text-slate-400">
              الوقت: <span className="font-mono text-slate-900 dark:text-white">{lectureLogDetails.lecture?.lecture_time}</span>
            </div>
          </div>

          {/* Lecture Info Header Card */}
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 shadow-sm dark:shadow-lg">
            <h2 className="text-base font-bold text-slate-900 dark:text-white mb-1">
              {lectureLogDetails.lecture?.topic}
            </h2>
            <div className="flex items-center gap-3 text-xs text-slate-500 dark:text-slate-400 flex-wrap">
              <span>المقرر: <strong className="text-slate-800 dark:text-slate-200">{lectureLogDetails.course?.course_name}</strong></span>
              <span>·</span>
              <span>رمز المقرر: <strong className="text-slate-800 dark:text-slate-200">{lectureLogDetails.course?.course_code}</strong></span>
              <span>·</span>
              <span>المحاضر: <strong className="text-slate-800 dark:text-slate-200">{lectureLogDetails.course?.instructor_name}</strong></span>
              <span>·</span>
              <span>تاريخ الانعقاد: <strong className="text-slate-800 dark:text-slate-200">{lectureLogDetails.lecture?.lecture_date}</strong></span>
            </div>
          </div>

          {/* Students Log Table */}
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl overflow-hidden shadow-sm dark:shadow-xl">
            <div className="overflow-x-auto">
              <table className="w-full text-right border-collapse text-xs sm:text-sm">
                <thead>
                  <tr className="bg-slate-100/70 dark:bg-slate-950/70 border-b border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-400 font-semibold">
                    <th className="py-3 px-4 w-12 text-center">#</th>
                    <th className="py-3 px-4">اسم الطالب</th>
                    <th className="py-3 px-4">الرقم الجامعي</th>
                    <th className="py-3 px-4 text-center">حالة الحضور</th>
                    <th className="py-3 px-4">الملاحظات</th>
                    <th className="py-3 px-4 text-center">وقت التسجيل</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 dark:divide-slate-800/80">
                  {lectureLogDetails.studentsWithStatus.map((item, idx) => (
                    <tr key={item.student.student_id} className="hover:bg-slate-50 dark:hover:bg-slate-800/40 transition-colors">
                      <td className="py-3 px-4 text-center font-mono text-slate-400 dark:text-slate-500">{idx + 1}</td>
                      <td className="py-3 px-4 font-semibold text-slate-900 dark:text-white">{item.student.full_name}</td>
                      <td className="py-3 px-4 font-mono text-slate-700 dark:text-slate-300">
                        {item.student.university_id}
                      </td>
                      <td className="py-3 px-4 text-center">
                        <span
                          className={`inline-block px-2.5 py-1 rounded-lg text-xs font-semibold ${
                            item.status === 'Present'
                              ? 'bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border border-emerald-500/20'
                              : item.status === 'Absent'
                              ? 'bg-rose-500/10 text-rose-600 dark:text-rose-400 border border-rose-500/20'
                              : item.status === 'Late'
                              ? 'bg-amber-500/10 text-amber-600 dark:text-amber-400 border border-amber-500/20'
                              : 'bg-blue-500/10 text-blue-600 dark:text-blue-400 border border-blue-500/20'
                          }`}
                        >
                          {item.status === 'Present'
                            ? 'حاضر'
                            : item.status === 'Absent'
                            ? 'غائب'
                            : item.status === 'Late'
                            ? 'متأخر'
                            : 'بعذر'}
                        </span>
                      </td>
                      <td className="py-3 px-4 text-slate-600 dark:text-slate-400">
                        {item.notes || <span className="text-slate-400 dark:text-slate-600">—</span>}
                      </td>
                      <td className="py-3 px-4 text-center font-mono text-xs text-slate-500">
                        {item.recorded_at || '—'}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
