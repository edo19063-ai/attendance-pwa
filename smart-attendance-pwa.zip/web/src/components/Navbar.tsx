import React, { useState, useEffect } from 'react';
import {
  QrCode,
  Smartphone,
  ClipboardList,
  BarChart3,
  Database,
  Share2,
  Volume2,
  VolumeX,
  RotateCcw,
  GraduationCap,
  Moon,
  Sun,
  FileCheck,
  ShieldAlert,
} from 'lucide-react';
import { useAttendance } from '../context/AttendanceContext';

export type ActiveView =
  | 'live-screen'
  | 'scanner'
  | 'manual'
  | 'excuses'
  | 'advising'
  | 'reports'
  | 'database'
  | 'share';

interface NavbarProps {
  activeView: ActiveView;
  setActiveView: (view: ActiveView) => void;
}

export const Navbar: React.FC<NavbarProps> = ({ activeView, setActiveView }) => {
  const {
    courses,
    lectures,
    selectedCourseId,
    selectedLectureId,
    setSelectedCourseId,
    setSelectedLectureId,
    soundEnabled,
    setSoundEnabled,
    resetDatabase,
    excuses,
    advisorAlerts,
  } = useAttendance();

  const pendingExcusesCount = excuses.filter((e) => e.status === 'قيد المراجعة').length;
  const pendingAlertsCount = advisorAlerts.filter((a) => a.status === 'قيد المتابعة').length;

  // Dark / Light Theme State synced with html.dark and localStorage
  const [isDark, setIsDark] = React.useState<boolean>(() => {
    if (typeof window !== 'undefined') {
      const saved = localStorage.getItem('smart_attendance_theme');
      if (saved) return saved === 'dark';
      return true; // Default to dark theme as requested
    }
    return true;
  });

  React.useEffect(() => {
    if (typeof document !== 'undefined') {
      if (isDark) {
        document.documentElement.classList.add('dark');
        document.body.classList.add('dark-theme');
        document.body.classList.remove('light-theme');
        localStorage.setItem('smart_attendance_theme', 'dark');
      } else {
        document.documentElement.classList.remove('dark');
        document.body.classList.remove('dark-theme');
        document.body.classList.add('light-theme');
        localStorage.setItem('smart_attendance_theme', 'light');
      }
    }
  }, [isDark]);

  const courseLectures = lectures.filter((l) => l.course_id === selectedCourseId);

  const navItems: Array<{ id: ActiveView; label: string; icon: React.ReactNode; badge?: number }> = [
    {
      id: 'live-screen',
      label: 'شاشة الباركود المتغير',
      icon: <QrCode className="w-4 h-4 shrink-0" />,
    },
    {
      id: 'scanner',
      label: 'ماسح الطالب',
      icon: <Smartphone className="w-4 h-4 shrink-0" />,
    },
    {
      id: 'manual',
      label: 'كشف الحضور اليدوي',
      icon: <ClipboardList className="w-4 h-4 shrink-0" />,
    },
    {
      id: 'excuses',
      label: 'الأعذار الإلكترونية',
      icon: <FileCheck className="w-4 h-4 shrink-0" />,
      badge: pendingExcusesCount > 0 ? pendingExcusesCount : undefined,
    },
    {
      id: 'advising',
      label: 'الإرشاد الأكاديمي',
      icon: <ShieldAlert className="w-4 h-4 shrink-0 text-amber-400" />,
      badge: pendingAlertsCount > 0 ? pendingAlertsCount : undefined,
    },
    {
      id: 'reports',
      label: 'التقارير والاستعلامات',
      icon: <BarChart3 className="w-4 h-4 shrink-0" />,
    },
    {
      id: 'database',
      label: 'قاعدة البيانات والكود',
      icon: <Database className="w-4 h-4 shrink-0" />,
    },
    {
      id: 'share',
      label: 'رابط النظام والمشاركة',
      icon: <Share2 className="w-4 h-4 shrink-0" />,
    },
  ];

  return (
    <header className="bg-slate-900 border-b border-slate-800 sticky top-0 z-50">
      {/* Top tier: Brand & Context selectors */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-3 flex items-center justify-between gap-4 flex-wrap">
        {/* Brand */}
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-blue-600 flex items-center justify-center text-white shadow-md shadow-blue-500/20">
            <GraduationCap className="w-6 h-6" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="font-bold text-lg text-white tracking-tight">نظام الحضور الذكي</span>
              <span className="text-xs bg-blue-500/10 text-blue-400 border border-blue-500/20 px-2 py-0.5 rounded font-mono">
                TOTP 5s
              </span>
            </div>
            <p className="text-xs text-slate-400 hidden sm:block">
              نظام جامعي لمكافحة الغش بالباركود المتجدد تلقائياً
            </p>
          </div>
        </div>

        {/* Course & Lecture Selector Strip */}
        <div className="flex items-center gap-2 sm:gap-3 flex-wrap">
          <div className="flex items-center gap-1.5 bg-slate-800/80 border border-slate-700/60 rounded-lg px-2.5 py-1.5">
            <span className="text-xs text-slate-400 shrink-0 font-medium">المقرر:</span>
            <select
              value={selectedCourseId}
              onChange={(e) => setSelectedCourseId(Number(e.target.value))}
              className="bg-transparent text-xs text-white font-medium outline-none cursor-pointer pr-1"
            >
              {courses.map((c) => (
                <option key={c.course_id} value={c.course_id} className="bg-slate-900 text-white">
                  {c.course_name} ({c.course_code})
                </option>
              ))}
            </select>
          </div>

          <div className="flex items-center gap-1.5 bg-slate-800/80 border border-slate-700/60 rounded-lg px-2.5 py-1.5">
            <span className="text-xs text-slate-400 shrink-0 font-medium">المحاضرة:</span>
            <select
              value={selectedLectureId}
              onChange={(e) => setSelectedLectureId(Number(e.target.value))}
              className="bg-transparent text-xs text-white font-medium outline-none cursor-pointer max-w-[140px] truncate"
            >
              {courseLectures.map((l) => (
                <option key={l.lecture_id} value={l.lecture_id} className="bg-slate-900 text-white">
                  محاضرة #{l.lecture_id} ({l.lecture_date})
                </option>
              ))}
            </select>
          </div>

          {/* Theme switcher */}
          <button
            onClick={() => setIsDark(!isDark)}
            title={isDark ? 'التبديل إلى الوضع النهاري' : 'التبديل إلى الوضع الليلي'}
            className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-xs text-slate-200 border border-slate-700/60 transition-colors cursor-pointer"
            aria-label="تبديل المظهر"
          >
            {isDark ? <Sun className="w-3.5 h-3.5 text-amber-400" /> : <Moon className="w-3.5 h-3.5 text-blue-400" />}
            <span className="hidden sm:inline">{isDark ? 'الوضع النهاري' : 'الوضع الليلي'}</span>
          </button>

          {/* Quick utility controls */}
          <button
            onClick={() => setSoundEnabled(!soundEnabled)}
            title={soundEnabled ? 'كتم التنبيه الصوتي' : 'تفعيل التنبيه الصوتي'}
            className="p-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 transition-colors border border-slate-700/60"
            aria-label="تبديل الصوت"
          >
            {soundEnabled ? <Volume2 className="w-4 h-4 text-emerald-400" /> : <VolumeX className="w-4 h-4 text-slate-500" />}
          </button>

          <button
            onClick={() => {
              if (window.confirm('هل تريد استعادة البيانات التجريبية الافتراضية؟')) {
                resetDatabase();
              }
            }}
            title="استعادة البيانات التجريبية"
            className="p-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-amber-400 transition-colors border border-slate-700/60"
            aria-label="استعادة البيانات"
          >
            <RotateCcw className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Navigation tabs row */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        <nav className="flex items-center gap-1 sm:gap-2 overflow-x-auto py-2 no-scrollbar">
          {navItems.map((item) => {
            const isActive = activeView === item.id;
            return (
              <button
                key={item.id}
                onClick={() => setActiveView(item.id)}
                className={`flex items-center gap-2 px-3.5 py-2 text-xs sm:text-sm font-medium rounded-lg whitespace-nowrap shrink-0 transition-all ${
                  isActive
                    ? 'bg-blue-600 text-white shadow-sm shadow-blue-500/20'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
                }`}
              >
                {item.icon}
                <span>{item.label}</span>
                {item.badge !== undefined && (
                  <span className={`text-[10px] font-bold px-1.5 py-0.2 rounded-full ${
                    isActive ? 'bg-white text-blue-700' : 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                  }`}>
                    {item.badge}
                  </span>
                )}
              </button>
            );
          })}
        </nav>
      </div>
    </header>
  );
};
