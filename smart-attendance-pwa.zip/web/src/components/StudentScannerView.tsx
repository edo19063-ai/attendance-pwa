import React, { useState, useEffect, useRef, useCallback } from 'react';
import jsQR from 'jsqr';
import confetti from 'canvas-confetti';
import {
  ArrowRight,
  Camera,
  CameraOff,
  CheckCircle2,
  AlertCircle,
  Loader2,
  MapPin,
  KeyRound,
  Eye,
  EyeOff,
  SwitchCamera,
  Volume2,
  VolumeX,
  Send,
  Star,
} from 'lucide-react';
import { useAttendance } from '../context/AttendanceContext';
import { DEFAULT_STUDENT_PHOTO_URL } from '../data/initialData';
import { playSuccessChime, playErrorChime, unlockAudio } from '../utils/audio';
import { scanAttendance, submitFeedback, errorMessage, ApiError } from '../services/api';

interface StudentScannerViewProps {
  onBackToLive?: () => void;
  onOpenExcuses?: () => void;
}

// رمز الحضور الصادر من الخادم: 16 خانة سداسية عشرية
const TOKEN_PATTERN = /^[0-9a-f]{16}$/i;
const UNIVERSITY_ID_KEY = 'attendance_university_id';
const COOLDOWN_MS = 2500;

interface ResultState {
  success: boolean;
  message: string;
  studentName?: string;
  universityId?: string;
  code?: string;
  /** رمز قصير العمر من الخادم لتقييم المحاضرة (لا نحتفظ بالكود السري) */
  feedbackToken?: string;
  points?: number;
}

export const StudentScannerView: React.FC<StudentScannerViewProps> = ({ onBackToLive, onOpenExcuses }) => {
  const {
    students,
    courses,
    lectures,
    selectedCourseId,
    selectedLectureId,
    setSelectedCourseId,
    setSelectedLectureId,
  } = useAttendance();

  // ---- هوية الطالب (الكود السري لا يُحفظ في أي مكان) ----
  const [universityId, setUniversityId] = useState<string>(() => {
    try {
      return localStorage.getItem(UNIVERSITY_ID_KEY) ?? '';
    } catch {
      return '';
    }
  });
  const [secretCode, setSecretCode] = useState<string>('');
  const [showSecret, setShowSecret] = useState<boolean>(false);

  // ---- الحالة ----
  const [manualToken, setManualToken] = useState<string>('');
  const [result, setResult] = useState<ResultState | null>(null);
  const [isProcessing, setIsProcessing] = useState<boolean>(false);
  const [soundAlert, setSoundAlert] = useState<boolean>(true);
  const [cameraActive, setCameraActive] = useState<boolean>(false);
  const [cameraError, setCameraError] = useState<string | null>(null);
  const [facingMode, setFacingMode] = useState<'environment' | 'user'>('environment');
  const [hint, setHint] = useState<string | null>(null);

  // ---- تقييم المحاضرة ----
  const [feedbackScore, setFeedbackScore] = useState<number>(9);
  const [feedbackMessage, setFeedbackMessage] = useState<string | null>(null);
  const [isSubmittingFeedback, setIsSubmittingFeedback] = useState<boolean>(false);
  const [feedbackSent, setFeedbackSent] = useState<boolean>(false);

  const videoRef = useRef<HTMLVideoElement | null>(null);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const loopRef = useRef<number | null>(null);
  const busyRef = useRef<boolean>(false); // قفل متزامن (حلقة الكاميرا لا ترى حالة React الحديثة)
  const lastRejectedRef = useRef<string>('');

  // قيم يحتاجها معالج المسح داخل حلقة الكاميرا دون إعادة تشغيلها
  const latest = useRef({ universityId, secretCode, selectedLectureId, soundAlert });
  latest.current = { universityId, secretCode, selectedLectureId, soundAlert };

  const selectedLecture = lectures.find((l) => l.lecture_id === selectedLectureId);
  const selectedCourse = courses.find((c) => c.course_id === selectedCourseId);
  const courseLectures = lectures.filter((l) => l.course_id === selectedCourseId);

  const matchedStudent = result?.universityId
    ? students.find((s) => s.university_id.toLowerCase() === result.universityId!.toLowerCase())
    : undefined;
  const points = result?.points ?? 0;

  // ------------------------------------------------------------------
  // إرسال الرمز إلى الخادم (كل التحقق هناك)
  // ------------------------------------------------------------------
  const submitToken = useCallback(async (rawToken: string) => {
    if (busyRef.current) return;
    const { universityId: uid, secretCode: code, selectedLectureId: lectureId, soundAlert: sound } = latest.current;
    const token = rawToken.trim();

    if (!uid.trim() || !code.trim()) {
      setHint('أدخل رقمك الجامعي وكودك السري أولاً');
      return;
    }
    if (!TOKEN_PATTERN.test(token)) {
      if (lastRejectedRef.current !== token) {
        lastRejectedRef.current = token;
        setHint('هذا ليس رمز حضور صالحاً. امسح الباركود المعروض على شاشة المحاضر');
      }
      return;
    }

    busyRef.current = true;
    setIsProcessing(true);
    setHint(null);
    unlockAudio();
    try {
      const res = await scanAttendance({
        lectureId,
        universityId: uid.trim(),
        secretCode: code.trim(),
        token,
      });
      try {
        localStorage.setItem(UNIVERSITY_ID_KEY, uid.trim());
      } catch {
        /* ignore */
      }
      setSecretCode(''); // لا نُبقي الكود السري في الذاكرة بعد النجاح
      setFeedbackSent(false);
      setFeedbackMessage(null);
      setResult({
        success: true,
        universityId: uid.trim(),
        studentName: res.studentName,
        feedbackToken: res.feedbackToken,
        points: res.participationPoints,
        message: res.alreadyRecorded
          ? 'حضورك مسجّل مسبقاً في هذه المحاضرة'
          : res.status === 'Late'
          ? 'تم تسجيل حضورك (متأخر)'
          : 'تم تسجيل حضورك بنجاح',
      });
      if (sound) playSuccessChime();
      if (!res.alreadyRecorded) {
        try {
          confetti({ particleCount: 60, spread: 70, origin: { y: 0.7 } });
        } catch {
          /* ignore */
        }
        navigator.vibrate?.(200);
      }
    } catch (e) {
      setResult({
        success: false,
        universityId: uid.trim(),
        message: errorMessage(e, 'تعذر تسجيل الحضور'),
        code: e instanceof ApiError ? e.code : undefined,
      });
      if (sound) playErrorChime();
    } finally {
      // فترة تهدئة قصيرة كي لا تُرسل الكاميرا الرمز نفسه عشرات المرات
      setTimeout(() => {
        busyRef.current = false;
        setIsProcessing(false);
      }, COOLDOWN_MS);
    }
  }, []);

  // ------------------------------------------------------------------
  // الكاميرا
  // ------------------------------------------------------------------
  const stopCamera = useCallback(() => {
    if (loopRef.current !== null) {
      cancelAnimationFrame(loopRef.current);
      loopRef.current = null;
    }
    if (streamRef.current) {
      streamRef.current.getTracks().forEach((t) => t.stop());
      streamRef.current = null;
    }
    setCameraActive(false);
  }, []);

  const startLoop = useCallback(() => {
    const tick = () => {
      const video = videoRef.current;
      const canvas = canvasRef.current;
      if (video && canvas && video.readyState === video.HAVE_ENOUGH_DATA && !busyRef.current) {
        canvas.width = video.videoWidth;
        canvas.height = video.videoHeight;
        const ctx = canvas.getContext('2d', { willReadFrequently: true });
        if (ctx) {
          ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
          const img = ctx.getImageData(0, 0, canvas.width, canvas.height);
          const code = jsQR(img.data, img.width, img.height, { inversionAttempts: 'dontInvert' });
          if (code?.data) submitToken(code.data);
        }
      }
      loopRef.current = requestAnimationFrame(tick);
    };
    loopRef.current = requestAnimationFrame(tick);
  }, [submitToken]);

  const startCamera = useCallback(async () => {
    setCameraError(null);
    unlockAudio();
    stopCamera();
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode, width: { ideal: 640 }, height: { ideal: 480 } },
        audio: false,
      });
      streamRef.current = stream;
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        videoRef.current.setAttribute('playsinline', 'true'); // مطلوب في iOS
        await videoRef.current.play();
        setCameraActive(true);
        startLoop();
      }
    } catch (e) {
      const msg = e instanceof Error ? e.message : String(e);
      setCameraError(
        msg.includes('Permission') || msg.includes('NotAllowed')
          ? 'لم يتم منح إذن الكاميرا. يمكنك إدخال الرمز يدوياً أدناه.'
          : 'الكاميرا غير متاحة (تتطلب HTTPS). يمكنك إدخال الرمز يدوياً أدناه.'
      );
      setCameraActive(false);
    }
  }, [facingMode, startLoop, stopCamera]);

  // إيقاف الكاميرا عند مغادرة الصفحة
  useEffect(() => stopCamera, [stopCamera]);

  // إعادة التشغيل عند تبديل الكاميرا الأمامية/الخلفية
  const wasActive = useRef(false);
  wasActive.current = cameraActive;
  useEffect(() => {
    if (wasActive.current) startCamera();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [facingMode]);

  // ------------------------------------------------------------------
  // التقييم
  // ------------------------------------------------------------------
  const handleFeedback = async () => {
    if (!result?.feedbackToken || isSubmittingFeedback) return;
    setIsSubmittingFeedback(true);
    try {
      await submitFeedback({ feedbackToken: result.feedbackToken, score: feedbackScore });
      setFeedbackMessage('شكراً لك! تم إرسال تقييمك للمحاضرة بنجاح.');
      setFeedbackSent(true);
    } catch (e) {
      setFeedbackMessage(errorMessage(e));
      if (e instanceof ApiError && e.code === 'already_rated') setFeedbackSent(true);
    } finally {
      setIsSubmittingFeedback(false);
    }
  };

  const inputClass =
    'w-full bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl px-3 py-2.5 text-sm text-slate-900 dark:text-white placeholder-slate-400 outline-none focus:border-blue-500 transition-colors';

  return (
    <div className="max-w-xl mx-auto p-4 sm:p-6 space-y-5">
      {/* الرأس */}
      <div className="flex items-start justify-between gap-3">
        <div>
          <h1 className="text-xl font-bold text-slate-900 dark:text-white">تسجيل الحضور</h1>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
            {selectedCourse?.course_name} ({selectedCourse?.course_code}) · {selectedLecture?.topic}
          </p>
        </div>
        {onBackToLive && (
          <button
            onClick={onBackToLive}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-xs text-slate-700 dark:text-slate-300 rounded-lg border border-slate-200 dark:border-slate-700 cursor-pointer"
          >
            <span>شاشة الأستاذ</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        )}
      </div>

      {/* اختيار المقرر والمحاضرة */}
      <div className="grid grid-cols-2 gap-3">
        <select
          value={selectedCourseId}
          onChange={(e) => setSelectedCourseId(Number(e.target.value))}
          className={inputClass}
          aria-label="المقرر"
        >
          {courses.map((c) => (
            <option key={c.course_id} value={c.course_id}>
              {c.course_name}
            </option>
          ))}
        </select>
        <select
          value={selectedLectureId}
          onChange={(e) => setSelectedLectureId(Number(e.target.value))}
          className={inputClass}
          aria-label="المحاضرة"
        >
          {courseLectures.map((l) => (
            <option key={l.lecture_id} value={l.lecture_id}>
              #{l.lecture_id} · {l.lecture_date}
            </option>
          ))}
        </select>
      </div>

      {/* الهوية */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-4 space-y-3 shadow-sm">
        <div className="flex items-center gap-2 text-sm font-bold text-slate-900 dark:text-white">
          <KeyRound className="w-4 h-4 text-amber-500" />
          <span>هويتك</span>
        </div>
        <input
          type="text"
          inputMode="numeric"
          autoComplete="username"
          value={universityId}
          onChange={(e) => setUniversityId(e.target.value)}
          placeholder="الرقم الجامعي"
          className={inputClass}
        />
        <div className="relative">
          <input
            type={showSecret ? 'text' : 'password'}
            autoComplete="off"
            value={secretCode}
            onChange={(e) => setSecretCode(e.target.value.toUpperCase())}
            placeholder="الكود السري (سلّمه لك المحاضر)"
            className={`${inputClass} font-mono tracking-widest pl-10`}
          />
          <button
            type="button"
            onClick={() => setShowSecret((v) => !v)}
            className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 cursor-pointer"
            aria-label={showSecret ? 'إخفاء الكود' : 'إظهار الكود'}
          >
            {showSecret ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
          </button>
        </div>
        <div className="flex items-start gap-2 text-[11px] text-slate-500 dark:text-slate-400">
          <MapPin className="w-3.5 h-3.5 shrink-0 mt-0.5 text-rose-500" />
          <span>
            يشترط وجودك داخل القاعة{selectedLecture?.hall_name ? ` (${selectedLecture.hall_name})` : ''}. سيطلب المتصفح إذن
            الموقع عند المسح، ويتم التحقق منه على الخادم.
          </span>
        </div>
      </div>

      {/* الكاميرا */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-4 space-y-3 shadow-sm">
        <div className="relative aspect-[4/3] bg-slate-950 rounded-xl overflow-hidden flex items-center justify-center">
          <video ref={videoRef} className={`w-full h-full object-cover ${cameraActive ? '' : 'hidden'}`} muted playsInline />
          <canvas ref={canvasRef} className="hidden" />
          {!cameraActive && (
            <div className="text-center text-slate-400 text-xs px-6 space-y-2">
              <CameraOff className="w-8 h-8 mx-auto text-slate-600" />
              <p>الكاميرا متوقفة</p>
            </div>
          )}
          {cameraActive && (
            <div className="absolute inset-6 border-2 border-emerald-400/70 rounded-xl pointer-events-none" />
          )}
          {isProcessing && (
            <div className="absolute inset-0 bg-black/55 flex items-center justify-center text-white text-sm gap-2">
              <Loader2 className="w-5 h-5 animate-spin" />
              <span>جارٍ التحقق من الخادم...</span>
            </div>
          )}
        </div>

        {cameraError && (
          <div className="p-2.5 rounded-lg text-xs bg-amber-500/10 text-amber-700 dark:text-amber-300 border border-amber-500/20">
            {cameraError}
          </div>
        )}
        {hint && (
          <div className="p-2.5 rounded-lg text-xs bg-blue-500/10 text-blue-700 dark:text-blue-300 border border-blue-500/20">
            {hint}
          </div>
        )}

        <div className="flex items-center gap-2">
          <button
            onClick={cameraActive ? stopCamera : startCamera}
            className="flex-1 px-4 py-2.5 bg-blue-600 hover:bg-blue-500 text-white rounded-xl text-xs font-bold flex items-center justify-center gap-2 cursor-pointer"
          >
            {cameraActive ? <CameraOff className="w-4 h-4" /> : <Camera className="w-4 h-4" />}
            <span>{cameraActive ? 'إيقاف الكاميرا' : 'تشغيل الكاميرا ومسح الباركود'}</span>
          </button>
          <button
            onClick={() => setFacingMode((m) => (m === 'environment' ? 'user' : 'environment'))}
            className="p-2.5 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 rounded-xl text-slate-600 dark:text-slate-300 cursor-pointer"
            title="تبديل الكاميرا"
          >
            <SwitchCamera className="w-4 h-4" />
          </button>
          <button
            onClick={() => setSoundAlert((v) => !v)}
            className="p-2.5 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 rounded-xl text-slate-600 dark:text-slate-300 cursor-pointer"
            title={soundAlert ? 'كتم الصوت' : 'تشغيل الصوت'}
          >
            {soundAlert ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
          </button>
        </div>

        {/* إدخال الرمز يدوياً */}
        <div className="flex items-center gap-2 pt-1">
          <input
            type="text"
            value={manualToken}
            onChange={(e) => setManualToken(e.target.value.trim())}
            onKeyDown={(e) => {
              if (e.key === 'Enter') submitToken(manualToken);
            }}
            maxLength={16}
            placeholder="أو اكتب الرمز الظاهر على الشاشة (16 خانة)"
            className={`${inputClass} font-mono text-xs`}
            dir="ltr"
          />
          <button
            onClick={() => submitToken(manualToken)}
            disabled={isProcessing || !manualToken}
            className="px-4 py-2.5 bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 cursor-pointer"
          >
            <Send className="w-3.5 h-3.5" />
            <span>إرسال</span>
          </button>
        </div>
        <p className="text-[11px] text-slate-500 dark:text-slate-400">
          الرمز يتغير كل بضع ثوانٍ. إن انتهت صلاحيته امسح الشاشة مجدداً مباشرة.
        </p>
      </div>

      {/* النتيجة */}
      {result && (
        <div
          className={`rounded-2xl p-4 border space-y-3 animate-fade-in ${
            result.success
              ? 'bg-emerald-500/10 border-emerald-500/30'
              : 'bg-rose-500/10 border-rose-500/30'
          }`}
          role="status"
        >
          <div className="flex items-start gap-3">
            {result.success ? (
              <img
                src={matchedStudent?.photo_url || DEFAULT_STUDENT_PHOTO_URL}
                alt={result.studentName}
                className="w-14 h-14 rounded-full object-cover border-2 border-emerald-400 shrink-0"
              />
            ) : (
              <AlertCircle className="w-6 h-6 text-rose-500 shrink-0 mt-0.5" />
            )}
            <div className="min-w-0">
              <div
                className={`text-sm font-bold ${
                  result.success ? 'text-emerald-700 dark:text-emerald-300' : 'text-rose-700 dark:text-rose-300'
                }`}
              >
                {result.success && <CheckCircle2 className="w-4 h-4 inline ml-1" />}
                {result.message}
              </div>
              {result.success && result.studentName && (
                <div className="text-xs text-slate-600 dark:text-slate-300 mt-1">
                  {result.studentName}
                  {points > 0 && <span className="mr-2 text-amber-600 dark:text-amber-400">· نقاط التفاعل: {points} 🌟</span>}
                </div>
              )}
            </div>
          </div>
          {!result.success && onOpenExcuses && (
            <button
              onClick={onOpenExcuses}
              className="text-xs text-blue-600 dark:text-blue-400 hover:underline cursor-pointer"
            >
              هل لديك عذر؟ قدّم طلب عذر غياب
            </button>
          )}
        </div>
      )}

      {/* تقييم المحاضرة بعد النجاح */}
      {result?.success && result.feedbackToken && (
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-4 space-y-3 shadow-sm">
          <div className="flex items-center gap-2 text-sm font-bold text-slate-900 dark:text-white">
            <Star className="w-4 h-4 text-amber-500" />
            <span>ما مدى استيعابك للمحاضرة؟</span>
          </div>
          <div className="flex items-center gap-3">
            <input
              type="range"
              min={1}
              max={10}
              value={feedbackScore}
              onChange={(e) => setFeedbackScore(Number(e.target.value))}
              disabled={feedbackSent}
              className="flex-1 accent-blue-600"
            />
            <span className="font-mono font-bold text-blue-600 dark:text-blue-400 w-6 text-center">{feedbackScore}</span>
          </div>
          <button
            onClick={handleFeedback}
            disabled={feedbackSent || isSubmittingFeedback}
            className="w-full px-4 py-2 bg-slate-900 dark:bg-slate-700 hover:opacity-90 disabled:opacity-50 text-white rounded-xl text-xs font-bold cursor-pointer"
          >
            {feedbackSent ? 'تم إرسال تقييمك' : isSubmittingFeedback ? 'جارٍ الإرسال...' : 'إرسال التقييم'}
          </button>
          {feedbackMessage && <p className="text-xs text-slate-600 dark:text-slate-300">{feedbackMessage}</p>}
        </div>
      )}
    </div>
  );
};
