import React, { useState } from 'react';
import {
  FileText,
  CheckCircle2,
  XCircle,
  Clock,
  Send,
  AlertCircle,
  ExternalLink,
  User,
  GraduationCap,
  Calendar,
  Sparkles,
  Trophy,
  Check,
  Search,
  Filter,
  KeyRound,
  Eye,
  EyeOff,
  Loader2,
  ListChecks,
} from 'lucide-react';
import { useAttendance } from '../context/AttendanceContext';
import { ExcuseStatus } from '../types/attendance';
import { InstructorGate } from './InstructorGate';
import { useServerExcuses, useLectureDetails } from '../hooks/useServerAttendance';
import { submitExcuse, fetchMyExcuses, errorMessage, type ServerExcuse } from '../services/api';

const UNIVERSITY_ID_KEY = 'attendance_university_id';

/** يعرض الرابط فقط إن كان http/https (يمنع javascript: وغيرها). */
const safeHref = (url?: string): string | undefined => (url && /^https?:\/\//i.test(url) ? url : undefined);

const STATUS_LABEL: Record<ServerExcuse['status'], string> = {
  pending: 'قيد المراجعة',
  accepted: 'مقبول',
  rejected: 'مرفوض',
};

// ======================================================================
// الجزء العام: تقديم الطالب لعذره (بالرقم الجامعي والكود السري)
// ======================================================================
const StudentExcusePanel: React.FC = () => {
  const { courses, lectures, selectedLectureId } = useAttendance();

  const [universityId, setUniversityId] = useState<string>(() => {
    try {
      return localStorage.getItem(UNIVERSITY_ID_KEY) ?? '';
    } catch {
      return '';
    }
  });
  const [secretCode, setSecretCode] = useState<string>('');
  const [showSecret, setShowSecret] = useState<boolean>(false);
  const [lectureId, setLectureId] = useState<number>(selectedLectureId);
  const [reasonText, setReasonText] = useState<string>('');
  const [documentUrl, setDocumentUrl] = useState<string>('');
  const [submitting, setSubmitting] = useState<boolean>(false);
  const [formFeedback, setFormFeedback] = useState<{ success: boolean; message: string } | null>(null);
  const [mine, setMine] = useState<ServerExcuse[] | null>(null);
  const [loadingMine, setLoadingMine] = useState<boolean>(false);

  const inputClass =
    'w-full bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl px-3 py-2.5 text-xs text-slate-900 dark:text-white placeholder:text-slate-400 outline-none focus:border-blue-500';

  const needCredentials = (): boolean => {
    if (!universityId.trim() || !secretCode.trim()) {
      setFormFeedback({ success: false, message: 'أدخل رقمك الجامعي وكودك السري أولاً' });
      return false;
    }
    return true;
  };

  const handleSubmitExcuse = async (e: React.FormEvent) => {
    e.preventDefault();
    if (submitting) return;
    if (!needCredentials()) return;
    if (!reasonText.trim()) {
      setFormFeedback({ success: false, message: 'يرجى كتابة سبب العذر بالتفصيل' });
      return;
    }
    setSubmitting(true);
    setFormFeedback(null);
    try {
      await submitExcuse({
        universityId: universityId.trim(),
        secretCode: secretCode.trim(),
        lectureId,
        reasonText: reasonText.trim(),
        documentUrl: documentUrl.trim() || undefined,
      });
      try {
        localStorage.setItem(UNIVERSITY_ID_KEY, universityId.trim());
      } catch {
        /* ignore */
      }
      setFormFeedback({ success: true, message: 'تم إرسال العذر بنجاح وهو الآن قيد المراجعة من الأستاذ' });
      setReasonText('');
      setDocumentUrl('');
      setSecretCode(''); // لا نُبقي الكود السري بعد الإرسال
      setMine(null);
    } catch (err) {
      setFormFeedback({ success: false, message: errorMessage(err, 'تعذر إرسال العذر') });
    } finally {
      setSubmitting(false);
    }
  };

  const handleShowMine = async () => {
    if (loadingMine || !needCredentials()) return;
    setLoadingMine(true);
    try {
      const r = await fetchMyExcuses({ universityId: universityId.trim(), secretCode: secretCode.trim() });
      setMine(r.excuses);
      setFormFeedback(null);
    } catch (err) {
      setFormFeedback({ success: false, message: errorMessage(err, 'تعذر جلب أعذارك') });
    } finally {
      setLoadingMine(false);
    }
  };

  return (
    <div className="bg-white dark:bg-slate-900/90 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 shadow-sm dark:shadow-xl">
      <div className="flex items-center gap-2 mb-3">
        <Send className="w-4 h-4 text-blue-500" />
        <h2 className="font-bold text-sm text-slate-900 dark:text-white">تقديم عذر إلكتروني جديد</h2>
      </div>
      <p className="text-xs text-slate-500 dark:text-slate-400 mb-4">
        يمكن للطالب رفع التقرير الطبي أو العذر الرسمي لتوثيقه وإرساله لمراجعة أستاذ المادة. التقديم يتطلب هويتك (رقمك الجامعي وكودك السري):
      </p>

      <form onSubmit={handleSubmitExcuse} className="space-y-3.5">
        <div>
          <label className="text-[11px] text-slate-500 dark:text-slate-400 flex items-center gap-1.5 mb-1">
            <KeyRound className="w-3.5 h-3.5 text-amber-500" />
            <span>1. هويتك:</span>
          </label>
          <div className="space-y-2">
            <input
              type="text"
              inputMode="numeric"
              autoComplete="username"
              value={universityId}
              onChange={(e) => setUniversityId(e.target.value)}
              placeholder="الرقم الجامعي"
              className={inputClass}
            />
            <div className="relative">
              <input
                type={showSecret ? 'text' : 'password'}
                autoComplete="off"
                value={secretCode}
                onChange={(e) => setSecretCode(e.target.value.toUpperCase())}
                placeholder="الكود السري"
                className={`${inputClass} font-mono tracking-widest pl-10`}
              />
              <button
                type="button"
                onClick={() => setShowSecret((v) => !v)}
                className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 cursor-pointer"
                aria-label={showSecret ? 'إخفاء الكود' : 'إظهار الكود'}
              >
                {showSecret ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
            </div>
          </div>
        </div>

        <div>
          <label className="text-[11px] text-slate-500 dark:text-slate-400 block mb-1">
            2. حدد المحاضرة المراد تقديم العذر لها:
          </label>
          <select
            value={lectureId}
            onChange={(e) => setLectureId(Number(e.target.value))}
            className={inputClass}
          >
            {lectures.map((l) => {
              const c = courses.find((crs) => crs.course_id === l.course_id);
              return (
                <option key={l.lecture_id} value={l.lecture_id} className="bg-white dark:bg-slate-900">
                  محاضرة #{l.lecture_id}: {l.topic} ({c?.course_code})
                </option>
              );
            })}
          </select>
        </div>

        <div>
          <label className="text-[11px] text-slate-500 dark:text-slate-400 block mb-1">
            3. سبب العذر بالتفصيل:
          </label>
          <textarea
            rows={3}
            maxLength={1000}
            value={reasonText}
            onChange={(e) => setReasonText(e.target.value)}
            placeholder="اكتب سبب الغياب بالتفصيل (مثل: مراجعة المستشفى، ظرف عائلي، مهمة رسمية)..."
            className={`${inputClass} resize-none`}
            required
          />
        </div>

        <div>
          <label className="text-[11px] text-slate-500 dark:text-slate-400 block mb-1">
            4. رابط المستند / التقرير الطبي (اختياري، يبدأ بـ https):
          </label>
          <input
            type="url"
            value={documentUrl}
            onChange={(e) => setDocumentUrl(e.target.value)}
            placeholder="https://university.edu.sa/reports/medical.pdf"
            className={`${inputClass} font-mono`}
          />
        </div>

        <button
          type="submit"
          disabled={submitting}
          className="w-full py-2.5 bg-blue-600 hover:bg-blue-500 disabled:opacity-60 text-white rounded-xl text-xs font-bold flex items-center justify-center gap-2 transition-colors cursor-pointer shadow-md shadow-blue-600/20"
        >
          {submitting ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Send className="w-3.5 h-3.5" />}
          <span>{submitting ? 'جارٍ الإرسال...' : 'إرسال طلب العذر للأستاذ'}</span>
        </button>

        <button
          type="button"
          onClick={handleShowMine}
          disabled={loadingMine}
          className="w-full py-2 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 disabled:opacity-60 text-slate-700 dark:text-slate-200 rounded-xl text-xs font-semibold flex items-center justify-center gap-2 cursor-pointer"
        >
          {loadingMine ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <ListChecks className="w-3.5 h-3.5" />}
          <span>عرض حالة أعذاري</span>
        </button>

        {formFeedback && (
          <div
            className={`p-3 rounded-xl text-xs font-medium flex items-center gap-2 animate-fade-in ${
              formFeedback.success
                ? 'bg-emerald-500/10 text-emerald-700 dark:text-emerald-300 border border-emerald-500/20'
                : 'bg-rose-500/10 text-rose-700 dark:text-rose-300 border border-rose-500/20'
            }`}
          >
            {formFeedback.success ? (
              <CheckCircle2 className="w-4 h-4 text-emerald-500 shrink-0" />
            ) : (
              <AlertCircle className="w-4 h-4 text-rose-500 shrink-0" />
            )}
            <span>{formFeedback.message}</span>
          </div>
        )}
      </form>

      {mine && (
        <div className="mt-4 space-y-2">
          <h3 className="text-xs font-bold text-slate-900 dark:text-white">أعذاري المقدّمة</h3>
          {mine.length === 0 ? (
            <p className="text-[11px] text-slate-400">لا توجد أعذار مقدّمة بعد.</p>
          ) : (
            mine.map((m) => (
              <div
                key={m.id}
                className="p-2.5 rounded-lg border border-slate-200 dark:border-slate-800 text-[11px] space-y-1"
              >
                <div className="flex items-center justify-between gap-2">
                  <span className="font-semibold text-slate-800 dark:text-slate-200">
                    #{m.lectureId} · {m.lectureTopic}
                  </span>
                  <span
                    className={`px-2 py-0.5 rounded-full font-bold border ${
                      m.status === 'accepted'
                        ? 'bg-emerald-500/15 text-emerald-600 dark:text-emerald-400 border-emerald-500/30'
                        : m.status === 'rejected'
                        ? 'bg-rose-500/15 text-rose-600 dark:text-rose-400 border-rose-500/30'
                        : 'bg-amber-500/15 text-amber-600 dark:text-amber-400 border-amber-500/30'
                    }`}
                  >
                    {STATUS_LABEL[m.status]}
                  </span>
                </div>
                {m.reviewNotes && <p className="text-slate-500 dark:text-slate-400">ملاحظة الأستاذ: {m.reviewNotes}</p>}
              </div>
            ))
          )}
        </div>
      )}
    </div>
  );
};

// ======================================================================
// جزء المحاضر (خلف تسجيل الدخول): المراجعة والقرار ولوحة الشرف
// ======================================================================
const InstructorExcuseBoard: React.FC = () => {
  const { selectedLectureId } = useAttendance();
  const { excuses, loaded, error, review } = useServerExcuses();
  const { studentsWithStatus } = useLectureDetails(selectedLectureId, 8000);

  // Filter and Tab state
  const [statusFilter, setStatusFilter] = useState<'all' | ExcuseStatus>('all');
  const [searchTerm, setSearchTerm] = useState<string>('');
  const [reviewNoteInputs, setReviewNoteInputs] = useState<Record<number, string>>({});
  const [reviewFeedback, setReviewFeedback] = useState<{ id: number; message: string; success: boolean } | null>(null);

  // Stats calculation
  const totalExcuses = excuses.length;
  const pendingCount = excuses.filter((e) => e.status === 'قيد المراجعة').length;
  const acceptedCount = excuses.filter((e) => e.status === 'مقبول').length;
  const rejectedCount = excuses.filter((e) => e.status === 'مرفوض').length;

  // Filtered excuses list
  const filteredExcuses = excuses.filter((excuse) => {
    if (statusFilter !== 'all' && excuse.status !== statusFilter) return false;
    if (searchTerm.trim()) {
      const term = searchTerm.toLowerCase();
      const matchName = excuse.student_name?.toLowerCase().includes(term);
      const matchId = excuse.university_id?.toLowerCase().includes(term);
      const matchReason = excuse.reason_text.toLowerCase().includes(term);
      return matchName || matchId || matchReason;
    }
    return true;
  });

  // Handle instructor review (accept / reject): الخادم يحدّث سجل الحضور عند القبول
  const handleReview = async (excuseId: number, action: 'accept' | 'reject') => {
    const note = reviewNoteInputs[excuseId] || '';
    const res = await review(excuseId, action, note);
    setReviewFeedback({ id: excuseId, message: res.message, success: res.success });
    setTimeout(() => setReviewFeedback(null), 3500);
  };

  // لوحة الشرف: حضور تحقق منه الخادم بالـ GPS فعلاً (مسح داخل نطاق القاعة)
  const perfectStudents = studentsWithStatus
    .filter((r) => r.status === 'Present' && r.method === 'scan')
    .map((r) => ({
      student_id: r.student.student_id,
      full_name: r.student.full_name,
      university_id: r.student.university_id,
    }));

  return (
    <div className="space-y-6">
      {error && (
        <div className="p-3 bg-rose-500/10 border border-rose-500/20 text-rose-700 dark:text-rose-300 rounded-xl text-xs font-semibold">
          ⚠️ تعذر تحميل الأعذار من الخادم: {error}
        </div>
      )}
      {!loaded && !error && <div className="text-xs text-slate-500">⏳ جارٍ تحميل الأعذار من الخادم...</div>}

      {/* KPI Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-4 shadow-sm">
          <span className="text-xs text-slate-500 dark:text-slate-400 font-medium">إجمالي الطلبات</span>
          <div className="text-2xl font-extrabold font-mono text-slate-900 dark:text-white mt-1.5">
            {totalExcuses}
          </div>
          <span className="text-[10px] text-slate-400">سجل الأعذار المقدمة</span>
        </div>

        <div className="bg-white dark:bg-slate-900 border border-amber-500/30 rounded-2xl p-4 shadow-sm">
          <div className="flex items-center justify-between">
            <span className="text-xs text-amber-600 dark:text-amber-400 font-medium">قيد المراجعة</span>
            <Clock className="w-3.5 h-3.5 text-amber-500" />
          </div>
          <div className="text-2xl font-extrabold font-mono text-amber-600 dark:text-amber-400 mt-1.5">
            {pendingCount}
          </div>
          <span className="text-[10px] text-slate-400">تتطلب قرار الأستاذ</span>
        </div>

        <div className="bg-white dark:bg-slate-900 border border-emerald-500/30 rounded-2xl p-4 shadow-sm">
          <div className="flex items-center justify-between">
            <span className="text-xs text-emerald-600 dark:text-emerald-400 font-medium">أعذار مقبولة</span>
            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500" />
          </div>
          <div className="text-2xl font-extrabold font-mono text-emerald-600 dark:text-emerald-400 mt-1.5">
            {acceptedCount}
          </div>
          <span className="text-[10px] text-slate-400">حُدثت إلى مقبول بعذر</span>
        </div>

        <div className="bg-white dark:bg-slate-900 border border-rose-500/30 rounded-2xl p-4 shadow-sm">
          <div className="flex items-center justify-between">
            <span className="text-xs text-rose-600 dark:text-rose-400 font-medium">أعذار مرفوضة</span>
            <XCircle className="w-3.5 h-3.5 text-rose-500" />
          </div>
          <div className="text-2xl font-extrabold font-mono text-rose-600 dark:text-rose-400 mt-1.5">
            {rejectedCount}
          </div>
          <span className="text-[10px] text-slate-400">يظل الطالب مسجلاً غائباً</span>
        </div>
      </div>


      <div className="space-y-4">
          <div className="bg-white dark:bg-slate-900/90 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 shadow-sm dark:shadow-xl">
            <div className="flex items-center justify-between gap-3 mb-4 flex-wrap">
              <div className="flex items-center gap-2">
                <FileText className="w-4 h-4 text-blue-500" />
                <h2 className="font-bold text-sm text-slate-900 dark:text-white">طلبات الأعذار الواردة للمراجعة</h2>
              </div>

              {/* Status Filter Tabs */}
              <div className="flex items-center gap-1 bg-slate-100 dark:bg-slate-800 p-1 rounded-xl text-xs">
                <button
                  onClick={() => setStatusFilter('all')}
                  className={`px-2.5 py-1 rounded-lg font-medium transition-colors cursor-pointer ${
                    statusFilter === 'all'
                      ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-xs font-bold'
                      : 'text-slate-500 hover:text-slate-900 dark:hover:text-white'
                  }`}
                >
                  الكل ({totalExcuses})
                </button>
                <button
                  onClick={() => setStatusFilter('قيد المراجعة')}
                  className={`px-2.5 py-1 rounded-lg font-medium transition-colors cursor-pointer ${
                    statusFilter === 'قيد المراجعة'
                      ? 'bg-amber-500 text-white shadow-xs font-bold'
                      : 'text-slate-500 hover:text-amber-500'
                  }`}
                >
                  قيد المراجعة ({pendingCount})
                </button>
                <button
                  onClick={() => setStatusFilter('مقبول')}
                  className={`px-2.5 py-1 rounded-lg font-medium transition-colors cursor-pointer ${
                    statusFilter === 'مقبول'
                      ? 'bg-emerald-600 text-white shadow-xs font-bold'
                      : 'text-slate-500 hover:text-emerald-500'
                  }`}
                >
                  مقبول ({acceptedCount})
                </button>
                <button
                  onClick={() => setStatusFilter('مرفوض')}
                  className={`px-2.5 py-1 rounded-lg font-medium transition-colors cursor-pointer ${
                    statusFilter === 'مرفوض'
                      ? 'bg-rose-600 text-white shadow-xs font-bold'
                      : 'text-slate-500 hover:text-rose-500'
                  }`}
                >
                  مرفوض ({rejectedCount})
                </button>
              </div>
            </div>

            {/* Search Input */}
            <div className="relative mb-4">
              <Search className="w-4 h-4 text-slate-400 absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none" />
              <input
                type="text"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                placeholder="ابحث باسم الطالب، رقمه الجامعي، أو سبب العذر..."
                className="w-full bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700/80 rounded-xl pr-9 pl-3 py-2 text-xs text-slate-900 dark:text-white placeholder:text-slate-400 outline-none focus:border-blue-500"
              />
            </div>

            {/* Excuses List */}
            {filteredExcuses.length === 0 ? (
              <div className="py-12 text-center text-slate-400 dark:text-slate-500 text-xs">
                لا توجد طلبات أعذار مطابقة للشروط الحالية.
              </div>
            ) : (
              <div className="space-y-3.5 max-h-[600px] overflow-y-auto pr-1">
                {filteredExcuses.map((excuse) => {
                  const isPending = excuse.status === 'قيد المراجعة';
                  const isAccepted = excuse.status === 'مقبول';
                  const isRejected = excuse.status === 'مرفوض';

                  return (
                    <div
                      key={excuse.excuse_id}
                      className={`border rounded-xl p-4 transition-all ${
                        isPending
                          ? 'bg-slate-50/50 dark:bg-slate-950/40 border-amber-500/30 shadow-xs'
                          : isAccepted
                          ? 'bg-emerald-50/30 dark:bg-emerald-950/10 border-emerald-500/20'
                          : 'bg-rose-50/30 dark:bg-rose-950/10 border-rose-500/20'
                      }`}
                    >
                      <div className="flex items-start justify-between gap-3 mb-2 flex-wrap">
                        <div className="flex items-center gap-2">
                          <span className="w-7 h-7 rounded-full bg-blue-600 text-white flex items-center justify-center font-bold text-xs">
                            {excuse.student_name ? excuse.student_name.trim().charAt(0) : 'ط'}
                          </span>
                          <div>
                            <span className="font-bold text-xs text-slate-900 dark:text-white">
                              {excuse.student_name}
                            </span>
                            <span className="text-[10px] text-slate-400 font-mono mr-2">
                              ({excuse.university_id})
                            </span>
                          </div>
                        </div>

                        {/* Status Badge */}
                        <span
                          className={`text-[10px] px-2.5 py-0.5 rounded-full font-bold border ${
                            isPending
                              ? 'bg-amber-500/15 text-amber-600 dark:text-amber-400 border-amber-500/30'
                              : isAccepted
                              ? 'bg-emerald-500/15 text-emerald-600 dark:text-emerald-400 border-emerald-500/30'
                              : 'bg-rose-500/15 text-rose-600 dark:text-rose-400 border-rose-500/30'
                          }`}
                        >
                          {excuse.status}
                        </span>
                      </div>

                      {/* Course / Lecture context */}
                      <div className="text-[11px] text-slate-500 dark:text-slate-400 flex items-center gap-2 flex-wrap mb-2.5">
                        <span className="font-medium text-slate-700 dark:text-slate-300">
                          {excuse.course_name}
                        </span>
                        <span>·</span>
                        <span>المحاضرة #{excuse.lecture_id}: {excuse.lecture_topic}</span>
                        <span>·</span>
                        <span className="font-mono text-[10px]">{excuse.submitted_at}</span>
                      </div>

                      {/* Reason Description */}
                      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-lg p-2.5 text-xs text-slate-800 dark:text-slate-200 mb-3 leading-relaxed">
                        <p className="font-semibold text-[11px] text-slate-500 mb-1">بيان العذر:</p>
                        {excuse.reason_text}
                      </div>

                      {/* Document Link if available */}
                      {safeHref(excuse.document_url) && (
                        <div className="mb-3">
                          <a
                            href={safeHref(excuse.document_url)}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="inline-flex items-center gap-1.5 text-[11px] text-blue-600 dark:text-blue-400 hover:underline bg-blue-500/10 px-2.5 py-1 rounded-md border border-blue-500/20"
                          >
                            <ExternalLink className="w-3 h-3" />
                            <span>معاينة المستند / التقرير الطبي المرفق</span>
                          </a>
                        </div>
                      )}

                      {/* Review note if present */}
                      {excuse.review_notes && (
                        <div className="text-[11px] text-slate-500 dark:text-slate-400 bg-slate-100 dark:bg-slate-800/60 p-2 rounded-md mb-2">
                          <span className="font-semibold text-slate-700 dark:text-slate-300">ملاحظة الأستاذ: </span>
                          {excuse.review_notes}
                        </div>
                      )}

                      {/* Action buttons if pending */}
                      {isPending && (
                        <div className="pt-2 border-t border-slate-200 dark:border-slate-800 flex items-center justify-between gap-2 flex-wrap">
                          <input
                            type="text"
                            placeholder="ملاحظات المراجعة (اختياري)..."
                            value={reviewNoteInputs[excuse.excuse_id] || ''}
                            onChange={(e) =>
                              setReviewNoteInputs({
                                ...reviewNoteInputs,
                                [excuse.excuse_id]: e.target.value,
                              })
                            }
                            className="flex-1 bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-lg px-2.5 py-1.5 text-xs text-slate-900 dark:text-white outline-none focus:border-blue-500 min-w-[150px]"
                          />

                          <div className="flex items-center gap-2">
                            <button
                              onClick={() => handleReview(excuse.excuse_id, 'accept')}
                              className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg text-xs font-bold flex items-center gap-1 transition-colors cursor-pointer shadow-xs"
                            >
                              <CheckCircle2 className="w-3.5 h-3.5" />
                              <span>قبول العذر</span>
                            </button>

                            <button
                              onClick={() => handleReview(excuse.excuse_id, 'reject')}
                              className="px-3 py-1.5 bg-rose-600 hover:bg-rose-500 text-white rounded-lg text-xs font-bold flex items-center gap-1 transition-colors cursor-pointer shadow-xs"
                            >
                              <XCircle className="w-3.5 h-3.5" />
                              <span>رفض العذر</span>
                            </button>
                          </div>
                        </div>
                      )}

                      {reviewFeedback && reviewFeedback.id === excuse.excuse_id && (
                        <p className={`text-[11px] mt-2 font-semibold ${reviewFeedback.success ? 'text-emerald-500' : 'text-rose-500'}`}>
                          {reviewFeedback.success ? '✅' : '❌'} {reviewFeedback.message}
                        </p>
                      )}
                    </div>
                  );
                })}
              </div>
            )}
          </div>

          {/* 🌟 لوحة الشرف للطلاب المتميزين (حضور 100% مع تحقق GPS) */}
          <div className="bg-white dark:bg-slate-900/90 border border-emerald-500/30 rounded-2xl p-5 shadow-sm dark:shadow-xl bg-gradient-to-r from-emerald-500/5 to-transparent">
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center gap-2">
                <Trophy className="w-4 h-4 text-amber-500" />
                <h3 className="font-bold text-sm text-emerald-600 dark:text-emerald-400">
                  لوحة الشرف للحضور المكتمل (GPS Verified)
                </h3>
              </div>
              <span className="text-[10px] bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border border-emerald-500/20 px-2 py-0.5 rounded-full font-bold">
                API Endpoint
              </span>
            </div>

            <p className="text-xs text-slate-500 dark:text-slate-400 mb-3">
              الطلاب الذين حققوا حضوراً رسمياً موثقاً داخل قاعة المحاضرة الحالية عبر الـ GPS:
            </p>

            {perfectStudents.length === 0 ? (
              <div className="py-6 text-center text-slate-400 text-xs">
                في انتظار استكمال تسجيل حضور الطلاب بالقاعة...
              </div>
            ) : (
              <div className="space-y-2 max-h-48 overflow-y-auto pr-1">
                {perfectStudents.map((s, idx) => (
                  <div
                    key={s.student_id}
                    className="p-2.5 bg-emerald-500/10 border border-emerald-500/20 rounded-xl flex items-center justify-between text-xs"
                  >
                    <div className="flex items-center gap-2.5">
                      <span className="w-6 h-6 rounded-full bg-emerald-600 text-white flex items-center justify-center font-bold text-[10px]">
                        #{idx + 1}
                      </span>
                      <div>
                        <span className="font-bold text-slate-900 dark:text-white">{s.full_name}</span>
                        <span className="text-[10px] text-slate-400 font-mono mr-2">({s.university_id})</span>
                      </div>
                    </div>
                    <span className="text-[10px] text-emerald-600 dark:text-emerald-400 font-bold bg-white dark:bg-slate-900 px-2 py-0.5 rounded-full border border-emerald-500/20">
                      🏆 حضور 100%
                    </span>
                  </div>
                ))}
              </div>
            )}
          </div>
      </div>
    </div>
  );
};

// ======================================================================
export const ExcusesView: React.FC = () => {
  return (
    <div className="max-w-6xl mx-auto p-4 sm:p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between gap-4 flex-wrap border-b border-slate-200 dark:border-slate-800 pb-4">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-xl sm:text-2xl font-bold text-slate-900 dark:text-white tracking-tight">
              نظام الأعذار الإلكترونية ولوحة التميز
            </h1>
            <span className="text-xs bg-amber-500/10 text-amber-600 dark:text-amber-400 border border-amber-500/20 px-2 py-0.5 rounded font-bold font-mono">
              Online Excuses Workflow
            </span>
          </div>
          <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1">
            تقديم الأعذار الطبية والرسمية إلكترونياً، مراجعتها من الأستاذ، وتحديث سجلات الحضور تلقائياً
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        <div className="lg:col-span-5">
          <StudentExcusePanel />
        </div>
        <div className="lg:col-span-7">
          <InstructorGate>
            <InstructorExcuseBoard />
          </InstructorGate>
        </div>
      </div>
    </div>
  );
};
