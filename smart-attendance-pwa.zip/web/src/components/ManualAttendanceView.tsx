import React, { useState, useSyncExternalStore } from 'react';
import {
  CheckCheck,
  Save,
  Download,
  Search,
  CheckCircle2,
  XCircle,
  Clock,
  FileText,
  AlertCircle,
  KeyRound,
  RefreshCw,
  Loader2,
  X,
} from 'lucide-react';
import { useAttendance } from '../context/AttendanceContext';
import { DEFAULT_STUDENT_PHOTO_URL } from '../data/initialData';
import { AttendanceStatus } from '../types/attendance';
import { exportReportToPdf } from '../utils/pdfExport';
import { useLectureDetails, useAdvisorAlerts } from '../hooks/useServerAttendance';
import { rotateSecret, errorMessage, getAuthInfo, subscribeAuth } from '../services/api';

export const ManualAttendanceView: React.FC = () => {
  const { selectedLectureId } = useAttendance();

  // المحاضر: صلاحية كاملة. المعيد المفوَّض: لا يرى الأكواد السرية ولا تنبيهات الإرشاد.
  const auth = useSyncExternalStore(subscribeAuth, getAuthInfo, () => null);
  const isInstructor = auth?.role === 'instructor';
  const { alerts: advisorAlerts } = useAdvisorAlerts(isInstructor);

  const [searchTerm, setSearchTerm] = useState<string>('');
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const [isExportingPdf, setIsExportingPdf] = useState<boolean>(false);
  const [actionError, setActionError] = useState<string | null>(null);
  const [noteDrafts, setNoteDrafts] = useState<Record<number, string>>({});
  // الكود السري يُعرض مرة واحدة فقط عند التوليد (الخادم يخزّن تجزئته فقط)
  const [secretNotice, setSecretNotice] = useState<{ name: string; code: string } | null>(null);

  // مصدر البيانات: الخادم (يُحدَّث تلقائياً كل 8 ثوانٍ ليظهر من سجّل حضوره بنفسه)
  const { lecture, course, studentsWithStatus, loading, error, refresh, updateStatus, markAllPresent, addPoint } =
    useLectureDetails(selectedLectureId, 8000);

  const handleStatus = async (studentId: number, status: AttendanceStatus, notes: string) => {
    const res = await updateStatus(studentId, status, notes);
    setActionError(res.ok ? null : res.message ?? 'تعذر حفظ التغيير');
  };

  const handleNoteBlur = async (studentId: number, status: AttendanceStatus, saved: string) => {
    const draft = noteDrafts[studentId];
    if (draft === undefined) return;
    setNoteDrafts((prev) => {
      const { [studentId]: _removed, ...rest } = prev;
      return rest;
    });
    if (draft !== saved) await handleStatus(studentId, status, draft);
  };

  const handleMarkAll = async () => {
    const res = await markAllPresent();
    if (res.ok) {
      setActionError(null);
      setToastMessage('تم تحضير جميع الطلاب بنجاح');
      setTimeout(() => setToastMessage(null), 3500);
    } else {
      setActionError(`تعذر تحضير ${res.failed} طالب/طلاب`);
    }
  };

  const handleRotateSecret = async (studentId: number, name: string) => {
    try {
      const r = await rotateSecret(studentId);
      setSecretNotice({ name, code: r.secretCode });
      setActionError(null);
    } catch (e) {
      setActionError(errorMessage(e));
    }
  };

  // Statistics
  const total = studentsWithStatus.length;
  const presentCount = studentsWithStatus.filter((s) => s.status === 'Present').length;
  const absentCount = studentsWithStatus.filter((s) => s.status === 'Absent').length;
  const lateCount = studentsWithStatus.filter((s) => s.status === 'Late').length;
  const excusedCount = studentsWithStatus.filter((s) => s.status === 'Excused').length;

  const filteredStudents = studentsWithStatus.filter(
    (item) =>
      item.student.full_name.includes(searchTerm) ||
      item.student.university_id.includes(searchTerm)
  );

  const handleSave = async () => {
    await refresh(); // التغييرات تُحفظ على الخادم فور حدوثها؛ هذا الزر يحدّث العرض فقط
    setToastMessage('تم تحديث سجل الحضور من الخادم');
    setTimeout(() => {
      setToastMessage(null);
    }, 3500);
  };

  const handleExportCSV = () => {
    if (!lecture || !course) return;

    const headers = ['#', 'الرقم الجامعي', 'اسم الطالب', 'القسم', 'حالة الحضور', 'الملاحظات'];
    const rows = studentsWithStatus.map((item, idx) => [
      idx + 1,
      item.student.university_id,
      item.student.full_name,
      item.student.department_name || '',
      item.status === 'Present'
        ? 'حاضر'
        : item.status === 'Absent'
        ? 'غائب'
        : item.status === 'Late'
        ? 'متأخر'
        : 'بعذر',
      item.notes || '',
    ]);

    const csvContent =
      'data:text/csv;charset=utf-8,\uFEFF' +
      [headers.join(','), ...rows.map((e) => e.map((val) => `"${val}"`).join(','))].join('\n');

    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute(
      'download',
      `attendance_${course.course_code}_lecture_${lecture.lecture_id}_${lecture.lecture_date}.csv`
    );
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleExportPDF = async () => {
    if (!lecture || !course) return;
    setIsExportingPdf(true);
    try {
      await exportReportToPdf({
        filename: `attendance_${course.course_code}_lecture_${lecture.lecture_id}_${lecture.lecture_date}.pdf`,
        title: `كشف الحضور والغياب — ${course.course_name} (${course.course_code})`,
        subtitle: lecture.topic,
        metaItems: [
          { label: 'أستاذ المقرر', value: course.instructor_name },
          { label: 'تاريخ المحاضرة', value: lecture.lecture_date },
          { label: 'القاعة', value: lecture.hall_name || 'القاعة A1' },
        ],
        stats: [
          { label: 'إجمالي الطلاب', value: total, accent: 'slate' },
          { label: 'حاضر', value: presentCount, accent: 'emerald' },
          { label: 'غائب', value: absentCount, accent: 'rose' },
          { label: 'تأخر / عذر', value: `${lateCount} / ${excusedCount}`, accent: 'amber' },
        ],
        columns: [
          { header: '#', align: 'center', width: '40px' },
          { header: 'اسم الطالب', align: 'right' },
          { header: 'الرقم الجامعي', align: 'center' },
          { header: 'القسم', align: 'right' },
          { header: 'حالة الحضور', align: 'center' },
          { header: 'نقاط التفاعل', align: 'center' },
          { header: 'الملاحظات', align: 'right' },
        ],
        rows: studentsWithStatus.map((item, idx) => [
          { text: String(idx + 1), mono: true },
          { text: item.student.full_name, bold: true },
          { text: item.student.university_id, mono: true },
          { text: item.student.department_name || '—' },
          {
            text:
              item.status === 'Present'
                ? 'حاضر'
                : item.status === 'Absent'
                ? 'غائب'
                : item.status === 'Late'
                ? 'متأخر'
                : 'بعذر',
            badgeColor:
              item.status === 'Present'
                ? 'emerald'
                : item.status === 'Absent'
                ? 'rose'
                : item.status === 'Late'
                ? 'amber'
                : 'blue',
          },
          {
            text: `+${item.points}`,
            mono: true,
          },
          { text: item.notes || '—' },
        ]),
      });
      setToastMessage('تم تصدير وتنزيل كشف الحضور بصيغة PDF بنجاح!');
      setTimeout(() => setToastMessage(null), 3500);
    } finally {
      setIsExportingPdf(false);
    }
  };

  return (
    <div className="max-w-6xl mx-auto p-4 sm:p-6 space-y-6">
      {/* Toast Alert */}
      {toastMessage && (
        <div className="p-4 rounded-xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-300 text-sm font-semibold flex items-center gap-2 animate-fade-in shadow-lg">
          <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />
          <span>{toastMessage}</span>
        </div>
      )}

      {actionError && (
        <div className="p-4 rounded-xl bg-rose-500/10 border border-rose-500/20 text-rose-600 dark:text-rose-300 text-sm font-semibold flex items-center gap-2">
          <AlertCircle className="w-5 h-5 shrink-0" />
          <span>{actionError}</span>
        </div>
      )}
      {error && !actionError && (
        <div className="p-4 rounded-xl bg-amber-500/10 border border-amber-500/20 text-amber-700 dark:text-amber-300 text-sm font-semibold flex items-center gap-2">
          <AlertCircle className="w-5 h-5 shrink-0" />
          <span>تعذر تحميل البيانات من الخادم: {error}</span>
        </div>
      )}
      {loading && studentsWithStatus.length > 0 && (
        <div className="text-xs text-slate-500 flex items-center gap-2"><Loader2 className="w-3.5 h-3.5 animate-spin" /> جارٍ التحديث...</div>
      )}
      {secretNotice && (
        <div className="p-4 rounded-xl bg-amber-500/10 border border-amber-500/30 text-sm flex items-start justify-between gap-3">
          <div className="space-y-1">
            <div className="font-bold text-amber-700 dark:text-amber-300">
              🔑 الكود السري الجديد للطالب {secretNotice.name}
            </div>
            <code className="inline-block font-mono text-lg font-bold tracking-widest bg-white dark:bg-slate-900 border border-amber-500/30 px-3 py-1 rounded-lg text-slate-900 dark:text-amber-300 select-all">
              {secretNotice.code}
            </code>
            <p className="text-xs text-slate-600 dark:text-slate-400">
              يظهر هذا الكود مرة واحدة فقط ولا يمكن استرجاعه لاحقاً. سلّمه للطالب الآن.
            </p>
          </div>
          <button
            type="button"
            onClick={() => setSecretNotice(null)}
            className="p-1 rounded hover:bg-amber-500/20 text-slate-500 cursor-pointer"
            title="إغلاق"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* Main Container Card */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl shadow-sm dark:shadow-xl overflow-hidden transition-colors">
        {/* Header Strip */}
        <div className="p-5 sm:p-6 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between gap-4 flex-wrap">
          <div>
            <h1 className="text-xl sm:text-2xl font-bold text-slate-900 dark:text-white tracking-tight">
              كشف الحضور والغياب اليدوي
            </h1>
            <div className="flex items-center gap-2 text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1 flex-wrap">
              <span>المقرر: <strong className="text-slate-800 dark:text-slate-200">{course?.course_name} ({course?.course_code})</strong></span>
              <span>·</span>
              <span>الموضوع: <strong className="text-slate-800 dark:text-slate-200">{lecture?.topic}</strong></span>
              <span>·</span>
              <span>التاريخ: <strong className="text-slate-800 dark:text-slate-200">{lecture?.lecture_date}</strong></span>
            </div>
          </div>

          {/* Quick Search */}
          <div className="relative w-full sm:w-64">
            <Search className="w-4 h-4 text-slate-400 absolute right-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="بحث بالاسم أو الرقم الجامعي..."
              className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl pr-9 pl-3 py-2 text-xs text-slate-900 dark:text-white placeholder-slate-400 dark:placeholder-slate-500 outline-none focus:border-blue-500 transition-colors"
            />
          </div>
        </div>

        {/* Stats Strip */}
        <div className="grid grid-cols-2 sm:grid-cols-5 border-b border-slate-200 dark:border-slate-800 divide-x divide-slate-200 dark:divide-slate-800 divide-x-reverse bg-slate-50/70 dark:bg-slate-950/40 text-center">
          <div className="p-3.5">
            <div className="text-xs text-slate-500 dark:text-slate-400">إجمالي الطلاب</div>
            <div className="text-lg font-bold font-mono text-slate-900 dark:text-white mt-0.5">{total}</div>
          </div>
          <div className="p-3.5">
            <div className="text-xs text-emerald-600 dark:text-emerald-400 flex items-center justify-center gap-1 font-semibold">
              <CheckCircle2 className="w-3.5 h-3.5" />
              <span>حاضر</span>
            </div>
            <div className="text-lg font-bold font-mono text-emerald-600 dark:text-emerald-400 mt-0.5">{presentCount}</div>
          </div>
          <div className="p-3.5">
            <div className="text-xs text-rose-600 dark:text-rose-400 flex items-center justify-center gap-1 font-semibold">
              <XCircle className="w-3.5 h-3.5" />
              <span>غائب</span>
            </div>
            <div className="text-lg font-bold font-mono text-rose-600 dark:text-rose-400 mt-0.5">{absentCount}</div>
          </div>
          <div className="p-3.5">
            <div className="text-xs text-amber-600 dark:text-amber-400 flex items-center justify-center gap-1 font-semibold">
              <Clock className="w-3.5 h-3.5" />
              <span>تأخر</span>
            </div>
            <div className="text-lg font-bold font-mono text-amber-600 dark:text-amber-400 mt-0.5">{lateCount}</div>
          </div>
          <div className="p-3.5 col-span-2 sm:col-span-1 border-t sm:border-t-0 border-slate-200 dark:border-slate-800">
            <div className="text-xs text-blue-600 dark:text-blue-400 flex items-center justify-center gap-1 font-semibold">
              <FileText className="w-3.5 h-3.5" />
              <span>عذر</span>
            </div>
            <div className="text-lg font-bold font-mono text-blue-600 dark:text-blue-400 mt-0.5">{excusedCount}</div>
          </div>
        </div>

        {/* Table View */}
        <div className="overflow-x-auto">
          <table className="w-full text-right border-collapse text-xs sm:text-sm">
            <thead>
              <tr className="bg-slate-100/70 dark:bg-slate-950/60 border-b border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-400 font-semibold">
                <th className="py-3 px-4 w-12 text-center">#</th>
                <th className="py-3 px-4">اسم الطالب</th>
                <th className="py-3 px-4">الرقم الجامعي</th>
                <th className="py-3 px-4 text-center">الكود السري</th>
                <th className="py-3 px-4 text-center min-w-[280px]">حالة الحضور</th>
                <th className="py-3 px-4 text-center">نقاط التفاعل (+1)</th>
                <th className="py-3 px-4 min-w-[200px]">ملاحظات</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800/80">
              {filteredStudents.length === 0 ? (
                <tr>
                  <td colSpan={7} className="py-10 text-center text-slate-500">
                    لا يوجد طلاب مطابقين للبحث.
                  </td>
                </tr>
              ) : (
                filteredStudents.map((item, index) => (
                  <tr
                    key={item.student.student_id}
                    className="hover:bg-slate-50 dark:hover:bg-slate-800/40 transition-colors"
                  >
                    <td className="py-3 px-4 text-center font-mono text-slate-400 dark:text-slate-500">
                      {index + 1}
                    </td>
                    <td className="py-3 px-4 font-semibold text-slate-900 dark:text-white">
                      <div className="flex items-center gap-2.5">
                        <img
                          src={item.student.photo_url || DEFAULT_STUDENT_PHOTO_URL}
                          alt={item.student.full_name}
                          onError={(e) => {
                            e.currentTarget.src = DEFAULT_STUDENT_PHOTO_URL;
                          }}
                          className="w-9 h-9 rounded-full object-cover border border-slate-200 dark:border-slate-700 shrink-0 bg-slate-100 dark:bg-slate-800"
                        />
                        <div>
                          <div className="flex items-center gap-2 flex-wrap">
                            <span>{item.student.full_name}</span>
                            {(() => {
                              const alert = advisorAlerts.find((a) => a.student_id === item.student.student_id);
                              if (!alert) return null;
                              return (
                                <span
                                  className={`text-[10px] px-1.5 py-0.2 rounded font-bold ${
                                    alert.status === 'قيد المتابعة'
                                      ? 'bg-amber-500/15 text-amber-600 dark:text-amber-400 border border-amber-500/30'
                                      : 'bg-emerald-500/15 text-emerald-600 dark:text-emerald-400 border border-emerald-500/30'
                                  }`}
                                  title={`المرشد المختص: ${alert.advisor_name} (${alert.status})`}
                                >
                                  ⚠️ إنذار مرشد ({alert.status})
                                </span>
                              );
                            })()}
                          </div>
                          <div className="text-[11px] text-slate-500 font-normal">
                            {item.student.department_name}
                          </div>
                        </div>
                      </div>
                    </td>
                    <td className="py-3 px-4 font-mono text-slate-700 dark:text-slate-300">
                      {item.student.university_id}
                    </td>
                    <td className="py-3 px-4 text-center whitespace-nowrap">
                      <div className="inline-flex items-center gap-1.5 bg-slate-100 dark:bg-slate-950/70 border border-slate-200 dark:border-slate-800 px-2.5 py-1 rounded-lg">
                        <KeyRound className="w-3 h-3 text-amber-500 shrink-0" />
                        <code className="font-mono text-xs font-bold text-slate-800 dark:text-amber-300 tracking-wider">
                          ••••••••
                        </code>
                        {isInstructor && (
                          <button
                            type="button"
                            onClick={() => handleRotateSecret(item.student.student_id, item.student.full_name)}
                            className="p-0.5 text-slate-400 hover:text-blue-500 transition-colors cursor-pointer"
                            title="إعادة توليد كود سري جديد للطالب"
                          >
                            <RefreshCw className="w-3 h-3" />
                          </button>
                        )}
                      </div>
                    </td>
                    <td className="py-3 px-4 text-center">
                      {/* Segmented Control Buttons for Status */}
                      <div className="inline-flex items-center gap-1 bg-slate-100 dark:bg-slate-950/80 p-1 rounded-xl border border-slate-200 dark:border-slate-800/90 shadow-inner">
                        <button
                          type="button"
                          onClick={() => handleStatus(item.student.student_id, 'Present', item.notes)}
                          className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
                            item.status === 'Present'
                              ? 'bg-emerald-600 text-white shadow-sm shadow-emerald-600/30'
                              : 'text-slate-400 hover:text-slate-200'
                          }`}
                        >
                          حاضر
                        </button>

                        <button
                          type="button"
                          onClick={() => handleStatus(item.student.student_id, 'Absent', item.notes)}
                          className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
                            item.status === 'Absent'
                              ? 'bg-rose-600 text-white shadow-sm shadow-rose-600/30'
                              : 'text-slate-400 hover:text-slate-200'
                          }`}
                        >
                          غائب
                        </button>

                        <button
                          type="button"
                          onClick={() => handleStatus(item.student.student_id, 'Late', item.notes)}
                          className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
                            item.status === 'Late'
                              ? 'bg-amber-600 text-white shadow-sm shadow-amber-600/30'
                              : 'text-slate-400 hover:text-slate-200'
                          }`}
                        >
                          تأخر
                        </button>

                        <button
                          type="button"
                          onClick={() => handleStatus(item.student.student_id, 'Excused', item.notes)}
                          className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
                            item.status === 'Excused'
                              ? 'bg-blue-600 text-white shadow-sm shadow-blue-600/30'
                              : 'text-slate-400 hover:text-slate-200'
                          }`}
                        >
                          عذر
                        </button>
                      </div>
                    </td>
                    <td className="py-3 px-4 text-center whitespace-nowrap">
                      <div className="inline-flex items-center gap-1.5">
                        <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-bold bg-amber-500/15 text-amber-600 dark:text-amber-400 border border-amber-500/25">
                          <span>🌟</span>
                          <span>{item.points}</span>
                        </span>
                        <button
                          type="button"
                          onClick={async () => {
                            const res = await addPoint(item.student.student_id, 'مشاركة وتفاعل إيجابي أثناء المحاضرة');
                            if (res.ok) {
                              setActionError(null);
                              setToastMessage(`🌟 ${res.message}`);
                              setTimeout(() => setToastMessage(null), 3500);
                            } else {
                              setActionError(res.message);
                            }
                          }}
                          className="px-2 py-0.5 rounded-md text-[11px] font-bold bg-blue-50 dark:bg-blue-900/30 text-blue-600 dark:text-blue-400 hover:bg-blue-100 dark:hover:bg-blue-900/50 transition-colors border border-blue-200 dark:border-blue-800"
                          title="منح نقطة تميز ومشاركة (+1)"
                        >
                          +1 🌟
                        </button>
                      </div>
                    </td>
                    <td className="py-3 px-4">
                      <input
                        type="text"
                        value={noteDrafts[item.student.student_id] ?? item.notes}
                        onChange={(e) =>
                          setNoteDrafts((prev) => ({ ...prev, [item.student.student_id]: e.target.value }))
                        }
                        onBlur={() => handleNoteBlur(item.student.student_id, item.status, item.notes)}
                        onKeyDown={(e) => {
                          if (e.key === 'Enter') (e.target as HTMLInputElement).blur();
                        }}
                        placeholder="أضف ملاحظة (مثال: عذر طبي)..."
                        className="w-full bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700/60 rounded-lg px-2.5 py-1.5 text-xs text-slate-900 dark:text-white placeholder-slate-400 dark:placeholder-slate-500 outline-none focus:border-blue-500 transition-colors"
                      />
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>

        {/* Footer Actions */}
        <div className="p-4 sm:p-5 bg-slate-50/70 dark:bg-slate-950/60 border-t border-slate-200 dark:border-slate-800 flex items-center justify-between gap-3 flex-wrap">
          <div className="flex items-center gap-2">
            <button
              onClick={handleMarkAll}
              className="flex items-center gap-1.5 px-4 py-2 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-200 border border-slate-200 dark:border-slate-700 rounded-xl text-xs sm:text-sm font-semibold transition-colors cursor-pointer"
            >
              <CheckCheck className="w-4 h-4 text-emerald-500 dark:text-emerald-400" />
              <span>تحديد الكل حاضر</span>
            </button>

            <button
              onClick={handleExportCSV}
              className="flex items-center gap-1.5 px-4 py-2 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-200 border border-slate-200 dark:border-slate-700 rounded-xl text-xs sm:text-sm font-semibold transition-colors cursor-pointer"
            >
              <Download className="w-4 h-4 text-blue-500 dark:text-blue-400" />
              <span>تصدير CSV</span>
            </button>

            <button
              onClick={handleExportPDF}
              disabled={isExportingPdf}
              className="flex items-center gap-1.5 px-4 py-2 bg-rose-600 hover:bg-rose-500 disabled:opacity-60 text-white rounded-xl text-xs sm:text-sm font-semibold transition-colors shadow-sm cursor-pointer"
            >
              {isExportingPdf ? <Loader2 className="w-4 h-4 animate-spin" /> : <FileText className="w-4 h-4" />}
              <span>{isExportingPdf ? 'جاري التجهيز...' : 'تصدير PDF'}</span>
            </button>
          </div>

          <button
            onClick={handleSave}
            className="flex items-center gap-1.5 px-6 py-2.5 bg-blue-600 hover:bg-blue-500 text-white rounded-xl text-xs sm:text-sm font-bold shadow-lg shadow-blue-600/25 transition-all cursor-pointer"
          >
            <Save className="w-4 h-4" />
            <span>حفظ السجل</span>
          </button>
        </div>
      </div>
    </div>
  );
};
