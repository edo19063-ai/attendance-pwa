import React, { useState } from 'react';
import {
  ShieldAlert,
  UserCheck,
  AlertTriangle,
  Clock,
  CheckCircle2,
  Search,
  Plus,
  RefreshCw,
  Trash2,
  User,
  GraduationCap,
  Sparkles,
  PhoneCall,
  Calendar,
  BookOpen,
  Download,
  Loader2,
} from 'lucide-react';
import { useAttendance } from '../context/AttendanceContext';
import { AdvisorAlertStatus } from '../types/attendance';
import { exportReportToPdf } from '../utils/pdfExport';
import { useAdvisorAlerts, useAtRisk } from '../hooks/useServerAttendance';

export const AcademicAdvisingView: React.FC = () => {
  const { students, courses, departments } = useAttendance();

  // مصدر البيانات: الخادم الآمن (التنبيهات محفوظة هناك وتُحسب الغيابات من سجلاته)
  const {
    alerts: advisorAlerts,
    error: alertsError,
    create: createAdvisorAlert,
    updateStatus: updateAdvisorAlertStatus,
    remove: deleteAdvisorAlert,
    autoGenerate: autoGenerateAdvisorAlerts,
  } = useAdvisorAlerts();
  const { students: highAbsenceStudents, error: atRiskError } = useAtRisk(2, 20);

  const [filterStatus, setFilterStatus] = useState<'all' | AdvisorAlertStatus>('all');
  const [searchTerm, setSearchTerm] = useState<string>('');
  const [showAddModal, setShowAddModal] = useState<boolean>(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // New alert form state
  const [newStudentId, setNewStudentId] = useState<number>(students[0]?.student_id || 1);
  const [newAdvisorName, setNewAdvisorName] = useState<string>('د. عبد السلام الورفلي');
  const [newAbsenceCount, setNewAbsenceCount] = useState<number>(3);
  const [newNotes, setNewNotes] = useState<string>('');
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);

  // Intervention modal notes
  const [selectedAlertForAction, setSelectedAlertForAction] = useState<number | null>(null);
  const [interventionNote, setInterventionNote] = useState<string>('');
  const [isExportingPdf, setIsExportingPdf] = useState<boolean>(false);

  // Statistics
  const totalAlerts = advisorAlerts.length;
  const pendingCount = advisorAlerts.filter((a) => a.status === 'قيد المتابعة').length;
  const resolvedCount = advisorAlerts.filter((a) => a.status === 'تم التدخل').length;

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3500);
  };

  const filteredAlerts = advisorAlerts.filter((alert) => {
    const matchesStatus = filterStatus === 'all' || alert.status === filterStatus;
    const matchesSearch =
      (alert.student_name || '').toLowerCase().includes(searchTerm.toLowerCase()) ||
      (alert.university_id || '').includes(searchTerm) ||
      (alert.advisor_name || '').toLowerCase().includes(searchTerm.toLowerCase()) ||
      (alert.notes || '').toLowerCase().includes(searchTerm.toLowerCase());
    return matchesStatus && matchesSearch;
  });

  const handleDelete = async (alertId: number) => {
    const res = await deleteAdvisorAlert(alertId);
    if (!res.success) showToast(`❌ ${res.message}`);
  };

  const handleAutoScan = async () => {
    const res = await autoGenerateAdvisorAlerts();
    if (!res.success) {
      showToast(`❌ ${res.message}`);
      return;
    }
    const addedCount = res.created;
    if (addedCount > 0) {
      showToast(`⚡ تم فحص الغيابات وإنشاء ${addedCount} تنبيهات إنذار مبكر جديدة بنجاح!`);
    } else {
      showToast('جميع الطلاب المتجاوزين لنسبة الغياب مسجل لهم تنبيهات مسبقاً.');
    }
  };

  const handleCreateAlert = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newAdvisorName.trim()) {
      alert('الرجاء إدخال اسم المرشد المختص.');
      return;
    }

    setIsSubmitting(true);
    const res = await createAdvisorAlert(
      newStudentId,
      newAdvisorName,
      newAbsenceCount,
      newNotes.trim()
    );
    setIsSubmitting(false);
    setShowAddModal(false);
    setNewNotes('');
    showToast(res.success ? `✅ ${res.message}` : `❌ ${res.message}`);
  };

  const handleStatusChange = async (alertId: number, newStatus: AdvisorAlertStatus) => {
    const res = await updateAdvisorAlertStatus(alertId, newStatus);
    showToast(res.success ? res.message : `❌ ${res.message}`);
  };

  const handleSaveInterventionNote = async (alertId: number) => {
    if (!interventionNote.trim()) return;
    const res = await updateAdvisorAlertStatus(alertId, 'تم التدخل', `إجراء المرشد: ${interventionNote.trim()}`);
    if (res.success) {
      setSelectedAlertForAction(null);
      setInterventionNote('');
    }
    showToast(res.success ? res.message : `❌ ${res.message}`);
  };

  const handleExportAlertsPdf = async () => {
    setIsExportingPdf(true);
    try {
      await exportReportToPdf({
        filename: 'academic_advisor_alerts_report.pdf',
        title: 'تقرير الإرشاد الأكاديمي والإنذار المبكر',
        subtitle: 'كشف متابعة حالات تكرار الغياب وتدخلات المرشدين الأكاديميين',
        stats: [
          { label: 'إجمالي التنبيهات', value: totalAlerts, accent: 'blue' },
          { label: 'قيد المتابعة', value: pendingCount, accent: 'amber' },
          { label: 'تم التدخل', value: resolvedCount, accent: 'emerald' },
        ],
        columns: [
          { header: '#', align: 'center', width: '40px' },
          { header: 'الطالب', align: 'right' },
          { header: 'الرقم الجامعي', align: 'center' },
          { header: 'المرشد المختص', align: 'right' },
          { header: 'الغيابات', align: 'center' },
          { header: 'الحالة', align: 'center' },
          { header: 'الملاحظات والتاريخ', align: 'right' },
        ],
        rows: filteredAlerts.map((a, idx) => [
          { text: String(idx + 1), mono: true },
          { text: a.student_name || `طالب #${a.student_id}`, bold: true },
          { text: a.university_id || String(a.student_id), mono: true },
          { text: a.advisor_name },
          { text: `${a.absence_count} غيابات`, badgeColor: a.absence_count >= 4 ? 'rose' : 'amber', mono: true },
          { text: a.status, badgeColor: a.status === 'تم التدخل' ? 'emerald' : 'amber' },
          { text: a.notes ? `${a.notes} (${a.timestamp})` : a.timestamp },
        ]),
      });
      showToast('📄 تم تصدير وتنزيل تقرير الإرشاد الأكاديمي بصيغة PDF بنجاح!');
    } finally {
      setIsExportingPdf(false);
    }
  };

  return (
    <div className="max-w-6xl mx-auto p-4 sm:p-6 space-y-6 animate-fade-in">
      {/* Toast Alert */}
      {toastMessage && (
        <div className="p-4 rounded-xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-300 text-sm font-semibold flex items-center gap-2 animate-fade-in shadow-lg">
          <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />
          <span>{toastMessage}</span>
        </div>
      )}

      {(alertsError || atRiskError) && (
        <div className="p-4 rounded-xl bg-rose-500/10 border border-rose-500/20 text-rose-700 dark:text-rose-300 text-sm font-semibold">
          ⚠️ تعذر تحميل البيانات من الخادم: {alertsError || atRiskError}
        </div>
      )}

      {/* Main Header */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 sm:p-6 shadow-sm dark:shadow-xl space-y-4">
        <div className="flex items-center justify-between gap-4 flex-wrap">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-amber-500/10 border border-amber-500/25 flex items-center justify-center text-amber-500 shrink-0">
              <ShieldAlert className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-xl sm:text-2xl font-bold text-slate-900 dark:text-white tracking-tight">
                  منظومة الإرشاد الأكاديمي والإنذار المبكر
                </h1>
                <span className="text-[11px] font-mono bg-amber-500/15 text-amber-600 dark:text-amber-400 border border-amber-500/30 px-2 py-0.5 rounded-full font-bold">
                  AcademicAdvisorAlert
                </span>
              </div>
              <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1">
                رصد حالات تكرار الغياب، وتعيين المرشدين الأكاديميين، وتوثيق التدخلات الأكاديمية المبكرة
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2.5 flex-wrap">
            <button
              onClick={handleExportAlertsPdf}
              disabled={isExportingPdf}
              className="px-3.5 py-2 rounded-xl text-xs sm:text-sm font-semibold bg-rose-600 hover:bg-rose-500 disabled:opacity-60 text-white transition-colors flex items-center gap-1.5 cursor-pointer shadow-sm"
            >
              {isExportingPdf ? <Loader2 className="w-4 h-4 animate-spin" /> : <Download className="w-4 h-4" />}
              <span>{isExportingPdf ? 'جاري التجهيز...' : 'تصدير PDF'}</span>
            </button>

            <button
              onClick={handleAutoScan}
              className="px-3.5 py-2 rounded-xl text-xs sm:text-sm font-semibold bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-200 border border-slate-200 dark:border-slate-700 transition-colors flex items-center gap-1.5 cursor-pointer shadow-sm"
              title="فحص سجلات الغياب وإصدار تنبيهات تلقائية لمن تجاوزوا الحد المسموح"
            >
              <RefreshCw className="w-4 h-4 text-amber-500" />
              <span>فحص وتوليد تنبيهات آلياً</span>
            </button>

            <button
              onClick={() => setShowAddModal(true)}
              className="px-4 py-2 rounded-xl text-xs sm:text-sm font-semibold bg-blue-600 hover:bg-blue-500 text-white transition-colors flex items-center gap-1.5 cursor-pointer shadow-md shadow-blue-600/20"
            >
              <Plus className="w-4 h-4" />
              <span>إضافة تنبيه إرشاد يدوي</span>
            </button>
          </div>
        </div>

        {/* Stats Strip */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-3 border-t border-slate-100 dark:border-slate-800/80">
          <div className="p-3.5 rounded-xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200/80 dark:border-slate-800 flex items-center justify-between">
            <div>
              <span className="text-xs text-slate-500 dark:text-slate-400 block font-medium">إجمالي التنبيهات الصادرة</span>
              <span className="text-2xl font-bold font-mono text-slate-900 dark:text-white">{totalAlerts}</span>
            </div>
            <div className="w-9 h-9 rounded-lg bg-blue-500/10 text-blue-500 flex items-center justify-center font-bold">
              📋
            </div>
          </div>

          <div className="p-3.5 rounded-xl bg-amber-500/5 border border-amber-500/20 flex items-center justify-between">
            <div>
              <span className="text-xs text-amber-600 dark:text-amber-400 block font-medium">حالات قيد المتابعة والتدخل</span>
              <span className="text-2xl font-bold font-mono text-amber-600 dark:text-amber-400">{pendingCount}</span>
            </div>
            <div className="w-9 h-9 rounded-lg bg-amber-500/15 text-amber-500 flex items-center justify-center font-bold">
              ⏳
            </div>
          </div>

          <div className="p-3.5 rounded-xl bg-emerald-500/5 border border-emerald-500/20 flex items-center justify-between">
            <div>
              <span className="text-xs text-emerald-600 dark:text-emerald-400 block font-medium">تم التدخل والمعالجة الأكاديمية</span>
              <span className="text-2xl font-bold font-mono text-emerald-600 dark:text-emerald-400">{resolvedCount}</span>
            </div>
            <div className="w-9 h-9 rounded-lg bg-emerald-500/15 text-emerald-500 flex items-center justify-center font-bold">
              ✅
            </div>
          </div>
        </div>
      </div>

      {/* Filter & Search Bar */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-4 shadow-sm flex items-center justify-between gap-3 flex-wrap">
        <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar">
          <button
            onClick={() => setFilterStatus('all')}
            className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition-colors cursor-pointer ${
              filterStatus === 'all'
                ? 'bg-blue-600 text-white'
                : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
            }`}
          >
            جميع التنبيهات ({totalAlerts})
          </button>
          <button
            onClick={() => setFilterStatus('قيد المتابعة')}
            className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition-colors cursor-pointer ${
              filterStatus === 'قيد المتابعة'
                ? 'bg-amber-600 text-white'
                : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
            }`}
          >
            قيد المتابعة ({pendingCount})
          </button>
          <button
            onClick={() => setFilterStatus('تم التدخل')}
            className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition-colors cursor-pointer ${
              filterStatus === 'تم التدخل'
                ? 'bg-emerald-600 text-white'
                : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
            }`}
          >
            تم التدخل ({resolvedCount})
          </button>
        </div>

        <div className="relative w-full sm:w-64">
          <Search className="w-4 h-4 text-slate-400 absolute right-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="بحث بالطالب أو المرشد أو الملاحظة..."
            className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl pr-9 pl-3 py-2 text-xs text-slate-900 dark:text-white placeholder-slate-400 outline-none focus:border-blue-500"
          />
        </div>
      </div>

      {/* Alerts Grid / List */}
      <div className="space-y-3">
        {filteredAlerts.length === 0 ? (
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-10 text-center text-slate-400">
            <ShieldAlert className="w-10 h-10 mx-auto text-slate-400 mb-2 opacity-50" />
            <p className="text-sm font-semibold text-slate-600 dark:text-slate-300">
              لا توجد تنبيهات إرشاد أكاديمي مطابقة لمعايير البحث.
            </p>
            <p className="text-xs text-slate-400 mt-1">
              يمكنك استخدام زر "فحص وتوليد تنبيهات آلياً" لرصد أي طالب تجاوز حد الغياب المسموح به.
            </p>
          </div>
        ) : (
          filteredAlerts.map((alert) => {
            const isPending = alert.status === 'قيد المتابعة';
            return (
              <div
                key={alert.alert_id}
                className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 shadow-sm hover:border-slate-300 dark:hover:border-slate-700 transition-all space-y-3.5"
              >
                <div className="flex items-start justify-between gap-3 flex-wrap">
                  <div className="flex items-center gap-3">
                    <span
                      className={`w-10 h-10 rounded-xl flex items-center justify-center font-bold text-sm text-white shrink-0 shadow-sm ${
                        alert.absence_count >= 4
                          ? 'bg-rose-600'
                          : alert.absence_count >= 3
                          ? 'bg-amber-600'
                          : 'bg-blue-600'
                      }`}
                    >
                      {alert.student_name ? alert.student_name.trim().charAt(0) : 'ط'}
                    </span>
                    <div>
                      <div className="flex items-center gap-2">
                        <h3 className="font-bold text-sm sm:text-base text-slate-900 dark:text-white">
                          {alert.student_name || `طالب #${alert.student_id}`}
                        </h3>
                        <span className="text-xs font-mono text-slate-400 font-bold bg-slate-100 dark:bg-slate-800 px-2 py-0.5 rounded">
                          {alert.university_id || alert.student_id}
                        </span>
                      </div>
                      <div className="text-xs text-slate-500 dark:text-slate-400 flex items-center gap-2 mt-0.5 flex-wrap">
                        <span>القسم: <strong>{alert.department || 'تقنية المعلومات'}</strong></span>
                        <span>·</span>
                        <span className="text-slate-400 font-mono flex items-center gap-1">
                          <Clock className="w-3 h-3" />
                          {alert.timestamp}
                        </span>
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    <span
                      className={`px-3 py-1 rounded-full text-xs font-bold flex items-center gap-1.5 ${
                        isPending
                          ? 'bg-amber-500/15 text-amber-600 dark:text-amber-400 border border-amber-500/30'
                          : 'bg-emerald-500/15 text-emerald-600 dark:text-emerald-400 border border-emerald-500/30'
                      }`}
                    >
                      <span>{isPending ? '⏳' : '✅'}</span>
                      <span>{alert.status}</span>
                    </span>

                    <button
                      onClick={() => handleDelete(alert.alert_id)}
                      className="p-1.5 text-slate-400 hover:text-rose-500 hover:bg-rose-500/10 rounded-lg transition-colors cursor-pointer"
                      title="حذف التنبيه"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>

                {/* Key Advisor & Absence Details Strip */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 p-3 bg-slate-50 dark:bg-slate-950/60 rounded-xl border border-slate-100 dark:border-slate-800 text-xs">
                  <div className="flex items-center gap-2">
                    <UserCheck className="w-4 h-4 text-blue-500 shrink-0" />
                    <div>
                      <span className="text-slate-400 block text-[10px]">المرشد الأكاديمي المختص (advisor_name):</span>
                      <strong className="text-slate-900 dark:text-white font-medium">{alert.advisor_name}</strong>
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    <AlertTriangle className="w-4 h-4 text-rose-500 shrink-0" />
                    <div>
                      <span className="text-slate-400 block text-[10px]">عدد الغيابات الحالية (absence_count):</span>
                      <span className="inline-flex items-center gap-1 font-bold font-mono text-rose-600 dark:text-rose-400">
                        <span>{alert.absence_count} محاضرات غياب</span>
                        <span className="text-[10px] font-normal text-slate-400">
                          ({alert.absence_count >= 4 ? 'إنذار حرمان وشيك' : 'تجاوز حد التحذير'})
                        </span>
                      </span>
                    </div>
                  </div>
                </div>

                {/* Notes and Intervention Summary */}
                {alert.notes && (
                  <div className="p-3 bg-blue-50/50 dark:bg-blue-950/20 border border-blue-100 dark:border-blue-900/30 rounded-xl text-xs text-slate-700 dark:text-slate-300">
                    <span className="font-semibold text-blue-600 dark:text-blue-400 block mb-0.5">
                      ملاحظات وتفاصيل التنبيه:
                    </span>
                    {alert.notes}
                  </div>
                )}

                {/* Action Buttons */}
                <div className="flex items-center justify-between gap-3 pt-2 border-t border-slate-100 dark:border-slate-800/80 flex-wrap">
                  <div className="text-[11px] text-slate-400">
                    رقم القيد الأكاديمي: <code className="font-mono text-slate-500">alert_id: {alert.alert_id}</code>
                  </div>

                  <div className="flex items-center gap-2">
                    {isPending ? (
                      <>
                        <button
                          type="button"
                          onClick={() => {
                            setSelectedAlertForAction(alert.alert_id);
                            setInterventionNote('');
                          }}
                          className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer shadow-sm"
                        >
                          <CheckCircle2 className="w-3.5 h-3.5" />
                          <span>توثيق التدخل الأكاديمي (تم التدخل)</span>
                        </button>

                        <button
                          type="button"
                          onClick={() => handleStatusChange(alert.alert_id, 'تم التدخل')}
                          className="px-2.5 py-1.5 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 rounded-lg text-xs font-medium transition-colors cursor-pointer"
                        >
                          تحديد كـ "تم التدخل" مباشرة
                        </button>
                      </>
                    ) : (
                      <button
                        type="button"
                        onClick={() => handleStatusChange(alert.alert_id, 'قيد المتابعة')}
                        className="px-3 py-1.5 bg-amber-600 hover:bg-amber-500 text-white rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer"
                      >
                        <Clock className="w-3.5 h-3.5" />
                        <span>إعادة التنبيه إلى (قيد المتابعة)</span>
                      </button>
                    )}
                  </div>
                </div>

                {/* Inline Intervention Note Form */}
                {selectedAlertForAction === alert.alert_id && (
                  <div className="p-3.5 bg-emerald-500/10 border border-emerald-500/30 rounded-xl space-y-2.5 animate-fade-in mt-2">
                    <label className="text-xs font-bold text-emerald-800 dark:text-emerald-300 block">
                      توثيق إجراء وتدخل المرشد الأكاديمي مع الطالب:
                    </label>
                    <textarea
                      value={interventionNote}
                      onChange={(e) => setInterventionNote(e.target.value)}
                      placeholder="مثال: تمت مقابلة الطالب شخصياً وإحالته للشؤون الطلابية وتقديم خطة تعويضية للمقرر..."
                      rows={2}
                      className="w-full bg-white dark:bg-slate-900 border border-emerald-500/30 rounded-lg p-2 text-xs text-slate-900 dark:text-white outline-none focus:border-emerald-500"
                    />
                    <div className="flex items-center justify-end gap-2">
                      <button
                        type="button"
                        onClick={() => setSelectedAlertForAction(null)}
                        className="px-3 py-1 text-xs text-slate-500 hover:text-slate-700 dark:hover:text-slate-300"
                      >
                        إلغاء
                      </button>
                      <button
                        type="button"
                        onClick={() => handleSaveInterventionNote(alert.alert_id)}
                        className="px-3.5 py-1 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg text-xs font-bold"
                      >
                        حفظ وتغيير الحالة إلى "تم التدخل"
                      </button>
                    </div>
                  </div>
                )}
              </div>
            );
          })
        )}
      </div>

      {/* Suggested Students with High Absences Section */}
      {highAbsenceStudents.length > 0 && (
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 shadow-sm space-y-3">
          <div className="flex items-center justify-between gap-2 flex-wrap">
            <div className="flex items-center gap-2">
              <span className="text-base">📢</span>
              <h3 className="font-bold text-sm text-slate-900 dark:text-white">
                طلاب مرشحون للإنذار المبكر بناءً على تقارير الغياب الفعلية:
              </h3>
            </div>
            <span className="text-xs text-slate-400 font-mono">
              تجاوزوا حد الغياب (2 أو أكثر)
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
            {highAbsenceStudents.slice(0, 6).map((student) => {
              const alreadyHasAlert = advisorAlerts.some((a) => a.student_id === student.student_id);
              return (
                <div
                  key={student.student_id}
                  className="p-3 bg-slate-50 dark:bg-slate-950/70 border border-slate-200 dark:border-slate-800 rounded-xl flex items-center justify-between text-xs"
                >
                  <div>
                    <div className="font-bold text-slate-900 dark:text-white">{student.full_name}</div>
                    <div className="text-[11px] text-slate-400 font-mono">
                      {student.university_id} · <span className="text-rose-500 font-bold">{student.absent_count} غيابات ({student.absent_percentage}%)</span>
                    </div>
                  </div>

                  {alreadyHasAlert ? (
                    <span className="text-[10px] font-bold text-emerald-600 dark:text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded-full border border-emerald-500/20">
                      تنبيه مسجل ✓
                    </span>
                  ) : (
                    <button
                      onClick={async () => {
                        const res = await createAdvisorAlert(
                          student.student_id,
                          'د. عبد السلام الورفلي',
                          student.absent_count,
                          `إنذار غياب فوري: غياب ${student.absent_count} محاضرات في مقرر ${student.course_name}.`
                        );
                        showToast(
                          res.success
                            ? `تم رفع تنبيه للمرشد عن الطالب: ${student.full_name}`
                            : `❌ ${res.message}`
                        );
                      }}
                      className="px-2.5 py-1 bg-amber-500/15 hover:bg-amber-500/25 text-amber-700 dark:text-amber-300 border border-amber-500/30 rounded-lg text-[11px] font-bold cursor-pointer transition-colors"
                    >
                      + رفع تنبيه
                    </button>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Manual Add Alert Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl max-w-lg w-full p-6 shadow-2xl space-y-4 animate-scale-up">
            <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3">
              <div className="flex items-center gap-2">
                <ShieldAlert className="w-5 h-5 text-amber-500" />
                <h3 className="font-bold text-base text-slate-900 dark:text-white">
                  إصدار تنبيه إرشاد أكاديمي جديد (New Alert)
                </h3>
              </div>
              <button
                onClick={() => setShowAddModal(false)}
                className="text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 text-lg font-bold"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleCreateAlert} className="space-y-3.5 text-xs sm:text-sm">
              <div>
                <label className="block font-medium text-slate-700 dark:text-slate-300 mb-1">
                  اختر الطالب المطلوب إصدار التنبيه له:
                </label>
                <select
                  value={newStudentId}
                  onChange={(e) => {
                    const id = Number(e.target.value);
                    setNewStudentId(id);
                    // auto guess absence count from reports
                    const rep = highAbsenceStudents.find((s) => s.student_id === id);
                    if (rep) setNewAbsenceCount(rep.absent_count);
                  }}
                  className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white outline-none focus:border-blue-500"
                >
                  {students.map((s) => (
                    <option key={s.student_id} value={s.student_id}>
                      {s.full_name} ({s.university_id}) — {s.department_name}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block font-medium text-slate-700 dark:text-slate-300 mb-1">
                  اسم المرشد المختص (advisor_name):
                </label>
                <input
                  type="text"
                  value={newAdvisorName}
                  onChange={(e) => setNewAdvisorName(e.target.value)}
                  placeholder="مثال: د. عبد السلام الورفلي"
                  className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white outline-none focus:border-blue-500 font-semibold"
                  required
                />
                <div className="flex items-center gap-1.5 flex-wrap mt-1.5 text-[11px]">
                  <span className="text-slate-400">مرشدون مقترحون:</span>
                  {['د. عبد السلام الورفلي', 'أ. د. منى القاضي', 'د. طارق المنصور'].map((adv) => (
                    <button
                      key={adv}
                      type="button"
                      onClick={() => setNewAdvisorName(adv)}
                      className="px-2 py-0.5 bg-slate-100 dark:bg-slate-800 hover:bg-blue-500/10 hover:text-blue-500 rounded text-slate-600 dark:text-slate-400 border border-slate-200 dark:border-slate-700 cursor-pointer"
                    >
                      {adv}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="block font-medium text-slate-700 dark:text-slate-300 mb-1">
                  عدد الغيابات الحالية (absence_count):
                </label>
                <input
                  type="number"
                  min={1}
                  max={20}
                  value={newAbsenceCount}
                  onChange={(e) => setNewAbsenceCount(Number(e.target.value))}
                  className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white outline-none focus:border-blue-500 font-mono"
                  required
                />
              </div>

              <div>
                <label className="block font-medium text-slate-700 dark:text-slate-300 mb-1">
                  ملاحظات وتوجيهات الإنذار:
                </label>
                <textarea
                  value={newNotes}
                  onChange={(e) => setNewNotes(e.target.value)}
                  placeholder="اكتب أسباب التنبيه أو التوصيات الموجهة للمرشد الأكاديمي..."
                  rows={3}
                  className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white outline-none focus:border-blue-500"
                />
              </div>

              <div className="flex items-center justify-end gap-2.5 pt-3 border-t border-slate-100 dark:border-slate-800">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-4 py-2 rounded-xl text-xs sm:text-sm font-medium text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
                >
                  إلغاء
                </button>
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="px-5 py-2 rounded-xl text-xs sm:text-sm font-bold bg-blue-600 hover:bg-blue-500 text-white cursor-pointer shadow-md shadow-blue-500/20 disabled:opacity-50"
                >
                  {isSubmitting ? 'جاري الحفظ والرفع...' : 'إصدار التنبيه فوراً'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
