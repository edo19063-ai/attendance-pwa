/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { AttendanceProvider, useAttendance } from './context/AttendanceContext';
import { Navbar, ActiveView } from './components/Navbar';
import { LiveScreenView } from './components/LiveScreenView';
import { StudentScannerView } from './components/StudentScannerView';
import { ManualAttendanceView } from './components/ManualAttendanceView';
import { ReportsView } from './components/ReportsView';
import { InstructorGate } from './components/InstructorGate';
import { DatabaseCodeStudioView } from './components/DatabaseCodeStudioView';
import { UrlsShareView } from './components/UrlsShareView';
import { ExcusesView } from './components/ExcusesView';
import { AcademicAdvisingView } from './components/AcademicAdvisingView';

const MainAppContent: React.FC = () => {
  const { setSelectedLectureId, setSelectedCourseId } = useAttendance();
  const [activeView, setActiveView] = useState<ActiveView>('live-screen');

  // Parse URL query parameters to support direct deep linking
  useEffect(() => {
    try {
      const params = new URLSearchParams(window.location.search);
      const viewParam = params.get('view') as ActiveView;
      const lectureParam = params.get('lecture');
      const courseParam = params.get('course');

      if (
        viewParam &&
        ['live-screen', 'scanner', 'manual', 'excuses', 'advising', 'reports', 'database', 'share'].includes(viewParam)
      ) {
        setActiveView(viewParam);
      }
      if (lectureParam) {
        const lId = Number(lectureParam);
        if (!isNaN(lId)) setSelectedLectureId(lId);
      }
      if (courseParam) {
        const cId = Number(courseParam);
        if (!isNaN(cId)) setSelectedCourseId(cId);
      }
    } catch {
      // ignore
    }
  }, [setSelectedLectureId, setSelectedCourseId]);

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 flex flex-col font-sans selection:bg-blue-600 selection:text-white transition-colors duration-200">
      {/* Top Navbar */}
      <Navbar activeView={activeView} setActiveView={setActiveView} />

      {/* Main Content Area */}
      <main className="flex-1 pb-16">
        {activeView === 'live-screen' && (
          <InstructorGate allowAssistant>
            <LiveScreenView onOpenScanner={() => setActiveView('scanner')} />
          </InstructorGate>
        )}
        {activeView === 'scanner' && (
          <StudentScannerView
            onBackToLive={() => setActiveView('live-screen')}
            onOpenExcuses={() => setActiveView('excuses')}
          />
        )}
        {activeView === 'manual' && (
          <InstructorGate allowAssistant>
            <ManualAttendanceView />
          </InstructorGate>
        )}
        {activeView === 'excuses' && <ExcusesView />}
        {activeView === 'advising' && (
          <InstructorGate>
            <AcademicAdvisingView />
          </InstructorGate>
        )}
        {activeView === 'reports' && (
          <InstructorGate>
            <ReportsView />
          </InstructorGate>
        )}
        {activeView === 'database' && <DatabaseCodeStudioView />}
        {activeView === 'share' && <UrlsShareView />}
      </main>

      {/* Quiet Footer */}
      <footer className="border-t border-slate-200 dark:border-slate-900 bg-white/80 dark:bg-slate-950/80 py-4 px-6 text-center text-xs text-slate-500">
        <div className="max-w-6xl mx-auto flex items-center justify-between gap-4 flex-wrap">
          <span>نظام الحضور الذكي بالباركود المتغير © {new Date().getFullYear()}</span>
          <div className="flex items-center gap-4 text-[11px]">
            <button
              onClick={() => setActiveView('share')}
              className="hover:text-blue-500 dark:hover:text-blue-400 transition-colors cursor-pointer"
            >
              روابط التطبيق المباشرة
            </button>
            <span>·</span>
            <button
              onClick={() => setActiveView('database')}
              className="hover:text-blue-500 dark:hover:text-blue-400 transition-colors cursor-pointer"
            >
              مخطط قاعدة البيانات و SQL
            </button>
            <span>·</span>
            <span>حماية من الغش بنظام التشفير الزمني (TOTP 5s)</span>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default function App() {
  return (
    <AttendanceProvider>
      <MainAppContent />
    </AttendanceProvider>
  );
}
