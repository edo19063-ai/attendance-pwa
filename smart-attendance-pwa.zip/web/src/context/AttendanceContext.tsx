import React, { createContext, useContext, useState, useEffect, useMemo, ReactNode } from 'react';
import {
  Department,
  Student,
  Course,
  CourseEnrollment,
  Lecture,
  AttendanceRecord,
  AttendanceStatus,
  StudentAttendanceSummary,
  RecentScanEvent,
  OfflineScanRecord,
  AttendanceExcuse,
  ExcuseStatus,
  TAProxySession,
  AssistantAuditLog,
  LectureFeedback,
  StudentParticipation,
  AcademicAdvisorAlert,
  AdvisorAlertStatus,
} from '../types/attendance';
import {
  INITIAL_DEPARTMENTS,
  INITIAL_COURSES,
  INITIAL_STUDENTS,
  INITIAL_ENROLLMENTS,
  INITIAL_LECTURES,
  INITIAL_ATTENDANCE,
  INITIAL_EXCUSES,
  INITIAL_AUDIT_LOGS,
  INITIAL_FEEDBACKS,
  INITIAL_PARTICIPATIONS,
  INITIAL_ADVISOR_ALERTS,
  DEFAULT_STUDENT_PHOTO_URL,
} from '../data/initialData';
import { verifyToken, generateToken, getTimeWindow, DEFAULT_INTERVAL_SECONDS } from '../utils/security';
import {
  verifyGeofence,
  DEFAULT_GEOFENCE_CONFIG,
  GeoCoordinates,
} from '../utils/geolocation';

interface AttendanceContextType {
  departments: Department[];
  courses: Course[];
  students: Student[];
  enrollments: CourseEnrollment[];
  lectures: Lecture[];
  attendance: AttendanceRecord[];
  selectedCourseId: number;
  selectedLectureId: number;
  totpInterval: number;
  soundEnabled: boolean;
  recentScans: RecentScanEvent[];

  setSelectedCourseId: (id: number) => void;
  setSelectedLectureId: (id: number) => void;
  setTotpInterval: (seconds: number) => void;
  setSoundEnabled: (enabled: boolean) => void;

  setStudentStatus: (lectureId: number, studentId: number, status: AttendanceStatus, notes?: string) => void;
  setStudentNotes: (lectureId: number, studentId: number, notes: string) => void;
  markAllPresent: (lectureId: number) => void;
  scanAttendance: (
    lectureId: number,
    universityId: string,
    token: string,
    geoCoords?: GeoCoordinates | null
  ) => {
    success: boolean;
    message: string;
    studentName?: string;
    distanceMeters?: number;
    isWithinGeofence?: boolean;
  };
  simulateQuickScan: (lectureId: number, studentId: number, valid: boolean) => { success: boolean; message: string };
  verifyStudentSecretCode: (
    universityId: string,
    secretCode: string,
    lectureId: number
  ) => Promise<{
    success: boolean;
    message: string;
    student_name?: string;
    photo_url?: string;
    university_id?: string;
  }>;
  checkInStudent: (
    studentId: number,
    lectureId: number
  ) => Promise<{
    success: boolean;
    message?: string;
    error?: string;
    student_name?: string;
    university_id?: string;
    photo_url?: string;
  }>;
  regenerateStudentSecretCode: (studentId: number) => string;
  // Offline Mode
  isOnline: boolean;
  isSimulatedOffline: boolean;
  setIsSimulatedOffline: (offline: boolean) => void;
  offlineQueue: OfflineScanRecord[];
  queueOfflineScan: (
    lectureId: number,
    universityId: string,
    token: string,
    geoCoords?: GeoCoordinates | null
  ) => { success: boolean; message: string; record?: OfflineScanRecord; studentName?: string };
  syncOfflineQueue: () => Promise<{ success: boolean; syncedCount: number; message: string }>;
  clearOfflineQueue: () => void;

  resetDatabase: () => void;

  // SQL Reports
  getCourseAttendanceReport: (courseId: number) => StudentAttendanceSummary[];
  getAbsenceThresholdReport: (
    courseId?: number,
    minAbsences?: number,
    minAbsencePct?: number
  ) => StudentAttendanceSummary[];
  getLectureDetails: (lectureId: number) => {
    lecture?: Lecture;
    course?: Course;
    studentsWithStatus: Array<{
      student: Student;
      status: AttendanceStatus;
      notes: string;
      recorded_at?: string;
    }>;
  };

  // Electronic Excuses System (الأعذار الإلكترونية)
  excuses: AttendanceExcuse[];
  submitExcuse: (
    studentId: number,
    lectureId: number,
    reasonText: string,
    documentUrl?: string
  ) => { success: boolean; message: string; excuse?: AttendanceExcuse };
  reviewExcuse: (
    excuseId: number,
    action: 'accept' | 'reject',
    reviewNotes?: string
  ) => { success: boolean; message: string };

  // Perfect Attendance (لوحة الشرف)
  getPerfectAttendanceStudents: (lectureId: number) => Array<{
    student_id: number;
    full_name: string;
    university_id: string;
  }>;

  // TA Proxy Mode & Audit Log (وضع تفويض المعيد وسجل التدقيق)
  taProxySession: TAProxySession | null;
  auditLogs: AssistantAuditLog[];
  activateTAProxy: (assistantName: string, action?: string) => Promise<{ success: boolean; message: string }>;
  deactivateTAProxy: () => void;
  recordAssistantAction: (action: string, assistantName?: string) => { success: boolean; message: string; log: AssistantAuditLog };

  // Lecture Feedback (تقييم المحاضرة الفوري)
  feedbacks: LectureFeedback[];
  submitFeedback: (lectureId: number, studentId: number, score: number) => Promise<{ success: boolean; message: string }>;
  getLectureFeedbackStats: (lectureId: number) => { average: number; count: number; breakdown: Record<number, number> };

  // Student Participation Points (نقاط التفاعل والتميز)
  participations: StudentParticipation[];
  addParticipationPoint: (studentId: number, courseId: number, reason?: string) => Promise<{ success: boolean; message: string }>;
  getStudentParticipationPoints: (studentId: number, courseId?: number) => number;

  // Academic Advisor Alerts (تنبيهات الإرشاد الأكاديمي والإنذار المبكر)
  advisorAlerts: AcademicAdvisorAlert[];
  createAdvisorAlert: (
    studentId: number,
    advisorName: string,
    absenceCount: number,
    notes?: string
  ) => Promise<{ success: boolean; message: string; alert: AcademicAdvisorAlert }>;
  updateAdvisorAlertStatus: (
    alertId: number,
    status: AdvisorAlertStatus,
    notes?: string
  ) => Promise<{ success: boolean; message: string }>;
  deleteAdvisorAlert: (alertId: number) => void;
  autoGenerateAdvisorAlerts: () => number;
}

const AttendanceContext = createContext<AttendanceContextType | undefined>(undefined);

const STORAGE_KEY = 'smart_attendance_system_data_v1';

const SECRET_CODE_CHARS = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';

// Cryptographically secure 6-character code (Math.random is predictable)
function generateSecretCode(): string {
  const buf = new Uint32Array(6);
  crypto.getRandomValues(buf);
  return Array.from(buf, (n) => SECRET_CODE_CHARS[n % SECRET_CODE_CHARS.length]).join('');
}

export const AttendanceProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [departments] = useState<Department[]>(INITIAL_DEPARTMENTS);
  const [courses] = useState<Course[]>(INITIAL_COURSES);
  const [students, setStudents] = useState<Student[]>(() => {
    try {
      const saved = localStorage.getItem(`${STORAGE_KEY}_students`);
      if (saved) {
        const parsed: Student[] = JSON.parse(saved);
        return parsed.map((st) => {
          const fallback = INITIAL_STUDENTS.find((i) => i.student_id === st.student_id);
          return {
            ...st,
            photo_url: st.photo_url || fallback?.photo_url || DEFAULT_STUDENT_PHOTO_URL,
            secret_code: st.secret_code || fallback?.secret_code || generateSecretCode(),
          };
        });
      }
    } catch {
      // ignore
    }
    return INITIAL_STUDENTS;
  });

  useEffect(() => {
    try {
      localStorage.setItem(`${STORAGE_KEY}_students`, JSON.stringify(students));
    } catch {
      // ignore
    }
  }, [students]);

  const [enrollments] = useState<CourseEnrollment[]>(INITIAL_ENROLLMENTS);
  const [lectures] = useState<Lecture[]>(INITIAL_LECTURES);

  // Initialize attendance records from localStorage or defaults
  const [attendance, setAttendance] = useState<AttendanceRecord[]>(() => {
    try {
      const saved = localStorage.getItem(`${STORAGE_KEY}_attendance`);
      if (saved) return JSON.parse(saved);
    } catch {
      // ignore
    }
    return INITIAL_ATTENDANCE;
  });

  const [selectedCourseId, setSelectedCourseId] = useState<number>(1);
  const [selectedLectureId, setSelectedLectureId] = useState<number>(5); // default to current active lecture
  const [totpInterval, setTotpInterval] = useState<number>(DEFAULT_INTERVAL_SECONDS);
  const [soundEnabled, setSoundEnabled] = useState<boolean>(true);
  const [recentScans, setRecentScans] = useState<RecentScanEvent[]>([]);

  // Offline Mode States
  const [isOnline, setIsOnline] = useState<boolean>(() =>
    typeof navigator !== 'undefined' ? navigator.onLine : true
  );
  const [isSimulatedOffline, setIsSimulatedOffline] = useState<boolean>(false);
  const [offlineQueue, setOfflineQueue] = useState<OfflineScanRecord[]>(() => {
    try {
      const savedQueue = localStorage.getItem(`${STORAGE_KEY}_offline_queue`);
      if (savedQueue) return JSON.parse(savedQueue);
    } catch {
      // ignore
    }
    return [];
  });

  // Sync offline queue to localStorage
  useEffect(() => {
    try {
      localStorage.setItem(`${STORAGE_KEY}_offline_queue`, JSON.stringify(offlineQueue));
    } catch {
      // ignore
    }
  }, [offlineQueue]);

  // Electronic Excuses State
  const [excuses, setExcuses] = useState<AttendanceExcuse[]>(() => {
    try {
      const saved = localStorage.getItem(`${STORAGE_KEY}_excuses`);
      if (saved) return JSON.parse(saved);
    } catch {
      // ignore
    }
    return INITIAL_EXCUSES;
  });

  // Sync excuses to localStorage
  useEffect(() => {
    try {
      localStorage.setItem(`${STORAGE_KEY}_excuses`, JSON.stringify(excuses));
    } catch {
      // ignore
    }
  }, [excuses]);

  // TA Proxy Mode State
  const [taProxySession, setTaProxySession] = useState<TAProxySession | null>(() => {
    try {
      const saved = localStorage.getItem(`${STORAGE_KEY}_ta_proxy`);
      if (saved) return JSON.parse(saved);
    } catch {
      // ignore
    }
    return null;
  });

  // Assistant Audit Logs State
  const [auditLogs, setAuditLogs] = useState<AssistantAuditLog[]>(() => {
    try {
      const saved = localStorage.getItem(`${STORAGE_KEY}_audit_logs`);
      if (saved) return JSON.parse(saved);
    } catch {
      // ignore
    }
    return INITIAL_AUDIT_LOGS;
  });

  // Sync TA proxy session and audit logs to localStorage
  useEffect(() => {
    try {
      if (taProxySession) {
        localStorage.setItem(`${STORAGE_KEY}_ta_proxy`, JSON.stringify(taProxySession));
      } else {
        localStorage.removeItem(`${STORAGE_KEY}_ta_proxy`);
      }
    } catch {
      // ignore
    }
  }, [taProxySession]);

  useEffect(() => {
    try {
      localStorage.setItem(`${STORAGE_KEY}_audit_logs`, JSON.stringify(auditLogs));
    } catch {
      // ignore
    }
  }, [auditLogs]);

  // Lecture Feedback State
  const [feedbacks, setFeedbacks] = useState<LectureFeedback[]>(() => {
    try {
      const saved = localStorage.getItem(`${STORAGE_KEY}_feedbacks`);
      if (saved) return JSON.parse(saved);
    } catch {
      // ignore
    }
    return INITIAL_FEEDBACKS;
  });

  // Student Participations State
  const [participations, setParticipations] = useState<StudentParticipation[]>(() => {
    try {
      const saved = localStorage.getItem(`${STORAGE_KEY}_participations`);
      if (saved) return JSON.parse(saved);
    } catch {
      // ignore
    }
    return INITIAL_PARTICIPATIONS;
  });

  useEffect(() => {
    try {
      localStorage.setItem(`${STORAGE_KEY}_feedbacks`, JSON.stringify(feedbacks));
    } catch {
      // ignore
    }
  }, [feedbacks]);

  useEffect(() => {
    try {
      localStorage.setItem(`${STORAGE_KEY}_participations`, JSON.stringify(participations));
    } catch {
      // ignore
    }
  }, [participations]);

  // Academic Advisor Alerts State
  const [advisorAlerts, setAdvisorAlerts] = useState<AcademicAdvisorAlert[]>(() => {
    try {
      const saved = localStorage.getItem(`${STORAGE_KEY}_advisor_alerts`);
      if (saved) return JSON.parse(saved);
    } catch {
      // ignore
    }
    return INITIAL_ADVISOR_ALERTS;
  });

  useEffect(() => {
    try {
      localStorage.setItem(`${STORAGE_KEY}_advisor_alerts`, JSON.stringify(advisorAlerts));
    } catch {
      // ignore
    }
  }, [advisorAlerts]);

  // Window online/offline event listeners
  useEffect(() => {
    const handleOnline = () => {
      setIsOnline(true);
    };
    const handleOffline = () => {
      setIsOnline(false);
    };

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  // Sync to localStorage
  useEffect(() => {
    try {
      localStorage.setItem(`${STORAGE_KEY}_attendance`, JSON.stringify(attendance));
    } catch {
      // ignore
    }
  }, [attendance]);

  // Keep selectedLectureId valid for selectedCourse
  useEffect(() => {
    const courseLectures = lectures.filter((l) => l.course_id === selectedCourseId);
    if (courseLectures.length > 0 && !courseLectures.some((l) => l.lecture_id === selectedLectureId)) {
      setSelectedLectureId(courseLectures[0].lecture_id);
    }
  }, [selectedCourseId, lectures, selectedLectureId]);

  // Sound chime
  const playAudioFeedback = (success: boolean) => {
    if (!soundEnabled) return;
    try {
      const ctx = new (window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext)();
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.connect(gain);
      gain.connect(ctx.destination);

      if (success) {
        osc.type = 'sine';
        osc.frequency.setValueAtTime(587.33, ctx.currentTime); // D5
        osc.frequency.setValueAtTime(880, ctx.currentTime + 0.1); // A5
        gain.gain.setValueAtTime(0.15, ctx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.35);
        osc.start();
        osc.stop(ctx.currentTime + 0.35);
      } else {
        osc.type = 'triangle';
        osc.frequency.setValueAtTime(300, ctx.currentTime);
        osc.frequency.setValueAtTime(200, ctx.currentTime + 0.12);
        gain.gain.setValueAtTime(0.2, ctx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.3);
        osc.start();
        osc.stop(ctx.currentTime + 0.3);
      }
    } catch {
      // AudioContext might be blocked until user gesture
    }
  };

  // Set single student status
  const setStudentStatus = (
    lectureId: number,
    studentId: number,
    status: AttendanceStatus,
    notes?: string
  ) => {
    const now = new Date().toISOString().replace('T', ' ').substring(0, 19);
    setAttendance((prev) => {
      const idx = prev.findIndex((a) => a.lecture_id === lectureId && a.student_id === studentId);
      if (idx >= 0) {
        const updated = [...prev];
        updated[idx] = {
          ...updated[idx],
          status,
          notes: notes !== undefined ? notes : updated[idx].notes,
          recorded_at: now,
        };
        return updated;
      }
      return [
        ...prev,
        {
          attendance_id: Date.now(),
          lecture_id: lectureId,
          student_id: studentId,
          status,
          notes: notes || '',
          recorded_at: now,
        },
      ];
    });
  };

  // Set notes
  const setStudentNotes = (lectureId: number, studentId: number, notes: string) => {
    const now = new Date().toISOString().replace('T', ' ').substring(0, 19);
    setAttendance((prev) => {
      const idx = prev.findIndex((a) => a.lecture_id === lectureId && a.student_id === studentId);
      if (idx >= 0) {
        const updated = [...prev];
        updated[idx] = { ...updated[idx], notes, recorded_at: now };
        return updated;
      }
      return [
        ...prev,
        {
          attendance_id: Date.now(),
          lecture_id: lectureId,
          student_id: studentId,
          status: 'Present',
          notes,
          recorded_at: now,
        },
      ];
    });
  };

  // Mark all enrolled students present
  const markAllPresent = (lectureId: number) => {
    const targetLecture = lectures.find((l) => l.lecture_id === lectureId);
    if (!targetLecture) return;

    const enrolledStudentIds = enrollments
      .filter((e) => e.course_id === targetLecture.course_id)
      .map((e) => e.student_id);

    const now = new Date().toISOString().replace('T', ' ').substring(0, 19);

    setAttendance((prev) => {
      const existingMap = new Map<number, AttendanceRecord>();
      prev.forEach((r) => {
        if (r.lecture_id === lectureId) {
          existingMap.set(r.student_id, r);
        }
      });

      const updatedRecords = prev.map((r) => {
        if (r.lecture_id === lectureId && enrolledStudentIds.includes(r.student_id)) {
          return { ...r, status: 'Present' as AttendanceStatus, recorded_at: now };
        }
        return r;
      });

      enrolledStudentIds.forEach((sId) => {
        if (!existingMap.has(sId)) {
          updatedRecords.push({
            attendance_id: Date.now() + sId,
            lecture_id: lectureId,
            student_id: sId,
            status: 'Present',
            notes: '',
            recorded_at: now,
          });
        }
      });

      return updatedRecords;
    });

    playAudioFeedback(true);
  };

  // Queue offline scan
  const queueOfflineScan = (
    lectureId: number,
    universityId: string,
    token: string,
    geoCoords?: GeoCoordinates | null
  ): {
    success: boolean;
    message: string;
    record?: OfflineScanRecord;
    studentName?: string;
    distanceMeters?: number;
    isWithinGeofence?: boolean;
  } => {
    const cleanUniId = universityId.trim();
    const cleanToken = token.trim();
    const nowTimeStr = new Date().toLocaleTimeString('ar-SA');

    // 1. Local TOTP validation
    const tokenResult = verifyToken(lectureId, cleanToken, totpInterval);
    if (!tokenResult.isValid) {
      playAudioFeedback(false);
      setRecentScans((prev) => [
        {
          id: Math.random().toString(),
          student_name: cleanUniId ? `رقم جامعي: ${cleanUniId}` : 'مسح مجهول',
          university_id: cleanUniId,
          timestamp: nowTimeStr,
          status: 'expired',
          message: `(وضع عدم الاتصال) ${tokenResult.message}`,
        },
        ...prev.slice(0, 19),
      ]);
      return {
        success: false,
        message: `(وضع عدم الاتصال) ${tokenResult.message}`,
      };
    }

    // 2. Student check
    const student = students.find((s) => s.university_id.toLowerCase() === cleanUniId.toLowerCase());
    if (!student) {
      playAudioFeedback(false);
      setRecentScans((prev) => [
        {
          id: Math.random().toString(),
          student_name: 'طالب غير معروف',
          university_id: cleanUniId,
          timestamp: nowTimeStr,
          status: 'not_found',
          message: `الرقم الجامعي (${cleanUniId}) غير موجود`,
        },
        ...prev.slice(0, 19),
      ]);
      return {
        success: false,
        message: `الرقم الجامعي (${cleanUniId}) غير مسجل في النظام`,
      };
    }

    // 3. Course Enrollment check
    const lecture = lectures.find((l) => l.lecture_id === lectureId);
    if (lecture) {
      const isEnrolled = enrollments.some(
        (e) => e.course_id === lecture.course_id && e.student_id === student.student_id
      );
      if (!isEnrolled) {
        playAudioFeedback(false);
        setRecentScans((prev) => [
          {
            id: Math.random().toString(),
            student_name: student.full_name,
            university_id: cleanUniId,
            timestamp: nowTimeStr,
            status: 'unregistered',
            message: `الطالب غير مسجل في هذا المقرر!`,
          },
          ...prev.slice(0, 19),
        ]);
        return {
          success: false,
          message: `عذراً، الطالب ${student.full_name} غير مسجل في هذا المقرر!`,
        };
      }
    }

    // 4. Geofence verification (if coords provided)
    let distanceMeters: number | undefined;
    let isWithinGeofence = true;
    if (geoCoords && lecture) {
      const hallConfig = {
        hallLat: lecture.hall_lat ?? DEFAULT_GEOFENCE_CONFIG.hallLat,
        hallLng: lecture.hall_lng ?? DEFAULT_GEOFENCE_CONFIG.hallLng,
        hallName: lecture.hall_name ?? DEFAULT_GEOFENCE_CONFIG.hallName,
        allowedRadiusMeters: lecture.allowed_radius_meters ?? DEFAULT_GEOFENCE_CONFIG.allowedRadiusMeters,
      };
      const geoCheck = verifyGeofence(geoCoords, hallConfig);
      distanceMeters = geoCheck.distanceMeters;
      isWithinGeofence = geoCheck.isWithin;

      if (!geoCheck.isWithin) {
        playAudioFeedback(false);
        setRecentScans((prev) => [
          {
            id: Math.random().toString(),
            student_name: student.full_name,
            university_id: cleanUniId,
            timestamp: nowTimeStr,
            status: 'out_of_range',
            message: `❌ خارج نطاق القاعة (${geoCheck.distanceMeters}م) في وضع عدم الاتصال`,
            distance_meters: geoCheck.distanceMeters,
            is_within_geofence: false,
          },
          ...prev.slice(0, 19),
        ]);
        return {
          success: false,
          message: `❌ فشل التسجيل: أنت خارج نطاق قاعة المحاضرة (${geoCheck.distanceMeters}م)! الحد الأقصى: ${geoCheck.allowedRadiusMeters}م`,
          studentName: student.full_name,
          distanceMeters: geoCheck.distanceMeters,
          isWithinGeofence: false,
        };
      }
    }

    // 5. Create and enqueue offline record
    const recordId = `offline_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`;
    const offlineRecord: OfflineScanRecord = {
      id: recordId,
      lecture_id: lectureId,
      university_id: cleanUniId,
      student_name: student.full_name,
      token: cleanToken,
      scanned_at: nowTimeStr,
      timestamp_ms: Date.now(),
      status: 'pending',
    };

    setOfflineQueue((prev) => [
      offlineRecord,
      ...prev.filter((r) => !(r.lecture_id === lectureId && r.university_id === cleanUniId)),
    ]);

    // Optimistically mark in local memory as Present with offline note
    const note = distanceMeters !== undefined
      ? `تم التحضير محلياً مع التحقق الجغرافي (${distanceMeters}م)`
      : 'تم التحضير محلياً (وضع عدم الاتصال)';
    setStudentStatus(lectureId, student.student_id, 'Present', note);
    playAudioFeedback(true);

    const successMsg = `تم حفظ حضور ${student.full_name} محلياً بدون إنترنت (بانتظار المزامنة)`;

    setRecentScans((prev) => [
      {
        id: recordId,
        student_name: student.full_name,
        university_id: cleanUniId,
        timestamp: nowTimeStr,
        status: 'offline_queued',
        message: successMsg,
        distance_meters: distanceMeters,
        is_within_geofence: true,
      },
      ...prev.slice(0, 19),
    ]);

    return {
      success: true,
      message: successMsg,
      record: offlineRecord,
      studentName: student.full_name,
    };
  };

  // Sync offline queue
  const syncOfflineQueue = async (): Promise<{ success: boolean; syncedCount: number; message: string }> => {
    const pending = offlineQueue.filter((r) => r.status === 'pending');
    if (pending.length === 0) {
      return { success: true, syncedCount: 0, message: 'لا توجد عمليات معلقة للمزامنة' };
    }

    // Small delay to simulate network sync
    await new Promise((res) => setTimeout(res, 400));

    let synced = 0;
    const syncedIds = new Set<string>();
    const failedIds = new Set<string>();
    pending.forEach((item) => {
      const student = students.find((s) => s.university_id.toLowerCase() === item.university_id.toLowerCase());
      if (student) {
        setStudentStatus(
          item.lecture_id,
          student.student_id,
          'Present',
          `تم التحضير بدون اتصال (${item.scanned_at}) - تمت المزامنة`
        );
        syncedIds.add(item.id);
        synced++;
      } else {
        failedIds.add(item.id);
      }
    });

    // Only touch the records that were actually processed (scans queued during the
    // delay above must stay pending), and flag unmatched records as failed instead
    // of silently reporting them as synced.
    setOfflineQueue((prev) =>
      prev.map((r) => {
        if (syncedIds.has(r.id)) return { ...r, status: 'synced' as const };
        if (failedIds.has(r.id)) {
          return { ...r, status: 'failed' as const, error_message: 'الرقم الجامعي غير موجود عند المزامنة' };
        }
        return r;
      })
    );

    playAudioFeedback(true);

    const nowTimeStr = new Date().toLocaleTimeString('ar-SA');
    setRecentScans((prev) => [
      {
        id: Math.random().toString(),
        student_name: `مزامنة ${synced} عمليات حضور`,
        university_id: 'SYNC',
        timestamp: nowTimeStr,
        status: 'success',
        message: `تمت مزامنة ${synced} عمليات بنجاح مع السيرفر وقاعدة البيانات!`,
      },
      ...prev.slice(0, 19),
    ]);

    return {
      success: failedIds.size === 0,
      syncedCount: synced,
      message:
        failedIds.size > 0
          ? `تمت مزامنة ${synced} عملية وفشلت ${failedIds.size} عملية (رقم جامعي غير معروف)`
          : `تمت مزامنة ${synced} عمليات حضور بنجاح مع قاعدة البيانات!`,
    };
  };

  const clearOfflineQueue = () => {
    setOfflineQueue([]);
    try {
      localStorage.removeItem(`${STORAGE_KEY}_offline_queue`);
    } catch {
      // ignore
    }
  };

  // Auto-sync when connection restores or simulated offline is toggled off
  useEffect(() => {
    if (isOnline && !isSimulatedOffline) {
      const hasPending = offlineQueue.some((r) => r.status === 'pending');
      if (hasPending) {
        syncOfflineQueue();
      }
    }
  }, [isOnline, isSimulatedOffline]);

  // Scan Attendance with TOTP and GPS Geofence validation
  const scanAttendance = (
    lectureId: number,
    universityId: string,
    token: string,
    geoCoords?: GeoCoordinates | null
  ): {
    success: boolean;
    message: string;
    studentName?: string;
    distanceMeters?: number;
    isWithinGeofence?: boolean;
  } => {
    // If device is offline or in simulated offline mode, route to offline queue
    if (!isOnline || isSimulatedOffline) {
      return queueOfflineScan(lectureId, universityId, token, geoCoords);
    }

    const cleanUniId = universityId.trim();
    const cleanToken = token.trim();
    const nowTimeStr = new Date().toLocaleTimeString('ar-SA');

    // 1. Validate Token Security
    const tokenResult = verifyToken(lectureId, cleanToken, totpInterval);

    if (!tokenResult.isValid) {
      playAudioFeedback(false);
      setRecentScans((prev) => [
        {
          id: Math.random().toString(),
          student_name: cleanUniId ? `رقم جامعي: ${cleanUniId}` : 'مسح مجهول',
          university_id: cleanUniId,
          timestamp: nowTimeStr,
          status: 'expired',
          message: tokenResult.message,
        },
        ...prev.slice(0, 19),
      ]);

      return {
        success: false,
        message: tokenResult.message,
      };
    }

    // 2. Validate Student exists
    const student = students.find((s) => s.university_id.toLowerCase() === cleanUniId.toLowerCase());
    if (!student) {
      playAudioFeedback(false);
      setRecentScans((prev) => [
        {
          id: Math.random().toString(),
          student_name: 'طالب غير معروف',
          university_id: cleanUniId,
          timestamp: nowTimeStr,
          status: 'not_found',
          message: `الرقم الجامعي (${cleanUniId}) غير مسجل في النظام`,
        },
        ...prev.slice(0, 19),
      ]);
      return {
        success: false,
        message: `الرقم الجامعي (${cleanUniId}) غير مسجل في النظام`,
      };
    }

    // 3. Validate Student is enrolled in this course
    const lecture = lectures.find((l) => l.lecture_id === lectureId);
    if (!lecture) {
      return { success: false, message: 'المحاضرة غير موجودة' };
    }

    const isEnrolled = enrollments.some(
      (e) => e.course_id === lecture.course_id && e.student_id === student.student_id
    );

    if (!isEnrolled) {
      playAudioFeedback(false);
      setRecentScans((prev) => [
        {
          id: Math.random().toString(),
          student_name: student.full_name,
          university_id: cleanUniId,
          timestamp: nowTimeStr,
          status: 'unregistered',
          message: `الطالب غير مسجل في هذا المقرر!`,
        },
        ...prev.slice(0, 19),
      ]);
      return {
        success: false,
        message: `عذراً، الطالب ${student.full_name} غير مسجل في هذا المقرر!`,
      };
    }

    // 4. GPS Geofence Verification (if coordinates are provided or checked)
    const geofenceConfig = {
      hallLat: lecture.hall_lat ?? DEFAULT_GEOFENCE_CONFIG.hallLat,
      hallLng: lecture.hall_lng ?? DEFAULT_GEOFENCE_CONFIG.hallLng,
      allowedRadiusMeters: lecture.allowed_radius_meters ?? DEFAULT_GEOFENCE_CONFIG.allowedRadiusMeters,
      hallName: lecture.hall_name ?? DEFAULT_GEOFENCE_CONFIG.hallName,
    };

    let distanceMeters: number | undefined;
    let isWithinGeofence = true;

    if (geoCoords) {
      const geoResult = verifyGeofence(geoCoords, geofenceConfig);
      distanceMeters = geoResult.distanceMeters;
      isWithinGeofence = geoResult.isWithin;

      if (!geoResult.isWithin) {
        playAudioFeedback(false);
        setRecentScans((prev) => [
          {
            id: Math.random().toString(),
            student_name: student.full_name,
            university_id: cleanUniId,
            timestamp: nowTimeStr,
            status: 'out_of_range',
            distance_meters: distanceMeters,
            is_within_geofence: false,
            message: `خارج قاعة المحاضرة (${distanceMeters}م - المسموح به: ${geofenceConfig.allowedRadiusMeters}م)`,
          },
          ...prev.slice(0, 19),
        ]);

        return {
          success: false,
          message: `❌ فشل التسجيل: أنت لست داخل قاعة المحاضرة! (المسافة: ${distanceMeters}م - الحد الأقصى: ${geofenceConfig.allowedRadiusMeters}م)`,
          studentName: student.full_name,
          distanceMeters,
          isWithinGeofence: false,
        };
      }
    }

    // 5. Mark Attendance Present
    const noteText = distanceMeters !== undefined
      ? `تم التحضير داخل القاعة (GPS: ${distanceMeters}م)`
      : 'تم التحضير عبر الباركود المتغير';

    setStudentStatus(lectureId, student.student_id, 'Present', noteText);
    playAudioFeedback(true);

    const successMessage = distanceMeters !== undefined
      ? `✅ أنت داخل القاعة (${distanceMeters}م)! تم تسجيل حضور ${student.full_name} بنجاح.`
      : `تم تسجيل حضور ${student.full_name} بنجاح!`;

    setRecentScans((prev) => [
      {
        id: Math.random().toString(),
        student_name: student.full_name,
        university_id: cleanUniId,
        timestamp: nowTimeStr,
        status: 'success',
        distance_meters: distanceMeters,
        is_within_geofence: true,
        photo_url: student.photo_url || DEFAULT_STUDENT_PHOTO_URL,
        verification_method: 'qr',
        message: distanceMeters !== undefined ? `📍 ضمن النطاق (${distanceMeters}م - مقبول)` : successMessage,
      },
      ...prev.slice(0, 19),
    ]);

    return {
      success: true,
      message: successMessage,
      studentName: student.full_name,
      distanceMeters,
      isWithinGeofence: true,
    };
  };

  // Simulation test scan
  const simulateQuickScan = (
    lectureId: number,
    studentId: number,
    valid: boolean,
    geoCoords?: GeoCoordinates | null
  ) => {
    const student = students.find((s) => s.student_id === studentId);
    if (!student) return { success: false, message: 'طالب غير موجود' };

    // If valid, use actual current token; if invalid, pass dummy expired token
    const token = valid
      ? generateToken(lectureId, getTimeWindow(totpInterval), totpInterval)
      : 'expired_token_999';
    return scanAttendance(lectureId, student.university_id, token, geoCoords);
  };

  // Verify Student Secret Code & Photo Identity (/api/verify-student-code)
  const verifyStudentSecretCode = async (
    universityId: string,
    secretCode: string,
    lectureId: number
  ): Promise<{
    success: boolean;
    message: string;
    student_name?: string;
    photo_url?: string;
    university_id?: string;
  }> => {
    const cleanUniId = universityId.trim();
    const cleanCode = secretCode.trim().toUpperCase();
    const nowTimeStr = new Date().toLocaleTimeString('ar-SA');

    // Send HTTP POST matching Flask route /api/verify-student-code
    try {
      await fetch('/api/verify-student-code', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          university_id: cleanUniId,
          secret_code: cleanCode,
          lecture_id: lectureId,
        }),
      });
    } catch {
      // Local browser execution fallback
    }

    const student = students.find(
      (s) =>
        s.university_id.toLowerCase() === cleanUniId.toLowerCase() &&
        s.secret_code.toUpperCase() === cleanCode
    );

    if (!student) {
      playAudioFeedback(false);
      setRecentScans((prev) => [
        {
          id: Math.random().toString(),
          student_name: cleanUniId ? `رقم جامعي: ${cleanUniId}` : 'تحقق غير صحيح',
          university_id: cleanUniId,
          timestamp: nowTimeStr,
          status: 'not_found',
          verification_method: 'secret_code',
          message: 'الرقم الجامعي أو الكود السري الخاص بالطالب غير صحيح!',
        },
        ...prev.slice(0, 19),
      ]);
      return {
        success: false,
        message: 'الرقم الجامعي أو الكود السري الخاص بالطالب غير صحيح!',
      };
    }

    const secretLecture = lectures.find((l) => l.lecture_id === lectureId);
    if (
      !secretLecture ||
      !enrollments.some((e) => e.course_id === secretLecture.course_id && e.student_id === student.student_id)
    ) {
      playAudioFeedback(false);
      setRecentScans((prev) => [
        {
          id: Math.random().toString(),
          student_name: student.full_name,
          university_id: student.university_id,
          timestamp: nowTimeStr,
          status: 'unregistered',
          verification_method: 'secret_code',
          message: 'الطالب غير مسجل في هذا المقرر!',
        },
        ...prev.slice(0, 19),
      ]);
      return { success: false, message: 'عذراً، الطالب غير مسجل في هذا المقرر!' };
    }

    const resolvedPhotoUrl = student.photo_url || DEFAULT_STUDENT_PHOTO_URL;
    setStudentStatus(
      lectureId,
      student.student_id,
      'Present',
      'تم التحقق عبر الكود السري الخاص بالطالب والصورة الشخصية (بدون تحقق GPS)'
    );
    playAudioFeedback(true);

    setRecentScans((prev) => [
      {
        id: Math.random().toString(),
        student_name: student.full_name,
        university_id: student.university_id,
        timestamp: nowTimeStr,
        status: 'success',
        photo_url: resolvedPhotoUrl,
        verification_method: 'secret_code',
        message: 'تم التحقق بالكود السري والصورة الشخصية بنجاح',
      },
      ...prev.slice(0, 19),
    ]);

    return {
      success: true,
      message: 'تم التحقق وتسجيل الحضور بنجاح!',
      student_name: student.full_name,
      photo_url: resolvedPhotoUrl,
      university_id: student.university_id,
    };
  };

  // Direct Student Check-In returning student photo & metadata for Instructor Live Screen (/api/check-in)
  const checkInStudent = async (
    studentId: number,
    lectureId: number
  ): Promise<{
    success: boolean;
    message?: string;
    error?: string;
    student_name?: string;
    university_id?: string;
    photo_url?: string;
  }> => {
    try {
      await fetch('/api/check-in', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          student_id: studentId,
          lecture_id: lectureId,
        }),
      });
    } catch {
      // Local browser execution fallback
    }

    const student = students.find((s) => s.student_id === studentId);
    if (!student) {
      playAudioFeedback(false);
      return { success: false, error: 'الطالب غير موجود' };
    }

    const ciLecture = lectures.find((l) => l.lecture_id === lectureId);
    if (
      !ciLecture ||
      !enrollments.some((e) => e.course_id === ciLecture.course_id && e.student_id === student.student_id)
    ) {
      playAudioFeedback(false);
      return { success: false, error: 'الطالب غير مسجل في هذا المقرر' };
    }

    const resolvedPhotoUrl = student.photo_url || DEFAULT_STUDENT_PHOTO_URL;
    const nowTimeStr = new Date().toLocaleTimeString('ar-SA');

    setStudentStatus(lectureId, student.student_id, 'Present', 'تم تسجيل الحضور (تسجيل مباشر من المحاضر)');
    playAudioFeedback(true);

    setRecentScans((prev) => [
      {
        id: Math.random().toString(),
        student_name: student.full_name,
        university_id: student.university_id,
        timestamp: nowTimeStr,
        status: 'success',
        photo_url: resolvedPhotoUrl,
        verification_method: 'qr',
        message: 'تم تسجيل الحضور بنجاح',
      },
      ...prev.slice(0, 19),
    ]);

    return {
      success: true,
      message: 'تم تسجيل الحضور بنجاح',
      student_name: student.full_name,
      university_id: student.university_id,
      photo_url: resolvedPhotoUrl,
    };
  };

  // Regenerate a unique 6-character alphanumeric secret code for a student
  const regenerateStudentSecretCode = (studentId: number): string => {
    const existingCodes = new Set(
      students.filter((s) => s.student_id !== studentId).map((s) => s.secret_code)
    );
    let newCode = '';
    do {
      newCode = generateSecretCode();
    } while (existingCodes.has(newCode));

    setStudents((prev) =>
      prev.map((s) => (s.student_id === studentId ? { ...s, secret_code: newCode } : s))
    );
    return newCode;
  };

  // Reset to default sample state
  const resetDatabase = () => {
    setStudents(INITIAL_STUDENTS);
    setAttendance(INITIAL_ATTENDANCE);
    setRecentScans([]);
    setOfflineQueue([]);
    setExcuses(INITIAL_EXCUSES);
    setTaProxySession(null);
    setAuditLogs(INITIAL_AUDIT_LOGS);
    setFeedbacks(INITIAL_FEEDBACKS);
    setParticipations(INITIAL_PARTICIPATIONS);
    setAdvisorAlerts(INITIAL_ADVISOR_ALERTS);
    try {
      localStorage.removeItem(`${STORAGE_KEY}_students`);
      localStorage.removeItem(`${STORAGE_KEY}_attendance`);
      localStorage.removeItem(`${STORAGE_KEY}_offline_queue`);
      localStorage.removeItem(`${STORAGE_KEY}_excuses`);
      localStorage.removeItem(`${STORAGE_KEY}_ta_proxy`);
      localStorage.removeItem(`${STORAGE_KEY}_audit_logs`);
      localStorage.removeItem(`${STORAGE_KEY}_feedbacks`);
      localStorage.removeItem(`${STORAGE_KEY}_participations`);
      localStorage.removeItem(`${STORAGE_KEY}_advisor_alerts`);
    } catch {
      // ignore
    }
  };

  // TA Proxy Mode Functions (وضع تفويض المعيد وسجل التدقيق)
  const activateTAProxy = async (
    assistantName: string,
    action?: string
  ): Promise<{ success: boolean; message: string }> => {
    const actionText = action || 'فتح القاعة وتفعيل الباركود المتغير نيابة عن الأستاذ';
    const nowStr = new Date().toLocaleString('ar-SA');
    const newSession: TAProxySession = {
      assistantName: assistantName.trim(),
      activatedAt: nowStr,
      lectureId: selectedLectureId,
      actionSummary: actionText,
    };
    setTaProxySession(newSession);

    const newLog: AssistantAuditLog = {
      log_id: Date.now(),
      lecture_id: selectedLectureId,
      assistant_name: assistantName.trim(),
      action_performed: actionText,
      timestamp: nowStr,
      status: 'نجاح',
      ip_address: '192.168.1.' + Math.floor(100 + Math.random() * 50),
    };
    setAuditLogs((prev) => [newLog, ...prev]);

    // Send asynchronous request matching user's backend route /api/assistant-action
    try {
      await fetch('/api/assistant-action', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          lecture_id: selectedLectureId,
          assistant_name: assistantName.trim(),
          action_performed: actionText,
        }),
      });
    } catch {
      // simulated success locally
    }

    return {
      success: true,
      message: `تم منح الصلاحية المؤقتة للمعيد: ${assistantName} وتوثيق العملية في سجل التدقيق بنجاح.`,
    };
  };

  const deactivateTAProxy = () => {
    if (taProxySession) {
      const nowStr = new Date().toLocaleString('ar-SA');
      const log: AssistantAuditLog = {
        log_id: Date.now(),
        lecture_id: selectedLectureId,
        assistant_name: taProxySession.assistantName,
        action_performed: 'إنهاء وضع التفويض واستعادة تحكم الأستاذ بالقاعة',
        timestamp: nowStr,
        status: 'نجاح',
        ip_address: '192.168.1.1',
      };
      setAuditLogs((prev) => [log, ...prev]);
    }
    setTaProxySession(null);
  };

  const recordAssistantAction = (
    action: string,
    assistantName?: string
  ): { success: boolean; message: string; log: AssistantAuditLog } => {
    const effectiveName = assistantName || taProxySession?.assistantName || 'معيد مفوض';
    const nowStr = new Date().toLocaleString('ar-SA');
    const log: AssistantAuditLog = {
      log_id: Date.now(),
      lecture_id: selectedLectureId,
      assistant_name: effectiveName,
      action_performed: action,
      timestamp: nowStr,
      status: 'نجاح',
      ip_address: '192.168.1.' + Math.floor(100 + Math.random() * 50),
    };
    setAuditLogs((prev) => [log, ...prev]);
    return { success: true, message: 'تم التوثيق في سجل التدقيق', log };
  };

  // Electronic Excuses - 1. Submit Excuse (Student)
  const submitExcuse = (
    studentId: number,
    lectureId: number,
    reasonText: string,
    documentUrl?: string
  ): { success: boolean; message: string; excuse?: AttendanceExcuse } => {
    if (!studentId || !lectureId || !reasonText.trim()) {
      return { success: false, message: 'جميع الحقول الأساسية مطلوبة لتقديم العذر' };
    }

    const student = students.find((s) => s.student_id === studentId);
    const lecture = lectures.find((l) => l.lecture_id === lectureId);
    const course = lecture ? courses.find((c) => c.course_id === lecture.course_id) : undefined;

    const newExcuse: AttendanceExcuse = {
      excuse_id: Date.now(),
      student_id: studentId,
      lecture_id: lectureId,
      reason_text: reasonText.trim(),
      document_url: documentUrl?.trim() || '',
      status: 'قيد المراجعة',
      submitted_at: new Date().toLocaleString('ar-SA'),
      student_name: student?.full_name,
      university_id: student?.university_id,
      lecture_topic: lecture?.topic,
      course_name: course?.course_name,
    };

    setExcuses((prev) => [newExcuse, ...prev]);

    return {
      success: true,
      message: 'تم إرسال العذر بنجاح وهو الآن قيد المراجعة من الأستاذ',
      excuse: newExcuse,
    };
  };

  // Electronic Excuses - 2. Review Excuse (Instructor Accept/Reject)
  const reviewExcuse = (
    excuseId: number,
    action: 'accept' | 'reject',
    reviewNotes?: string
  ): { success: boolean; message: string } => {
    const target = excuses.find((e) => e.excuse_id === excuseId);
    if (!target) {
      return { success: false, message: 'العذر غير موجود في النظام' };
    }

    const newStatus: ExcuseStatus = action === 'accept' ? 'مقبول' : 'مرفوض';

    setExcuses((prev) =>
      prev.map((e) =>
        e.excuse_id === excuseId
          ? {
              ...e,
              status: newStatus,
              review_notes:
                reviewNotes || (action === 'accept' ? 'تم اعتماد العذر من الأستاذ' : 'تم رفض العذر'),
            }
          : e
      )
    );

    if (action === 'accept') {
      // Automatically update attendance record status to Excused
      setStudentStatus(
        target.lecture_id,
        target.student_id,
        'Excused',
        `مقبول بعذر رسمي: ${target.reason_text.slice(0, 45)}`
      );
    }

    return {
      success: true,
      message: `تم تحديث حالة العذر بنجاح إلى: ${newStatus}`,
    };
  };

  // Electronic Excuses - 3. Perfect Attendance Students (Honor Roll API)
  const getPerfectAttendanceStudents = (lectureId: number) => {
    const records = attendance.filter(
      (a) => a.lecture_id === lectureId && a.status === 'Present' && a.is_within_geofence !== false
    );
    return records
      .map((r) => {
        const student = students.find((s) => s.student_id === r.student_id);
        if (!student) return null;
        return {
          student_id: student.student_id,
          full_name: student.full_name,
          university_id: student.university_id,
        };
      })
      .filter((s): s is { student_id: number; full_name: string; university_id: string } => Boolean(s));
  };

  // 1. Submit Lecture Feedback (تقييم المحاضرة الفوري من الطالب)
  const submitFeedback = async (
    lectureId: number,
    studentId: number,
    score: number
  ): Promise<{ success: boolean; message: string }> => {
    const student = students.find((s) => s.student_id === studentId);
    const newFeedback: LectureFeedback = {
      feedback_id: Date.now(),
      lecture_id: lectureId,
      student_id: studentId,
      understanding_score: Math.max(1, Math.min(10, score)),
      timestamp: new Date().toLocaleString('ar-SA'),
      student_name: student?.full_name,
    };

    setFeedbacks((prev) => [newFeedback, ...prev]);

    // Send HTTP POST to /api/submit-feedback matching Flask route
    try {
      await fetch('/api/submit-feedback', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          lecture_id: lectureId,
          student_id: studentId,
          understanding_score: score,
        }),
      });
    } catch {
      // Local fallback in browser
    }

    return {
      success: true,
      message: 'شكراً لك! تم إرسال تقييمك للمحاضرة بنجاح.',
    };
  };

  // Get Lecture Feedback Statistics (متوسط الاستيعاب وتوزيعه)
  const getLectureFeedbackStats = (lectureId: number) => {
    const lectureFeedbacks = feedbacks.filter((f) => f.lecture_id === lectureId);
    const count = lectureFeedbacks.length;
    if (count === 0) {
      return { average: 0, count: 0, breakdown: {} };
    }
    const sum = lectureFeedbacks.reduce((acc, f) => acc + f.understanding_score, 0);
    const average = Math.round((sum / count) * 10) / 10;
    const breakdown: Record<number, number> = {};
    lectureFeedbacks.forEach((f) => {
      breakdown[f.understanding_score] = (breakdown[f.understanding_score] || 0) + 1;
    });
    return { average, count, breakdown };
  };

  // 2. Add Participation Point (منح نقاط التفاعل والتميز)
  const addParticipationPoint = async (
    studentId: number,
    courseId: number,
    reason = 'مشاركة فعالة في المحاضرة'
  ): Promise<{ success: boolean; message: string }> => {
    const student = students.find((s) => s.student_id === studentId);
    const newPoint: StudentParticipation = {
      participation_id: Date.now(),
      student_id: studentId,
      course_id: courseId,
      points_added: 1,
      reason,
      timestamp: new Date().toLocaleString('ar-SA'),
      student_name: student?.full_name,
    };

    setParticipations((prev) => [newPoint, ...prev]);

    // Send HTTP POST to /api/add-participation-point matching Flask route
    try {
      await fetch('/api/add-participation-point', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          student_id: studentId,
          course_id: courseId,
          reason,
        }),
      });
    } catch {
      // Local fallback in browser
    }

    return {
      success: true,
      message: 'تم منح نقطة التميز والمشاركة للطالب بنجاح!',
    };
  };

  const getStudentParticipationPoints = (studentId: number, courseId?: number) => {
    return participations
      .filter((p) => p.student_id === studentId && (!courseId || p.course_id === courseId))
      .reduce((sum, p) => sum + p.points_added, 0);
  };

  // ==============================================================
  // SQL Query 1: Calculate attendance & absence % for course students
  // ==============================================================
  const getCourseAttendanceReport = (courseId: number): StudentAttendanceSummary[] => {
    const course = courses.find((c) => c.course_id === courseId);
    const courseLectures = lectures.filter((l) => l.course_id === courseId);
    const lectureIds = courseLectures.map((l) => l.lecture_id);
    const totalLecturesCount = courseLectures.length;

    const enrolledStudents = enrollments
      .filter((e) => e.course_id === courseId)
      .map((e) => students.find((s) => s.student_id === e.student_id))
      .filter((s): s is Student => Boolean(s));

    return enrolledStudents
      .map((student) => {
        const studentRecords = attendance.filter(
          (a) => a.student_id === student.student_id && lectureIds.includes(a.lecture_id)
        );

        let presentCount = 0;
        let absentCount = 0;
        let lateCount = 0;
        let excusedCount = 0;

        studentRecords.forEach((r) => {
          if (r.status === 'Present') presentCount++;
          else if (r.status === 'Absent') absentCount++;
          else if (r.status === 'Late') lateCount++;
          else if (r.status === 'Excused') excusedCount++;
        });

        // Unrecorded past lectures count as Absent
        const recordedCount = studentRecords.length;
        if (recordedCount < totalLecturesCount) {
          absentCount += totalLecturesCount - recordedCount;
        }

        const effectiveTotal = Math.max(totalLecturesCount, 1);
        const attendancePct = totalLecturesCount > 0 ? (presentCount / effectiveTotal) * 100 : 0;
        const absentPct = totalLecturesCount > 0 ? (absentCount / effectiveTotal) * 100 : 0;

        return {
          student_id: student.student_id,
          full_name: student.full_name,
          university_id: student.university_id,
          course_name: course?.course_name || '',
          course_code: course?.course_code || '',
          total_lectures: totalLecturesCount,
          present_count: presentCount,
          absent_count: absentCount,
          late_count: lateCount,
          excused_count: excusedCount,
          attendance_percentage: Math.round(attendancePct * 10) / 10,
          absent_percentage: Math.round(absentPct * 10) / 10,
        };
      })
      .sort((a, b) => b.absent_count - a.absent_count || a.full_name.localeCompare(b.full_name));
  };

  // ==============================================================
  // SQL Query 2: Students exceeding absence threshold
  // ==============================================================
  const getAbsenceThresholdReport = (
    courseId?: number,
    minAbsences = 3,
    minAbsencePct = 25
  ): StudentAttendanceSummary[] => {
    const targetCourses = courseId ? courses.filter((c) => c.course_id === courseId) : courses;
    const results: StudentAttendanceSummary[] = [];

    targetCourses.forEach((c) => {
      const summaries = getCourseAttendanceReport(c.course_id);
      summaries.forEach((s) => {
        if (s.absent_count > minAbsences || s.absent_percentage >= minAbsencePct) {
          results.push(s);
        }
      });
    });

    return results.sort((a, b) => b.absent_percentage - a.absent_percentage);
  };

  // ==============================================================
  // SQL Query 3: Lecture daily attendance log
  // ==============================================================
  const getLectureDetails = (lectureId: number) => {
    const lecture = lectures.find((l) => l.lecture_id === lectureId);
    if (!lecture) return { lecture: undefined, course: undefined, studentsWithStatus: [] };

    const course = courses.find((c) => c.course_id === lecture.course_id);
    const enrolledStudents = enrollments
      .filter((e) => e.course_id === lecture.course_id)
      .map((e) => students.find((s) => s.student_id === e.student_id))
      .filter((s): s is Student => Boolean(s));

    const lectureRecords = attendance.filter((a) => a.lecture_id === lectureId);
    const recordMap = new Map<number, AttendanceRecord>();
    lectureRecords.forEach((r) => recordMap.set(r.student_id, r));

    const studentsWithStatus = enrolledStudents.map((student) => {
      const record = recordMap.get(student.student_id);
      return {
        student,
        status: (record?.status || 'Absent') as AttendanceStatus,
        notes: record?.notes || '',
        recorded_at: record?.recorded_at,
      };
    });

    return {
      lecture,
      course,
      studentsWithStatus,
    };
  };

  // ==============================================================
  // Academic Advisor Alerts (تنبيهات الإرشاد الأكاديمي والإنذار المبكر)
  // ==============================================================
  const createAdvisorAlert = async (
    studentId: number,
    advisorName: string,
    absenceCount: number,
    notes = ''
  ): Promise<{ success: boolean; message: string; alert: AcademicAdvisorAlert }> => {
    const student = students.find((s) => s.student_id === studentId);
    const department = student?.department_id
      ? departments.find((d) => d.department_id === student.department_id)?.department_name
      : student?.department_name;

    const newAlert: AcademicAdvisorAlert = {
      alert_id: Date.now(),
      student_id: studentId,
      advisor_name: advisorName.trim() || 'د. عبد السلام الورفلي (المرشد الأكاديمي)',
      absence_count: absenceCount,
      status: 'قيد المتابعة',
      timestamp: new Date().toLocaleString('ar-SA'),
      student_name: student?.full_name,
      university_id: student?.university_id,
      department: department || 'تقنية المعلومات',
      notes: notes || `تنبيه مبكر للمرشد الأكاديمي بسبب تجاوز عدد الغيابات (${absenceCount} محاضرات).`,
    };

    setAdvisorAlerts((prev) => [newAlert, ...prev]);

    // Send HTTP POST to /api/academic-alerts matching Flask backend
    try {
      await fetch('/api/academic-alerts', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          student_id: studentId,
          advisor_name: newAlert.advisor_name,
          absence_count: absenceCount,
          status: 'قيد المتابعة',
          notes: newAlert.notes,
        }),
      });
    } catch {
      // Local fallback in browser
    }

    return {
      success: true,
      message: `تم رفع تنبيه الإرشاد الأكاديمي للطالب (${student?.full_name || studentId}) بنجاح.`,
      alert: newAlert,
    };
  };

  const updateAdvisorAlertStatus = async (
    alertId: number,
    status: AdvisorAlertStatus,
    notes?: string
  ): Promise<{ success: boolean; message: string }> => {
    setAdvisorAlerts((prev) =>
      prev.map((a) =>
        a.alert_id === alertId
          ? {
              ...a,
              status,
              notes: notes ? `${a.notes ? a.notes + ' | ' : ''}${notes}` : a.notes,
            }
          : a
      )
    );

    // Send HTTP PUT to /api/academic-alerts/<id>
    try {
      await fetch(`/api/academic-alerts/${alertId}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status, notes }),
      });
    } catch {
      // Local fallback
    }

    return {
      success: true,
      message: `تم تحديث حالة التنبيه الأكاديمي إلى: (${status})`,
    };
  };

  const deleteAdvisorAlert = (alertId: number) => {
    setAdvisorAlerts((prev) => prev.filter((a) => a.alert_id !== alertId));
  };

  const autoGenerateAdvisorAlerts = (): number => {
    const existingStudentIds = new Set(advisorAlerts.map((a) => a.student_id));
    let newAlertsCount = 0;
    const newAlerts: AcademicAdvisorAlert[] = [];

    courses.forEach((c) => {
      const summaries = getCourseAttendanceReport(c.course_id);
      summaries.forEach((s) => {
        if (s.absent_count >= 2 && !existingStudentIds.has(s.student_id)) {
          existingStudentIds.add(s.student_id);
          newAlertsCount++;
          const studentObj = students.find((st) => st.student_id === s.student_id);
          const dept = studentObj?.department_id
            ? departments.find((d) => d.department_id === studentObj.department_id)?.department_name
            : studentObj?.department_name;

          newAlerts.push({
            alert_id: Date.now() + newAlertsCount,
            student_id: s.student_id,
            advisor_name: 'د. عبد السلام الورفلي (مرشد التخصص)',
            absence_count: s.absent_count,
            status: 'قيد المتابعة',
            timestamp: new Date().toLocaleString('ar-SA'),
            student_name: s.full_name,
            university_id: s.university_id,
            department: dept || 'تقنية المعلومات',
            notes: `إنذار مبكر تلقائي: غياب ${s.absent_count} محاضرات (${s.absent_percentage}%) في مقرر ${s.course_code}.`,
          });
        }
      });
    });

    if (newAlerts.length > 0) {
      setAdvisorAlerts((prev) => [...newAlerts, ...prev]);
    }

    return newAlertsCount;
  };

  const value = useMemo(
    () => ({
      departments,
      courses,
      students,
      enrollments,
      lectures,
      attendance,
      selectedCourseId,
      selectedLectureId,
      totpInterval,
      soundEnabled,
      recentScans,
      setSelectedCourseId,
      setSelectedLectureId,
      setTotpInterval,
      setSoundEnabled,
      setStudentStatus,
      setStudentNotes,
      markAllPresent,
      scanAttendance,
      simulateQuickScan,
      verifyStudentSecretCode,
      checkInStudent,
      regenerateStudentSecretCode,
      resetDatabase,
      getCourseAttendanceReport,
      getAbsenceThresholdReport,
      getLectureDetails,
      // Offline mode
      isOnline,
      isSimulatedOffline,
      setIsSimulatedOffline,
      offlineQueue,
      queueOfflineScan,
      syncOfflineQueue,
      clearOfflineQueue,
      // Excuses
      excuses,
      submitExcuse,
      reviewExcuse,
      getPerfectAttendanceStudents,
      // TA Proxy Mode & Audit Logs
      taProxySession,
      auditLogs,
      activateTAProxy,
      deactivateTAProxy,
      recordAssistantAction,
      // Lecture Feedback (تقييم المحاضرة الفوري)
      feedbacks,
      submitFeedback,
      getLectureFeedbackStats,
      // Student Participation Points (نقاط التفاعل والمشاركة)
      participations,
      addParticipationPoint,
      getStudentParticipationPoints,
      // Academic Advisor Alerts (تنبيهات الإرشاد الأكاديمي والإنذار المبكر)
      advisorAlerts,
      createAdvisorAlert,
      updateAdvisorAlertStatus,
      deleteAdvisorAlert,
      autoGenerateAdvisorAlerts,
    }),
    [
      departments,
      courses,
      students,
      enrollments,
      lectures,
      attendance,
      selectedCourseId,
      selectedLectureId,
      totpInterval,
      soundEnabled,
      recentScans,
      isOnline,
      isSimulatedOffline,
      offlineQueue,
      excuses,
      taProxySession,
      auditLogs,
      feedbacks,
      participations,
      advisorAlerts,
    ]
  );

  return <AttendanceContext.Provider value={value}>{children}</AttendanceContext.Provider>;
};

export const useAttendance = () => {
  const context = useContext(AttendanceContext);
  if (!context) {
    throw new Error('useAttendance must be used within an AttendanceProvider');
  }
  return context;
};
