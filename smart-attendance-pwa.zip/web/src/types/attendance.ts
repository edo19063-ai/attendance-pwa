export interface Department {
  department_id: number;
  department_name: string;
}

export interface Student {
  student_id: number;
  full_name: string;
  university_id: string;
  email: string;
  department_id: number;
  department_name?: string;
  avatar_url?: string;
  photo_url?: string;
  secret_code: string;
}

export interface Course {
  course_id: number;
  course_name: string;
  course_code: string;
  instructor_name: string;
  department_id?: number;
}

export interface CourseEnrollment {
  enrollment_id: number;
  student_id: number;
  course_id: number;
  semester: string;
}

export interface Lecture {
  lecture_id: number;
  course_id: number;
  lecture_date: string; // YYYY-MM-DD
  lecture_time: string; // HH:mm:ss
  topic: string;
  hall_name?: string;
  hall_lat?: number;
  hall_lng?: number;
  allowed_radius_meters?: number;
}

export type AttendanceStatus = 'Present' | 'Absent' | 'Late' | 'Excused';

export interface AttendanceRecord {
  attendance_id: number;
  lecture_id: number;
  student_id: number;
  status: AttendanceStatus;
  notes?: string;
  recorded_at: string;
  distance_meters?: number;
  is_within_geofence?: boolean;
}

export interface StudentAttendanceSummary {
  student_id: number;
  full_name: string;
  university_id: string;
  course_name: string;
  course_code: string;
  total_lectures: number;
  present_count: number;
  absent_count: number;
  late_count: number;
  excused_count: number;
  attendance_percentage: number;
  absent_percentage: number;
}

export interface RecentScanEvent {
  id: string;
  student_name: string;
  university_id: string;
  timestamp: string;
  status: 'success' | 'expired' | 'unregistered' | 'not_found' | 'offline_queued' | 'out_of_range';
  message: string;
  distance_meters?: number;
  is_within_geofence?: boolean;
  photo_url?: string;
  verification_method?: 'qr' | 'secret_code';
}

export interface OfflineScanRecord {
  id: string;
  lecture_id: number;
  university_id: string;
  student_name?: string;
  token: string;
  scanned_at: string;
  timestamp_ms: number;
  status: 'pending' | 'synced' | 'failed';
  error_message?: string;
}

export type ExcuseStatus = 'قيد المراجعة' | 'مقبول' | 'مرفوض';

export interface AttendanceExcuse {
  excuse_id: number;
  student_id: number;
  lecture_id: number;
  reason_text: string;
  document_url?: string;
  status: ExcuseStatus;
  submitted_at: string;
  student_name?: string;
  university_id?: string;
  lecture_topic?: string;
  course_name?: string;
  review_notes?: string;
}

export interface TAProxySession {
  assistantName: string;
  activatedAt: string;
  lectureId: number;
  actionSummary: string;
}

export interface AssistantAuditLog {
  log_id: number;
  lecture_id: number;
  assistant_name: string;
  action_performed: string;
  timestamp: string;
  status: 'نجاح' | 'تحذير' | 'فشل';
  ip_address?: string;
}

export interface LectureFeedback {
  feedback_id: number;
  lecture_id: number;
  student_id: number;
  understanding_score: number; // 1 to 10
  timestamp: string;
  student_name?: string;
}

export interface StudentParticipation {
  participation_id: number;
  student_id: number;
  course_id: number;
  points_added: number;
  reason?: string;
  timestamp: string;
  student_name?: string;
}

export type AdvisorAlertStatus = 'قيد المتابعة' | 'تم التدخل' | 'مغلق';

export interface AcademicAdvisorAlert {
  alert_id: number;
  student_id: number;
  advisor_name: string;
  absence_count: number;
  status: AdvisorAlertStatus;
  timestamp: string;
  student_name?: string;
  university_id?: string;
  department?: string;
  notes?: string;
}

