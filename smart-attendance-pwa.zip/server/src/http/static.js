import fs from 'node:fs';
import path from 'node:path';

const TYPES = {
  '.html': 'text/html; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.mjs': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.webmanifest': 'application/manifest+json; charset=utf-8',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.svg': 'image/svg+xml',
  '.ico': 'image/x-icon',
  '.woff2': 'font/woff2',
  '.woff': 'font/woff',
  '.txt': 'text/plain; charset=utf-8',
  '.map': 'application/json; charset=utf-8',
};

// ملفات يجب ألا تُخزَّن طويلاً كي تصل التحديثات فوراً
const NO_CACHE = new Set(['/index.html', '/sw.js', '/manifest.webmanifest']);

/**
 * يخدم الواجهة المبنية (dist) من نفس الخادم، مع:
 *  - حماية من اجتياز المسارات (../)
 *  - رجوع إلى index.html لمسارات التطبيق (SPA)
 *  - تخزين مؤقت طويل لملفات /assets (أسماؤها تحوي hash)
 * لا يلمس أي مسار يبدأ بـ /api.
 */
export function serveStatic(rootDir) {
  const root = path.resolve(rootDir);
  const indexFile = path.join(root, 'index.html');

  return (req, res, next) => {
    if (req.method !== 'GET' && req.method !== 'HEAD') return next();
    if (req.path === '/api' || req.path.startsWith('/api/')) return next();

    let rel;
    try {
      rel = decodeURIComponent(req.path);
    } catch {
      return res.sendStatus(400);
    }
    if (rel.includes('\0')) return res.sendStatus(400);

    const file = path.join(root, path.normalize(rel));
    if (file !== root && !file.startsWith(root + path.sep)) return res.sendStatus(403);

    let target = file;
    let stat = null;
    try {
      stat = fs.statSync(file);
      if (stat.isDirectory()) {
        target = path.join(file, 'index.html');
        stat = fs.statSync(target);
      }
    } catch {
      stat = null;
    }

    if (!stat || !stat.isFile()) {
      // ملف بامتداد غير موجود = 404 حقيقي. مسار بلا امتداد = صفحة من التطبيق.
      if (path.extname(rel)) return next();
      target = indexFile;
      try {
        stat = fs.statSync(indexFile);
      } catch {
        return next();
      }
    }

    const urlPath = '/' + path.relative(root, target).split(path.sep).join('/');
    let cache = 'public, max-age=86400';
    if (urlPath.startsWith('/assets/')) cache = 'public, max-age=31536000, immutable';
    else if (NO_CACHE.has(urlPath)) cache = 'no-cache';

    res.set({
      'Content-Type': TYPES[path.extname(target).toLowerCase()] || 'application/octet-stream',
      'Content-Length': String(stat.size),
      'Cache-Control': cache,
    });
    if (req.method === 'HEAD') return res.end();

    const stream = fs.createReadStream(target);
    stream.on('error', () => res.destroy());
    stream.pipe(res);
  };
}
