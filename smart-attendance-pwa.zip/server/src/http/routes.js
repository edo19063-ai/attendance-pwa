import express from 'express';
import { safeEqual, signSession } from '../lib/crypto.js';
import { AppError } from '../services/attendance.js';
import { rateLimit, requireRole } from './middleware.js';

const id = (v) => {
  const n = Number(v);
  if (!Number.isInteger(n) || n <= 0) throw new AppError(400, 'invalid_id', 'معرّف غير صالح');
  return n;
};
const pickGeo = (g) =>
  g && typeof g === 'object' ? { lat: g.lat, lng: g.lng, accuracy: g.accuracy } : undefined;

export function buildRouter({ config, service }) {
  const r = express.Router();
  const instructor = requireRole(config, service); // المحاضر فقط
  const staff = requireRole(config, service, { allowAssistant: true, lectureParam: 'id' }); // محاضر أو معيد لهذه المحاضرة
  const anyStaff = requireRole(config, service, { allowAssistant: true }); // بلا تقييد بمحاضرة (للمعلومات العامة)

  // ---------- المصادقة ----------
  r.post('/auth/login', rateLimit({ windowMs: 15 * 60_000, max: 10, failuresOnly: true }), (req, res) => {
    const password = typeof req.body?.password === 'string' ? req.body.password : '';
    if (!safeEqual(password, config.adminPassword)) {
      throw new AppError(401, 'invalid_credentials', 'كلمة المرور غير صحيحة');
    }
    const exp = Date.now() + config.instructorSessionMs;
    res.json({ ok: true, token: signSession({ role: 'instructor', exp }, config.sessionSecret), expiresAt: exp });
  });

  r.post('/auth/assistant-login', rateLimit({ windowMs: 15 * 60_000, max: 10, failuresOnly: true }), (req, res) => {
    const grant = service.assistantLogin(req.body?.accessCode, { ip: req.ip });
    // لا تتجاوز الجلسة نهاية التفويض
    const exp = Math.min(grant.expiresAt, Date.now() + config.instructorSessionMs);
    res.json({
      ok: true,
      token: signSession({ role: 'assistant', delegationId: grant.delegationId, exp }, config.sessionSecret),
      expiresAt: exp,
      assistantName: grant.assistantName,
      lectureId: grant.lectureId,
    });
  });

  r.get('/auth/me', anyStaff, (req, res) => {
    if (req.role === 'assistant') {
      const d = req.delegation;
      return res.json({ ok: true, role: 'assistant', assistantName: d.assistantName, lectureId: d.lectureId, expiresAt: d.expiresAt });
    }
    res.json({ ok: true, role: 'instructor' });
  });

  // ---------- تقييم المحاضرة (الطالب برمز قصير العمر) ----------
  r.post('/feedback', rateLimit({ windowMs: 60_000, max: config.scanRatePerIpPerMinute }), (req, res) => {
    const b = req.body || {};
    res.status(201).json({ ok: true, ...service.submitFeedback({ feedbackToken: b.feedbackToken, score: b.score }) });
  });

  // ---------- الطالب ----------
  r.post(
    '/attendance/scan',
    rateLimit({ windowMs: 60_000, max: config.scanRatePerIpPerMinute }),
    rateLimit({ windowMs: 60_000, max: 10, key: (req) => `uid:${String(req.body?.universityId || '').toLowerCase()}` }),
    (req, res) => {
      const b = req.body || {};
      const { studentId, ...out } = service.scan(
        { lectureId: b.lectureId, universityId: b.universityId, secretCode: b.secretCode,
          token: b.token, deviceId: b.deviceId, geo: pickGeo(b.geo) },
        { ip: req.ip }
      );
      res.json({
        ok: true,
        ...out,
        // رمز تقييم قصير العمر + نقاط الطالب في المقرر (لا حاجة لإعادة إرسال الكود السري)
        feedbackToken: service.issueFeedbackToken(studentId, b.lectureId),
        participationPoints: service.participationPoints(b.lectureId, studentId),
      });
    }
  );

  // ---------- الأعذار: تقديم الطالب ----------
  const uidKey = (req) => `uid:${String(req.body?.universityId || '').toLowerCase()}`;
  const studentLimits = [
    rateLimit({ windowMs: 60_000, max: config.scanRatePerIpPerMinute }),
    rateLimit({ windowMs: 60_000, max: 10, key: uidKey }),
  ];

  r.post('/excuses', ...studentLimits, (req, res) => {
    const b = req.body || {};
    const excuse = service.submitExcuse(
      { universityId: b.universityId, secretCode: b.secretCode, lectureId: b.lectureId,
        reasonText: b.reasonText, documentUrl: b.documentUrl },
      { ip: req.ip }
    );
    res.status(201).json({ ok: true, excuse });
  });

  r.post('/excuses/mine', ...studentLimits, (req, res) => {
    const b = req.body || {};
    res.json({ ok: true, excuses: service.listMine({ universityId: b.universityId, secretCode: b.secretCode }, { ip: req.ip }) });
  });

  // ---------- المحاضر (كلها محمية) ----------
  r.post('/lectures/:id/session/open', staff, (req, res) =>
    res.json({ ok: true, ...service.openSession(id(req.params.id), req.actor) }));

  r.post('/lectures/:id/session/close', staff, (req, res) =>
    res.json({ ok: true, ...service.closeSession(id(req.params.id), req.actor) }));

  r.get('/lectures/:id/token', staff, (req, res) =>
    res.json({ ok: true, ...service.getLiveToken(id(req.params.id)) }));

  r.get('/lectures/:id/roster', staff, (req, res) => {
    const lectureId = id(req.params.id);
    const points = service.pointsForLecture(lectureId);
    const roster = service.getRoster(lectureId).map((row) => ({ ...row, points: points.get(row.studentId) || 0 }));
    res.json({ ok: true, roster });
  });

  r.put('/lectures/:id/attendance/:studentId', staff, (req, res) => {
    const { status, notes } = req.body || {};
    res.json({ ok: true, ...service.setStatus(id(req.params.id), id(req.params.studentId), status, notes ?? '', req.actor) });
  });

  r.get('/courses/:id/report', instructor, (req, res) =>
    res.json({ ok: true, ...service.getReport(id(req.params.id)) }));

  r.post('/students/:id/secret/rotate', instructor, (req, res) =>
    res.json({ ok: true, ...service.rotateSecret(id(req.params.id), req.actor) }));

  r.get('/audit', instructor, (req, res) =>
    res.json({ ok: true, events: service.listAudit(Number(req.query.limit) || 100) }));

  // ---------- الأعذار: مراجعة المحاضر ----------
  r.get('/excuses', instructor, (req, res) => {
    const lectureId = req.query.lectureId ? id(req.query.lectureId) : undefined;
    res.json({ ok: true, excuses: service.listExcuses({ status: req.query.status || undefined, lectureId }) });
  });

  r.post('/excuses/:id/review', instructor, (req, res) => {
    const { action, notes } = req.body || {};
    res.json({ ok: true, excuse: service.reviewExcuse(id(req.params.id), action, notes ?? '', req.actor) });
  });

  // ---------- الإرشاد الأكاديمي ----------
  r.get('/advising/at-risk', instructor, (req, res) => {
    const q = req.query;
    res.json({
      ok: true,
      students: service.atRisk({
        minAbsences: q.minAbsences === undefined ? 2 : Number(q.minAbsences),
        minPct: q.minPct === undefined ? 20 : Number(q.minPct),
      }),
    });
  });

  r.get('/academic-alerts', instructor, (_req, res) => res.json({ ok: true, alerts: service.listAlerts() }));

  r.post('/academic-alerts/auto-generate', instructor, (req, res) =>
    res.json({ ok: true, ...service.autoGenerate(req.actor) }));

  r.post('/academic-alerts', instructor, (req, res) =>
    res.status(201).json({ ok: true, alert: service.createAlert(req.body || {}, req.actor) }));

  r.put('/academic-alerts/:id', instructor, (req, res) =>
    res.json({ ok: true, alert: service.updateAlert(id(req.params.id), req.body || {}, req.actor) }));

  r.delete('/academic-alerts/:id', instructor, (req, res) =>
    res.json({ ok: true, ...service.deleteAlert(id(req.params.id), req.actor) }));

  // ---------- نقاط التفاعل والتقييمات (محاضر أو معيد مفوَّض لهذه المحاضرة) ----------
  r.post('/lectures/:id/participation', staff, (req, res) => {
    const b = req.body || {};
    res.status(201).json({ ok: true, ...service.addParticipation(id(req.params.id), b.studentId, b.reason, req.actor) });
  });

  r.get('/lectures/:id/feedback', staff, (req, res) =>
    res.json({ ok: true, ...service.feedbackStats(id(req.params.id)) }));

  // ---------- تفويض المعيد (المحاضر فقط) ----------
  r.post('/delegations', instructor, (req, res) => {
    const b = req.body || {};
    res.status(201).json({
      ok: true,
      ...service.createDelegation(
        { assistantName: b.assistantName, lectureId: b.lectureId, durationMinutes: b.durationMinutes },
        req.actor, { ip: req.ip }),
    });
  });

  r.get('/delegations', instructor, (req, res) => {
    const lectureId = req.query.lectureId ? id(req.query.lectureId) : undefined;
    res.json({ ok: true, delegations: service.listDelegations({ lectureId }) });
  });

  r.post('/delegations/:id/revoke', instructor, (req, res) =>
    res.json({ ok: true, delegation: service.revokeDelegation(id(req.params.id), req.actor) }));

  // سجل تدقيق المحاضرة (للمحاضر أو للمعيد المفوَّض لها)
  r.get('/lectures/:id/assistant-log', staff, (req, res) =>
    res.json({ ok: true, logs: service.assistantLog(id(req.params.id)) }));

  return r;
}
