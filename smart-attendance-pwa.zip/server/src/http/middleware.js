import { verifySession } from '../lib/crypto.js';
import { AppError } from '../services/attendance.js';

const CSP = [
  "default-src 'self'",
  "script-src 'self'",
  "style-src 'self' 'unsafe-inline' https://fonts.googleapis.com",
  "font-src 'self' data: https://fonts.gstatic.com",
  "img-src 'self' data: blob: https://cdn-icons-png.flaticon.com",
  "connect-src 'self'",
  "media-src 'self' blob:",
  "worker-src 'self' blob:",
  "manifest-src 'self'",
  "object-src 'none'",
  "base-uri 'self'",
  "form-action 'self'",
  "frame-ancestors 'none'",
].join('; ');

export function securityHeaders(config = {}) {
  return (req, res, next) => {
    const headers = {
      'X-Content-Type-Options': 'nosniff',
      'X-Frame-Options': 'DENY',
      'Referrer-Policy': 'no-referrer',
      'Permissions-Policy': 'camera=(self), geolocation=(self), microphone=()',
      'Cache-Control': 'no-store', // الـ API والرموز لا تُخزَّن (الملفات الثابتة تضبط رأسها بنفسها)
    };
    if (config.cspEnabled !== false) headers['Content-Security-Policy'] = CSP;
    // HSTS فقط عندما يكون الاتصال HTTPS فعلاً (خلف وسيط موثوق)
    if (config.trustProxy && req.secure) headers['Strict-Transport-Security'] = 'max-age=31536000';
    res.set(headers);
    next();
  };
}

/** CORS بقائمة بيضاء صريحة (لا يوجد "*"). */
export function cors(allowedOrigins) {
  return (req, res, next) => {
    const origin = req.headers.origin;
    if (origin && allowedOrigins.includes(origin)) {
      res.set({
        'Access-Control-Allow-Origin': origin,
        'Access-Control-Allow-Headers': 'Authorization, Content-Type',
        'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
        'Access-Control-Max-Age': '600', // يقلّل طلبات preflight على شبكات الجوال
        Vary: 'Origin',
      });
    }
    if (req.method === 'OPTIONS') return res.sendStatus(204);
    next();
  };
}

/**
 * محدّد معدّل بسيط في الذاكرة (نافذة ثابتة). لعدة نسخ من الخادم استخدم Redis.
 * failuresOnly: لا يُحتسب إلا الطلبات الفاشلة (status >= 400)، فلا يُحجب من ينجح.
 */
export function rateLimit({ windowMs, max, key = (req) => req.ip, message = 'طلبات كثيرة، حاول لاحقاً', failuresOnly = false }) {
  const hits = new Map();
  setInterval(() => {
    const t = Date.now();
    for (const [k, v] of hits) if (v.reset <= t) hits.delete(k);
  }, windowMs).unref();

  const block = (res, h, t) => {
    res.set('Retry-After', String(Math.ceil((h.reset - t) / 1000)));
    return res.status(429).json({ ok: false, code: 'rate_limited', message });
  };

  return (req, res, next) => {
    const k = key(req);
    const t = Date.now();
    let h = hits.get(k);
    if (!h || h.reset <= t) {
      h = { count: 0, reset: t + windowMs };
      hits.set(k, h);
    }
    if (failuresOnly) {
      if (h.count >= max) return block(res, h, t);
      res.on('finish', () => {
        if (res.statusCode >= 400) h.count += 1;
      });
      return next();
    }
    h.count += 1;
    if (h.count > max) return block(res, h, t);
    next();
  };
}

/**
 * حماية المسارات بالدور:
 *  - المحاضر: صلاحية كاملة.
 *  - المعيد (allowAssistant): يعمل بتفويض مؤقت مقيّد بمحاضرة واحدة. يُتحقق عند كل طلب أن التفويض
 *    ما زال فعالاً (لم يُسحب ولم ينتهِ) وأن المحاضرة المطلوبة هي محاضرته (lectureParam).
 *  - أي مسار آخر للمعيد = 403 (لا يُسجَّل خروجه، لأن جلسته صالحة لكنها غير مخوَّلة هنا).
 */
export function requireRole(config, service, { allowAssistant = false, lectureParam = null } = {}) {
  return (req, _res, next) => {
    const header = req.headers.authorization || '';
    const token = header.startsWith('Bearer ') ? header.slice(7) : '';
    const payload = verifySession(token, config.sessionSecret);
    if (!payload) return next(new AppError(401, 'unauthorized', 'يلزم تسجيل الدخول'));

    if (payload.role === 'instructor') {
      req.role = 'instructor';
      req.actor = 'instructor';
      return next();
    }
    if (payload.role === 'assistant') {
      if (!allowAssistant) return next(new AppError(403, 'forbidden', 'هذه الصلاحية للمحاضر فقط'));
      try {
        const d = service.checkDelegation(payload.delegationId); // 401 delegation_ended إن سُحب/انتهى
        if (lectureParam && Number(req.params[lectureParam]) !== d.lectureId) {
          return next(new AppError(403, 'out_of_scope', 'تفويضك يخص محاضرة أخرى'));
        }
        req.role = 'assistant';
        req.actor = `assistant:${d.assistantName}`;
        req.delegation = d;
        return next();
      } catch (e) {
        return next(e);
      }
    }
    return next(new AppError(401, 'unauthorized', 'يلزم تسجيل الدخول'));
  };
}

export function notFound(_req, _res, next) {
  next(new AppError(404, 'not_found', 'المسار غير موجود'));
}

// eslint-disable-next-line no-unused-vars
export function errorHandler(err, _req, res, _next) {
  if (err instanceof AppError) return res.status(err.status).json({ ok: false, code: err.code, message: err.message });
  if (err?.type === 'entity.parse.failed') return res.status(400).json({ ok: false, code: 'bad_json', message: 'JSON غير صالح' });
  if (err?.type === 'entity.too.large') return res.status(413).json({ ok: false, code: 'too_large', message: 'الطلب كبير جداً' });
  console.error('[internal error]', err); // التفاصيل في السجل فقط، لا تُرسل للعميل
  res.status(500).json({ ok: false, code: 'internal_error', message: 'خطأ داخلي في الخادم' });
}
