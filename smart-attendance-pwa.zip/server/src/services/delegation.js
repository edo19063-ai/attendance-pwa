import { AppError } from './attendance.js';
import { hashSecret, verifySecret, generateSecretCode, DUMMY_HASH } from '../lib/crypto.js';

const MIN_MINUTES = 15;
const MAX_MINUTES = 240;
const DEFAULT_MINUTES = 120;
const MAX_ACTIVE = 20;
const MAX_FAILED = 5;
const LOCK_MS = 15 * 60_000;
const CODE_PATTERN = /^(\d{1,9})-([A-Za-z2-9]{10})$/;

const STATUS_AR = { Present: 'حاضر', Absent: 'غائب', Late: 'متأخر', Excused: 'معذور' };

/**
 * تفويض المعيد: صلاحية مؤقتة (محاضرة واحدة + مدة محددة) يمنحها المحاضر ويمكنه سحبها.
 * يدخل المعيد بكود مستقل (id-CODE) يظهر للمحاضر مرة واحدة فقط ويُخزَّن مجزّأً.
 */
export function createDelegationService({ store, now = () => Date.now(), attendance }) {
  const { audit, getLecture } = attendance.internals;
  const db = () => store.db;
  const failures = new Map(); // delegationId -> { count, lockedUntil }

  const statusOf = (d, t) => (d.revokedAt ? 'revoked' : t >= d.expiresAt ? 'expired' : 'active');
  const view = (d) => ({
    id: d.id,
    assistantName: d.assistantName,
    lectureId: d.lectureId,
    createdAt: new Date(d.createdAt).toISOString(),
    expiresAt: new Date(d.expiresAt).toISOString(),
    revokedAt: d.revokedAt ? new Date(d.revokedAt).toISOString() : null,
    status: statusOf(d, now()),
  });

  function createDelegation({ assistantName, lectureId, durationMinutes } = {}, actor = 'instructor', meta = {}) {
    if (typeof assistantName !== 'string' || assistantName.trim().length < 2 || assistantName.trim().length > 60
      || /[\u0000-\u001f]/.test(assistantName)) {
      throw new AppError(400, 'invalid_name', 'اسم المعيد من 2 إلى 60 حرفاً');
    }
    if (!Number.isInteger(lectureId) || lectureId <= 0) throw new AppError(400, 'invalid_request', 'المحاضرة غير محددة');
    const minutes = durationMinutes === undefined ? DEFAULT_MINUTES : durationMinutes;
    if (!Number.isInteger(minutes) || minutes < MIN_MINUTES || minutes > MAX_MINUTES) {
      throw new AppError(400, 'invalid_duration', `المدة من ${MIN_MINUTES} إلى ${MAX_MINUTES} دقيقة`);
    }
    getLecture(lectureId);
    const t = now();
    if (db().delegations.filter((d) => statusOf(d, t) === 'active').length >= MAX_ACTIVE) {
      throw new AppError(429, 'too_many_delegations', 'عدد التفويضات النشطة بلغ الحد الأقصى');
    }

    const code = generateSecretCode(10);
    const d = {
      id: store.nextId('delegations'),
      assistantName: assistantName.trim(),
      lectureId,
      codeHash: hashSecret(code),
      createdAt: t,
      expiresAt: t + minutes * 60_000,
      revokedAt: null,
    };
    db().delegations.push(d);
    audit('delegation_created', {
      lectureId, delegationId: d.id, assistantName: d.assistantName, actor, ip: meta.ip,
      expiresAt: new Date(d.expiresAt).toISOString(),
    });
    // الكود الكامل يُعرض هنا مرة واحدة فقط
    return { delegation: view(d), accessCode: `${d.id}-${code}` };
  }

  const listDelegations = ({ lectureId } = {}) =>
    db()
      .delegations.filter((d) => (lectureId ? d.lectureId === lectureId : true))
      .sort((a, b) => b.id - a.id)
      .map(view);

  function revokeDelegation(delegationId, actor = 'instructor') {
    const d = db().delegations.find((x) => x.id === delegationId);
    if (!d) throw new AppError(404, 'delegation_not_found', 'التفويض غير موجود');
    if (statusOf(d, now()) !== 'active') throw new AppError(409, 'not_active', 'التفويض منتهٍ أو مسحوب مسبقاً');
    d.revokedAt = now();
    audit('delegation_revoked', { lectureId: d.lectureId, delegationId: d.id, assistantName: d.assistantName, actor });
    return view(d);
  }

  /** دخول المعيد بالكود. الأخطاء عامة كي لا يُستدل على وجود تفويض معين. */
  function assistantLogin(accessCode, meta = {}) {
    const m = typeof accessCode === 'string' ? CODE_PATTERN.exec(accessCode.trim()) : null;
    if (!m) throw new AppError(400, 'invalid_request', 'كود التفويض غير مكتمل');
    const delegationId = Number(m[1]);
    const code = m[2].toUpperCase();

    const t = now();
    const f = failures.get(delegationId);
    if (f && f.lockedUntil > t) {
      throw new AppError(429, 'locked', 'تم إيقاف الدخول بهذا الكود مؤقتاً بعد محاولات خاطئة');
    }

    const d = db().delegations.find((x) => x.id === delegationId);
    const ok = verifySecret(code, d ? d.codeHash : DUMMY_HASH);
    if (!d || !ok) {
      const rec = failures.get(delegationId) || { count: 0, lockedUntil: 0 };
      rec.count += 1;
      if (rec.count >= MAX_FAILED) { rec.lockedUntil = t + LOCK_MS; rec.count = 0; }
      failures.set(delegationId, rec);
      audit('assistant_login_failed', { delegationId, ip: meta.ip });
      throw new AppError(401, 'invalid_access_code', 'كود التفويض غير صحيح');
    }
    if (statusOf(d, t) !== 'active') {
      throw new AppError(401, 'delegation_ended', 'انتهى هذا التفويض أو سُحب. اطلب كوداً جديداً من المحاضر');
    }
    failures.delete(delegationId);
    audit('assistant_login', { lectureId: d.lectureId, delegationId: d.id, assistantName: d.assistantName, ip: meta.ip });
    return { delegationId: d.id, assistantName: d.assistantName, lectureId: d.lectureId, expiresAt: d.expiresAt };
  }

  /** يُستدعى مع كل طلب من المعيد: يتحقق أن التفويض ما زال فعالاً (لم يُسحب ولم ينتهِ). */
  function checkDelegation(delegationId) {
    const d = db().delegations.find((x) => x.id === delegationId);
    if (!d || statusOf(d, now()) !== 'active') {
      throw new AppError(401, 'delegation_ended', 'انتهى التفويض أو سُحب');
    }
    return { id: d.id, assistantName: d.assistantName, lectureId: d.lectureId, expiresAt: d.expiresAt };
  }

  const ACTIONS = {
    delegation_created: (e) => `منح تفويض مؤقت للمعيد ${e.assistantName} (ينتهي ${new Date(e.expiresAt).toLocaleTimeString('ar-SA')})`,
    delegation_revoked: (e) => `سحب تفويض المعيد ${e.assistantName}`,
    assistant_login: () => 'دخول المعيد بكود التفويض',
    session_opened: () => 'فتح جلسة الحضور وتفعيل الباركود المتغير',
    session_closed: () => 'إغلاق جلسة الحضور',
    manual_status: (e) => `تعديل حالة الطالب #${e.studentId} إلى ${STATUS_AR[e.status] || e.status}`,
    participation_added: (e) => `منح نقطة تفاعل للطالب #${e.studentId}`,
  };

  /** سجل تدقيق المحاضرة: كل ما يتعلق بالتفويض وأفعال المعيد (مأخوذ من سجل التدقيق العام). */
  function assistantLog(lectureId, limit = 200) {
    getLecture(lectureId);
    const rows = [];
    for (const e of db().audit) {
      if (e.lectureId !== lectureId || !ACTIONS[e.event]) continue;
      const isAssistantActor = typeof e.actor === 'string' && e.actor.startsWith('assistant:');
      const isDelegationEvent = e.event.startsWith('delegation_') || e.event === 'assistant_login';
      if (!isAssistantActor && !isDelegationEvent) continue;
      rows.push({
        log_id: e.id,
        lecture_id: lectureId,
        assistant_name: e.assistantName ?? (isAssistantActor ? e.actor.slice('assistant:'.length) : 'المحاضر'),
        action_performed: ACTIONS[e.event](e),
        timestamp: new Date(e.at).toLocaleString('ar-SA'),
        status: 'نجاح',
        ip_address: e.ip,
      });
    }
    return rows.reverse().slice(0, Math.min(Math.max(limit, 1), 500));
  }

  return { createDelegation, listDelegations, revokeDelegation, assistantLogin, checkDelegation, assistantLog };
}
