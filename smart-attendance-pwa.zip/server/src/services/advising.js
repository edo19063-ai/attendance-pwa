import { AppError } from './attendance.js';

export const ALERT_STATUSES = ['قيد المتابعة', 'تم التدخل', 'مغلق'];
const DEFAULT_ADVISOR = 'د. عبد السلام الورفلي (المرشد الأكاديمي)';

const int = (v, min, max, name) => {
  const n = Number(v);
  if (!Number.isInteger(n) || n < min || n > max) throw new AppError(400, 'invalid_param', `قيمة ${name} غير صالحة`);
  return n;
};

/** الإرشاد الأكاديمي والإنذار المبكر: كل الحسابات من سجلات الحضور على الخادم. */
export function createAdvisingService({ store, now = () => Date.now(), attendance }) {
  const { audit } = attendance.internals;
  const db = () => store.db;

  const alertView = (a) => {
    const student = db().students.find((s) => s.id === a.studentId);
    return {
      id: a.id,
      studentId: a.studentId,
      universityId: student?.universityId ?? '',
      studentName: student?.fullName ?? '',
      advisorName: a.advisorName,
      absenceCount: a.absenceCount,
      status: a.status,
      notes: a.notes,
      createdAt: a.createdAt,
      updatedAt: a.updatedAt,
    };
  };

  /** طلاب تجاوزوا حد الغياب في أي مقرر (غياب >= الحد أو نسبة غياب >= النسبة). */
  function atRisk({ minAbsences = 2, minPct = 20 } = {}) {
    const minA = int(minAbsences, 0, 100, 'minAbsences');
    const minP = int(minPct, 0, 100, 'minPct');
    const worst = new Map(); // الطالب -> أسوأ مقرر
    for (const course of db().courses) {
      const { rows, totalLectures } = attendance.getReport(course.id);
      for (const r of rows) {
        const pct = totalLectures > 0 ? Math.round((r.absent / totalLectures) * 1000) / 10 : 0;
        if (r.absent >= minA || pct >= minP) {
          const prev = worst.get(r.studentId);
          if (!prev || r.absent > prev.absent) {
            worst.set(r.studentId, {
              studentId: r.studentId, universityId: r.universityId, fullName: r.fullName,
              courseId: course.id, courseName: course.name, courseCode: course.code,
              absent: r.absent, totalLectures, absentPercentage: pct,
            });
          }
        }
      }
    }
    return [...worst.values()].sort((a, b) => b.absent - a.absent);
  }

  const listAlerts = () => [...db().alerts].sort((a, b) => b.id - a.id).map(alertView);

  function createAlert({ studentId, advisorName, absenceCount, notes } = {}, actor = 'instructor') {
    const sid = int(studentId, 1, 1e9, 'studentId');
    const count = int(absenceCount, 0, 999, 'absenceCount');
    if (!db().students.some((s) => s.id === sid)) throw new AppError(404, 'student_not_found', 'الطالب غير موجود');
    if (advisorName !== undefined && (typeof advisorName !== 'string' || advisorName.length > 100)) {
      throw new AppError(400, 'invalid_param', 'اسم المرشد غير صالح');
    }
    if (notes !== undefined && (typeof notes !== 'string' || notes.length > 500)) {
      throw new AppError(400, 'invalid_param', 'ملاحظات غير صالحة');
    }
    const t = new Date(now()).toISOString();
    const a = {
      id: store.nextId('alerts'),
      studentId: sid,
      advisorName: (advisorName || '').trim() || DEFAULT_ADVISOR,
      absenceCount: count,
      status: 'قيد المتابعة',
      notes: (notes || '').trim() || `تنبيه مبكر للمرشد الأكاديمي بسبب تجاوز عدد الغيابات (${count} محاضرات).`,
      createdAt: t,
      updatedAt: t,
    };
    db().alerts.push(a);
    audit('alert_created', { alertId: a.id, studentId: sid, actor });
    return alertView(a);
  }

  function updateAlert(alertId, { status, notes } = {}, actor = 'instructor') {
    const a = db().alerts.find((x) => x.id === alertId);
    if (!a) throw new AppError(404, 'alert_not_found', 'التنبيه غير موجود');
    if (!ALERT_STATUSES.includes(status)) throw new AppError(400, 'invalid_status', 'حالة غير صالحة');
    if (notes !== undefined && (typeof notes !== 'string' || notes.length > 500)) {
      throw new AppError(400, 'invalid_param', 'ملاحظات غير صالحة');
    }
    a.status = status;
    if (notes && notes.trim()) a.notes = `${a.notes ? a.notes + ' | ' : ''}${notes.trim()}`.slice(-2000);
    a.updatedAt = new Date(now()).toISOString();
    audit('alert_updated', { alertId, status, actor });
    return alertView(a);
  }

  function deleteAlert(alertId, actor = 'instructor') {
    const idx = db().alerts.findIndex((x) => x.id === alertId);
    if (idx === -1) throw new AppError(404, 'alert_not_found', 'التنبيه غير موجود');
    db().alerts.splice(idx, 1);
    audit('alert_deleted', { alertId, actor });
    return { id: alertId };
  }

  /** ينشئ تنبيهاً لكل طالب غابَ مرتين فأكثر ولا يملك تنبيهاً سابقاً. */
  function autoGenerate(actor = 'instructor') {
    const have = new Set(db().alerts.map((a) => a.studentId));
    let created = 0;
    for (const r of atRisk({ minAbsences: 2, minPct: 100 })) {
      if (r.absent < 2 || have.has(r.studentId)) continue;
      have.add(r.studentId);
      createAlert(
        {
          studentId: r.studentId,
          advisorName: 'د. عبد السلام الورفلي (مرشد التخصص)',
          absenceCount: r.absent,
          notes: `إنذار مبكر تلقائي: غياب ${r.absent} محاضرات (${r.absentPercentage}%) في مقرر ${r.courseCode}.`,
        },
        actor
      );
      created++;
    }
    return { created };
  }

  return { atRisk, listAlerts, createAlert, updateAlert, deleteAlert, autoGenerate };
}
