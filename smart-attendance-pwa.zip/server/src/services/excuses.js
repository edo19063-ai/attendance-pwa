import { AppError } from './attendance.js';

const STATUS_VALUES = ['pending', 'accepted', 'rejected'];
const MAX_EXCUSES_PER_STUDENT = 50;

/** يقبل روابط http/https فقط (يمنع javascript: وdata: وغيرها). */
function cleanUrl(raw) {
  if (raw === undefined || raw === null || raw === '') return '';
  if (typeof raw !== 'string' || raw.length > 500 || /\s/.test(raw)) {
    throw new AppError(400, 'invalid_document_url', 'رابط المستند غير صالح');
  }
  let u;
  try {
    u = new URL(raw);
  } catch {
    throw new AppError(400, 'invalid_document_url', 'رابط المستند غير صالح');
  }
  if (u.protocol !== 'https:' && u.protocol !== 'http:') {
    throw new AppError(400, 'invalid_document_url', 'يُقبل رابط يبدأ بـ http أو https فقط');
  }
  return u.toString();
}

const str = (v, min, max) => typeof v === 'string' && v.trim().length >= min && v.trim().length <= max;

/** الأعذار الإلكترونية: يقدّمها الطالب بهويته، ويراجعها المحاضر فيتحدّث الحضور تلقائياً. */
export function createExcusesService({ store, now = () => Date.now(), attendance }) {
  const { audit, authenticateStudent, getLecture, isEnrolled, findRecord } = attendance.internals;
  const db = () => store.db;

  const view = (e) => {
    const student = db().students.find((s) => s.id === e.studentId);
    const lecture = db().lectures.find((l) => l.id === e.lectureId);
    const course = lecture ? db().courses.find((c) => c.id === lecture.courseId) : undefined;
    return {
      id: e.id,
      studentId: e.studentId,
      universityId: student?.universityId ?? '',
      studentName: student?.fullName ?? '',
      lectureId: e.lectureId,
      lectureTopic: lecture?.topic ?? '',
      courseName: course?.name ?? '',
      reasonText: e.reasonText,
      documentUrl: e.documentUrl,
      status: e.status,
      submittedAt: e.submittedAt,
      reviewedAt: e.reviewedAt,
      reviewNotes: e.reviewNotes,
    };
  };

  function checkCreds(input) {
    const i = input || {};
    if (!str(i.universityId, 3, 32) || !str(i.secretCode, 4, 32)) {
      throw new AppError(400, 'invalid_request', 'الرقم الجامعي والكود السري مطلوبان');
    }
    return { universityId: i.universityId.trim(), secretCode: i.secretCode.trim().toUpperCase() };
  }

  /** تقديم عذر من الطالب (يتطلب الرقم الجامعي والكود السري). */
  function submitExcuse(input, meta = {}) {
    const { universityId, secretCode } = checkCreds(input);
    const i = input;
    if (!Number.isInteger(i.lectureId) || i.lectureId <= 0) throw new AppError(400, 'invalid_request', 'المحاضرة غير محددة');
    if (!str(i.reasonText, 5, 1000)) throw new AppError(400, 'invalid_reason', 'اكتب سبب العذر (5 أحرف على الأقل، و1000 كحد أقصى)');
    const documentUrl = cleanUrl(i.documentUrl);

    const student = authenticateStudent(universityId, secretCode, meta, 'excuse');
    const lecture = getLecture(i.lectureId);
    if (!isEnrolled(lecture.courseId, student.id)) throw new AppError(403, 'not_enrolled', 'أنت غير مسجل في هذا المقرر');

    const rec = findRecord(i.lectureId, student.id);
    if (rec && (rec.status === 'Present' || rec.status === 'Late')) {
      throw new AppError(409, 'already_present', 'أنت مسجل حاضراً في هذه المحاضرة، لا حاجة لعذر');
    }
    if (rec && rec.status === 'Excused') throw new AppError(409, 'already_excused', 'غيابك مُعذَّر مسبقاً في هذه المحاضرة');

    const mine = db().excuses.filter((e) => e.studentId === student.id);
    if (mine.some((e) => e.lectureId === i.lectureId && e.status === 'pending')) {
      throw new AppError(409, 'duplicate_pending', 'لديك طلب عذر قيد المراجعة لهذه المحاضرة');
    }
    if (mine.some((e) => e.lectureId === i.lectureId && e.status === 'accepted')) {
      throw new AppError(409, 'already_excused', 'عذرك لهذه المحاضرة مقبول مسبقاً');
    }
    if (mine.length >= MAX_EXCUSES_PER_STUDENT) {
      throw new AppError(429, 'too_many_excuses', 'تجاوزت الحد الأقصى لعدد الأعذار');
    }

    const excuse = {
      id: store.nextId('excuses'),
      studentId: student.id,
      lectureId: i.lectureId,
      reasonText: i.reasonText.trim(),
      documentUrl,
      status: 'pending',
      submittedAt: new Date(now()).toISOString(),
      reviewedAt: null,
      reviewNotes: '',
    };
    db().excuses.push(excuse);
    audit('excuse_submitted', { excuseId: excuse.id, studentId: student.id, lectureId: i.lectureId, ip: meta.ip });
    return view(excuse);
  }

  /** أعذار الطالب نفسه (لمعرفة حالتها). */
  function listMine(input, meta = {}) {
    const { universityId, secretCode } = checkCreds(input);
    const student = authenticateStudent(universityId, secretCode, meta, 'excuse');
    return db()
      .excuses.filter((e) => e.studentId === student.id)
      .sort((a, b) => b.id - a.id)
      .map(view);
  }

  /** للمحاضر: كل الأعذار مع إمكانية التصفية. */
  function listExcuses({ status, lectureId } = {}) {
    if (status !== undefined && !STATUS_VALUES.includes(status)) throw new AppError(400, 'invalid_status', 'حالة غير صالحة');
    return db()
      .excuses.filter((e) => (status ? e.status === status : true) && (lectureId ? e.lectureId === lectureId : true))
      .sort((a, b) => b.id - a.id)
      .map(view);
  }

  /** مراجعة المحاضر: القبول يحوّل الغياب إلى «معذور» في سجل الحضور فوراً. */
  function reviewExcuse(excuseId, action, notes = '', actor = 'instructor') {
    if (action !== 'accept' && action !== 'reject') throw new AppError(400, 'invalid_action', 'إجراء غير صالح');
    if (typeof notes !== 'string' || notes.length > 500) throw new AppError(400, 'invalid_notes', 'ملاحظات غير صالحة');
    const e = db().excuses.find((x) => x.id === excuseId);
    if (!e) throw new AppError(404, 'excuse_not_found', 'العذر غير موجود');
    if (e.status !== 'pending') throw new AppError(409, 'already_reviewed', 'تمت مراجعة هذا العذر مسبقاً');

    if (action === 'accept') {
      // قبل تغيير حالة العذر: إن فشل التحديث (مثلاً أُلغي تسجيل الطالب) لا يتغير شيء
      attendance.setStatus(e.lectureId, e.studentId, 'Excused', `مقبول بعذر رسمي: ${e.reasonText.slice(0, 45)}`, actor);
    }
    e.status = action === 'accept' ? 'accepted' : 'rejected';
    e.reviewedAt = new Date(now()).toISOString();
    e.reviewNotes = notes.trim() || (action === 'accept' ? 'تم اعتماد العذر من الأستاذ' : 'تم رفض العذر');
    audit('excuse_reviewed', { excuseId, action, studentId: e.studentId, lectureId: e.lectureId, actor });
    return view(e);
  }

  return { submitExcuse, listMine, listExcuses, reviewExcuse };
}
