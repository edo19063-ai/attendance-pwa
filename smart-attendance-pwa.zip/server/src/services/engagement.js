import { AppError } from './attendance.js';
import { signSession, verifySession } from '../lib/crypto.js';

const FEEDBACK_TTL_MS = 30 * 60_000;
const MAX_POINTS_PER_STUDENT_PER_LECTURE = 10;
const DEFAULT_REASON = 'مشاركة وتفاعل إيجابي في المحاضرة';

/** نقاط التفاعل وتقييم المحاضرات (كلاهما على الخادم). */
export function createEngagementService({ store, config, now = () => Date.now(), attendance }) {
  const { audit, getLecture, isEnrolled, findRecord } = attendance.internals;
  const db = () => store.db;

  // ---------------------------------------------------------------- نقاط التفاعل
  function pointsMap(courseId) {
    const m = new Map();
    for (const p of db().participations) {
      if (p.courseId === courseId) m.set(p.studentId, (m.get(p.studentId) || 0) + p.points);
    }
    return m;
  }

  const pointsForLecture = (lectureId) => pointsMap(getLecture(lectureId).courseId);

  /** يمنح المحاضر (أو المعيد المفوَّض لهذه المحاضرة) نقطة تفاعل لطالب مسجل في المقرر. */
  function addParticipation(lectureId, studentId, reason, actor = 'instructor') {
    const lecture = getLecture(lectureId);
    if (!Number.isInteger(studentId) || studentId <= 0) throw new AppError(400, 'invalid_request', 'الطالب غير محدد');
    if (reason !== undefined && reason !== null && (typeof reason !== 'string' || reason.length > 200)) {
      throw new AppError(400, 'invalid_reason', 'سبب غير صالح');
    }
    const student = db().students.find((s) => s.id === studentId);
    if (!student) throw new AppError(404, 'student_not_found', 'الطالب غير موجود');
    if (!isEnrolled(lecture.courseId, studentId)) throw new AppError(403, 'not_enrolled', 'الطالب غير مسجل في المقرر');

    const given = db().participations.filter((p) => p.lectureId === lectureId && p.studentId === studentId).length;
    if (given >= MAX_POINTS_PER_STUDENT_PER_LECTURE) {
      throw new AppError(429, 'too_many_points', 'بلغ الطالب الحد الأقصى لنقاط هذه المحاضرة');
    }
    db().participations.push({
      id: store.nextId('participations'),
      studentId,
      courseId: lecture.courseId,
      lectureId,
      points: 1,
      reason: (reason || '').trim() || DEFAULT_REASON,
      createdAt: new Date(now()).toISOString(),
      actor,
    });
    audit('participation_added', { lectureId, studentId, actor });
    return { studentId, studentName: student.fullName, points: pointsMap(lecture.courseId).get(studentId) || 0 };
  }

  const participationPoints = (lectureId, studentId) => pointsForLecture(lectureId).get(studentId) || 0;

  // ---------------------------------------------------------------- تقييم المحاضرة
  /** رمز قصير العمر يُمنح للطالب عند نجاح تسجيل حضوره، فيقيّم المحاضرة بدون إعادة إدخال كوده السري. */
  const issueFeedbackToken = (studentId, lectureId) =>
    signSession({ purpose: 'feedback', studentId, lectureId, exp: now() + FEEDBACK_TTL_MS }, config.sessionSecret);

  function submitFeedback(input) {
    const i = input || {};
    const payload = typeof i.feedbackToken === 'string' ? verifySession(i.feedbackToken, config.sessionSecret, now()) : null;
    if (!payload || payload.purpose !== 'feedback') {
      throw new AppError(401, 'invalid_feedback_token', 'انتهت صلاحية التقييم. سجّل حضورك مجدداً ثم قيّم المحاضرة');
    }
    if (!Number.isInteger(i.score) || i.score < 1 || i.score > 10) {
      throw new AppError(400, 'invalid_score', 'التقييم رقم صحيح من 1 إلى 10');
    }
    const { studentId, lectureId } = payload;
    getLecture(lectureId);
    const rec = findRecord(lectureId, studentId);
    if (!rec || (rec.status !== 'Present' && rec.status !== 'Late')) {
      throw new AppError(409, 'not_attended', 'يقيّم المحاضرة من سجّل حضوره فقط');
    }
    if (db().feedbacks.some((f) => f.lectureId === lectureId && f.studentId === studentId)) {
      throw new AppError(409, 'already_rated', 'قيّمت هذه المحاضرة مسبقاً');
    }
    db().feedbacks.push({
      id: store.nextId('feedbacks'), lectureId, studentId, score: i.score, createdAt: new Date(now()).toISOString(),
    });
    audit('feedback_submitted', { lectureId, studentId });
    return { ok: true };
  }

  /** إحصاءات مجهولة الهوية: لا تُرجع أسماء الطلاب. */
  function feedbackStats(lectureId) {
    getLecture(lectureId);
    const rows = db().feedbacks.filter((f) => f.lectureId === lectureId);
    const count = rows.length;
    if (count === 0) return { average: 0, count: 0, breakdown: {} };
    const breakdown = {};
    let sum = 0;
    for (const f of rows) {
      sum += f.score;
      breakdown[f.score] = (breakdown[f.score] || 0) + 1;
    }
    return { average: Math.round((sum / count) * 10) / 10, count, breakdown };
  }

  return { addParticipation, pointsForLecture, participationPoints, issueFeedbackToken, submitFeedback, feedbackStats };
}
