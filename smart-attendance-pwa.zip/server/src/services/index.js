import { createAttendanceService } from './attendance.js';
import { createExcusesService } from './excuses.js';
import { createAdvisingService } from './advising.js';
import { createEngagementService } from './engagement.js';
import { createDelegationService } from './delegation.js';

/** يجمع كل الخدمات في كائن واحد تستخدمه طبقة HTTP. */
export function createServices({ store, config, now }) {
  const attendance = createAttendanceService({ store, config, now });
  const excuses = createExcusesService({ store, now, attendance });
  const advising = createAdvisingService({ store, now, attendance });
  const engagement = createEngagementService({ store, config, now, attendance });
  const delegation = createDelegationService({ store, now, attendance });
  const { internals, ...publicAttendance } = attendance; // لا نعرض الدوال الداخلية
  return { ...publicAttendance, ...excuses, ...advising, ...engagement, ...delegation };
}
