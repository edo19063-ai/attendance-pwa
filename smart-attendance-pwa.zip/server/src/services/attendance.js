import { createHmac, randomBytes } from 'node:crypto';
import { currentToken, verifyToken } from '../lib/token.js';
import { checkGeofence } from '../lib/geo.js';
import { hashSecret, verifySecret, generateSecretCode, DUMMY_HASH } from '../lib/crypto.js';

export class AppError extends Error {
  constructor(status, code, message) {
    super(message);
    this.status = status;
    this.code = code;
  }
}

export const STATUSES = ['Present', 'Absent', 'Late', 'Excused'];
const AUDIT_LIMIT = 5000;

/**
 * منطق العمل كاملاً. لا يعتمد على Express ولا على ساعة النظام مباشرة (now قابلة للحقن)،
 * لذلك يمكن اختباره بالكامل.
 */
export function createAttendanceService({ store, config, now = () => Date.now() }) {
  const failures = new Map(); // universityId -> { count, lockedUntil }
  const pepper = createHmac('sha256', config.tokenSecret).update('device-pepper').digest();
  const hashDevice = (deviceId) => createHmac('sha256', pepper).update(deviceId).digest('hex');
  const db = () => store.db;

  function audit(event, data = {}) {
    const d = db();
    d.audit.push({ id: store.nextId('audit'), at: new Date(now()).toISOString(), event, ...data });
    if (d.audit.length > AUDIT_LIMIT) d.audit.splice(0, d.audit.length - AUDIT_LIMIT);
    store.save();
  }

  const getLecture = (id) => {
    const lecture = db().lectures.find((l) => l.id === id);
    if (!lecture) throw new AppError(404, 'lecture_not_found', 'المحاضرة غير موجودة');
    return lecture;
  };
  const getOpenSession = (lectureId) => {
    const s = db().sessions[lectureId];
    if (!s || s.closedAt) throw new AppError(409, 'session_closed', 'جلسة الحضور غير مفتوحة لهذه المحاضرة');
    return s;
  };
  const isEnrolled = (courseId, studentId) =>
    db().enrollments.some((e) => e.courseId === courseId && e.studentId === studentId);
  const findRecord = (lectureId, studentId) =>
    db().attendance.find((a) => a.lectureId === lectureId && a.studentId === studentId);

  // ---------------- المحاضر ----------------
  function openSession(lectureId, actor = 'instructor') {
    getLecture(lectureId);
    const existing = db().sessions[lectureId];
    if (existing && !existing.closedAt) return { lectureId, openedAt: existing.openedAt, alreadyOpen: true };
    const session = { nonce: randomBytes(16).toString('hex'), openedAt: now(), closedAt: null, openedBy: actor };
    db().sessions[lectureId] = session;
    audit('session_opened', { lectureId, actor });
    return { lectureId, openedAt: session.openedAt, alreadyOpen: false };
  }

  function closeSession(lectureId, actor = 'instructor') {
    getLecture(lectureId);
    const s = getOpenSession(lectureId);
    s.closedAt = now();
    audit('session_closed', { lectureId, actor });
    return { lectureId, closedAt: s.closedAt };
  }

  /** التوكن الحالي للعرض على شاشة المحاضر فقط (المسار محمي بتسجيل دخول). */
  function getLiveToken(lectureId) {
    getLecture(lectureId);
    const s = getOpenSession(lectureId);
    const { token, expiresInMs } = currentToken(
      { secret: config.tokenSecret, lectureId, nonce: s.nonce, intervalSeconds: config.tokenIntervalSeconds },
      now()
    );
    return { lectureId, token, expiresInMs, intervalSeconds: config.tokenIntervalSeconds, serverTime: now() };
  }

  function getRoster(lectureId) {
    const lecture = getLecture(lectureId);
    return db()
      .enrollments.filter((e) => e.courseId === lecture.courseId)
      .map((e) => {
        const st = db().students.find((s) => s.id === e.studentId);
        const rec = findRecord(lectureId, e.studentId);
        return {
          studentId: st.id,
          universityId: st.universityId,
          fullName: st.fullName,
          status: rec ? rec.status : 'Absent',
          method: rec ? rec.method : null,
          notes: rec ? rec.notes : '',
          recordedAt: rec ? rec.recordedAt : null,
          distanceMeters: rec && rec.distanceMeters != null ? Math.round(rec.distanceMeters) : null,
        };
      });
  }

  function setStatus(lectureId, studentId, status, notes = '', actor = 'instructor') {
    const lecture = getLecture(lectureId);
    if (!STATUSES.includes(status)) throw new AppError(400, 'invalid_status', 'حالة غير صالحة');
    if (typeof notes !== 'string' || notes.length > 500) throw new AppError(400, 'invalid_notes', 'ملاحظات غير صالحة');
    const student = db().students.find((s) => s.id === studentId);
    if (!student) throw new AppError(404, 'student_not_found', 'الطالب غير موجود');
    if (!isEnrolled(lecture.courseId, studentId)) throw new AppError(403, 'not_enrolled', 'الطالب غير مسجل في المقرر');

    let rec = findRecord(lectureId, studentId);
    if (!rec) {
      rec = { id: store.nextId('attendance'), lectureId, studentId };
      db().attendance.push(rec);
    }
    Object.assign(rec, { status, notes, method: 'manual', recordedAt: new Date(now()).toISOString(), recordedBy: actor });
    audit('manual_status', { lectureId, studentId, status, actor });
    return { studentId, status };
  }

  function rotateSecret(studentId, actor = 'instructor') {
    const student = db().students.find((s) => s.id === studentId);
    if (!student) throw new AppError(404, 'student_not_found', 'الطالب غير موجود');
    const code = generateSecretCode();
    student.secretHash = hashSecret(code);
    failures.delete(student.universityId.toLowerCase());
    audit('secret_rotated', { studentId, actor });
    return { studentId, secretCode: code }; // يُعرض مرة واحدة فقط
  }

  function getReport(courseId) {
    const course = db().courses.find((c) => c.id === courseId);
    if (!course) throw new AppError(404, 'course_not_found', 'المقرر غير موجود');
    // نحسب فقط المحاضرات التي فُتحت لها جلسة حضور فعلاً
    const held = db().lectures.filter((l) => l.courseId === courseId && db().sessions[l.id]).map((l) => l.id);
    const total = held.length;
    const rows = db()
      .enrollments.filter((e) => e.courseId === courseId)
      .map((e) => {
        const st = db().students.find((s) => s.id === e.studentId);
        const c = { Present: 0, Late: 0, Excused: 0, Absent: 0 };
        for (const id of held) c[findRecord(id, st.id)?.status || 'Absent']++;
        const pct = total ? Math.round(((c.Present + c.Late) / total) * 1000) / 10 : 0;
        return {
          studentId: st.id, universityId: st.universityId, fullName: st.fullName,
          totalLectures: total, present: c.Present, late: c.Late, excused: c.Excused, absent: c.Absent,
          attendancePercentage: pct, // (حاضر + متأخر) / المحاضرات المنعقدة
        };
      });
    return { course, totalLectures: total, rows: rows.sort((a, b) => b.absent - a.absent) };
  }

  const listAudit = (limit = 100) => db().audit.slice(-Math.min(Math.max(limit, 1), 500)).reverse();

  // ---------------- الطالب ----------------
  function validateScan(input) {
    const i = input || {};
    const str = (v, min, max) => typeof v === 'string' && v.trim().length >= min && v.trim().length <= max;
    if (!str(i.universityId, 3, 32) || !str(i.secretCode, 4, 32) || !str(i.token, 8, 64) || !str(i.deviceId, 8, 128)
      || !Number.isInteger(i.lectureId) || i.lectureId <= 0) {
      throw new AppError(400, 'invalid_request', 'بيانات الطلب غير مكتملة أو غير صالحة');
    }
    return {
      universityId: i.universityId.trim(), secretCode: i.secretCode.trim().toUpperCase(),
      token: i.token.trim(), deviceId: i.deviceId.trim(), lectureId: i.lectureId, geo: i.geo,
    };
  }

  function registerFailure(key) {
    const f = failures.get(key) || { count: 0, lockedUntil: 0 };
    f.count += 1;
    if (f.count >= config.maxFailedAttempts) {
      f.lockedUntil = now() + config.lockoutMs;
      f.count = 0;
    }
    failures.set(key, f);
  }

  const GEO_MESSAGES = {
    missing_location: 'لم يصل موقعك. فعّل خدمة GPS وامنح الإذن ثم أعد المحاولة',
    invalid_location: 'موقع غير صالح',
    low_accuracy: 'دقة الـ GPS ضعيفة. انتظر لحظات حتى يستقر الموقع ثم أعد المحاولة',
    out_of_range: 'أنت خارج نطاق قاعة المحاضرة',
  };

  /**
   * مصادقة الطالب: الرقم الجامعي + الكود السري، مع قفل مؤقت بعد المحاولات الخاطئة.
   * تُستخدم لكل عملية يقوم بها الطالب (مسح، تقديم عذر...) كي لا يُنتحل أحد.
   */
  function authenticateStudent(universityId, secretCode, meta = {}, context = 'scan') {
    const key = universityId.toLowerCase();
    const t = now();

    const f = failures.get(key);
    if (f && f.lockedUntil > t) {
      audit(`${context}_locked`, { universityId, ip: meta.ip });
      throw new AppError(429, 'locked', 'تم إيقاف الحساب مؤقتاً بسبب محاولات خاطئة. حاول لاحقاً أو راجع المحاضر');
    }

    const student = db().students.find((s) => s.universityId.toLowerCase() === key);
    const ok = verifySecret(secretCode, student ? student.secretHash : DUMMY_HASH); // نفس الزمن مع/بدون وجود الطالب
    if (!student || !ok) {
      registerFailure(key);
      audit(`${context}_bad_credentials`, { universityId, ip: meta.ip });
      throw new AppError(401, 'invalid_credentials', 'الرقم الجامعي أو الكود السري غير صحيح');
    }
    failures.delete(key);
    return student;
  }

  /** تسجيل حضور طالب: كل التحققات تتم هنا على الخادم فقط. */
  function scan(input, meta = {}) {
    const v = validateScan(input);
    const t = now();

    // 1+2) الهوية والقفل
    const student = authenticateStudent(v.universityId, v.secretCode, meta, 'scan');

    // 3) المحاضرة والجلسة والتسجيل في المقرر
    const lecture = getLecture(v.lectureId);
    const session = getOpenSession(v.lectureId);
    if (!isEnrolled(lecture.courseId, student.id)) {
      audit('scan_not_enrolled', { lectureId: v.lectureId, studentId: student.id, ip: meta.ip });
      throw new AppError(403, 'not_enrolled', 'أنت غير مسجل في هذا المقرر');
    }

    // 4) منع التكرار وحماية قرارات المحاضر اليدوية
    const existing = findRecord(v.lectureId, student.id);
    if (existing && existing.method === 'manual') {
      throw new AppError(409, 'locked_by_instructor', 'تم تحديد حالتك يدوياً من المحاضر ولا يمكن تغييرها بالمسح');
    }
    if (existing && (existing.status === 'Present' || existing.status === 'Late')) {
      return { alreadyRecorded: true, status: existing.status, studentName: student.fullName, studentId: student.id };
    }
    // سجل "غائب" مستورد/تلقائي لا يمنع التسجيل: سيُحدَّث أدناه بدل إنشاء سجل مكرر

    // 5) التوكن الزمني المتغير
    const tok = verifyToken(
      { secret: config.tokenSecret, lectureId: v.lectureId, nonce: session.nonce, token: v.token,
        intervalSeconds: config.tokenIntervalSeconds, tolerance: config.tokenToleranceWindows }, t);
    if (!tok.valid) {
      audit('scan_bad_token', { lectureId: v.lectureId, studentId: student.id, ip: meta.ip });
      throw new AppError(401, 'invalid_token', 'الرمز غير صالح أو منتهي. امسح الشاشة مباشرة');
    }

    // 6) الموقع الجغرافي (إلزامي)
    const geo = checkGeofence(v.geo, lecture.hall, { maxAccuracyMeters: config.maxGpsAccuracyMeters });
    if (!geo.ok) {
      audit('scan_geofence_failed', {
        lectureId: v.lectureId, studentId: student.id, reason: geo.reason,
        distance: geo.distance != null ? Math.round(geo.distance) : undefined, ip: meta.ip,
      });
      // لا نكشف المسافة الدقيقة كي لا تُستخدم لتحديد موقع القاعة
      throw new AppError(403, geo.reason, GEO_MESSAGES[geo.reason]);
    }

    // 7) ربط الجهاز: جهاز واحد لا يحضّر أكثر من طالب في المحاضرة نفسها
    const deviceHash = hashDevice(v.deviceId);
    const clash = db().attendance.find(
      (a) => a.lectureId === v.lectureId && a.deviceHash === deviceHash && a.studentId !== student.id);
    if (clash) {
      audit('scan_device_reuse', { lectureId: v.lectureId, studentId: student.id, otherStudentId: clash.studentId, ip: meta.ip });
      throw new AppError(409, 'device_already_used', 'تم استخدام هذا الجهاز لتسجيل طالب آخر في هذه المحاضرة');
    }

    // 8) التسجيل (متأخر إذا تجاوز المهلة)
    const late = t - session.openedAt > config.lateAfterMinutes * 60_000;
    const rec = existing || { id: store.nextId('attendance'), lectureId: v.lectureId, studentId: student.id };
    Object.assign(rec, {
      status: late ? 'Late' : 'Present', method: 'scan', notes: '',
      recordedAt: new Date(t).toISOString(), distanceMeters: geo.distance, deviceHash,
    });
    if (!existing) db().attendance.push(rec);
    audit('scan_success', { lectureId: v.lectureId, studentId: student.id, status: rec.status, ip: meta.ip });
    return { alreadyRecorded: false, status: rec.status, studentName: student.fullName, studentId: student.id };
  }

  return {
    openSession, closeSession, getLiveToken, getRoster, setStatus, rotateSecret, getReport, listAudit, scan,
    // دوال داخلية تستخدمها خدمات الأعذار والإرشاد (لا تُعرَض عبر HTTP مباشرة)
    internals: { audit, authenticateStudent, getLecture, isEnrolled, findRecord },
  };
}
