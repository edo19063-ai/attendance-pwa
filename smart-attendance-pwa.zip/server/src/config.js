/** الأصول التي يستخدمها تطبيق الجوال المغلَّف بـ Capacitor عند استدعاء الـ API. */
export const NATIVE_APP_ORIGINS = ['https://localhost', 'capacitor://localhost'];

const num = (v, d) => {
  if (v === undefined || v === '') return d;
  const n = Number(v);
  return Number.isFinite(n) && n > 0 ? n : d;
};

/** يقرأ الإعدادات ويرفض التشغيل إذا كانت الأسرار ضعيفة أو مفقودة. */
export function loadConfig(env = process.env) {
  const errors = [];
  const need = (key, min) => {
    const v = env[key];
    if (!v || v.length < min) errors.push(`${key} مطلوب (${min} محرفاً على الأقل)`);
    return v;
  };
  const tokenSecret = need('TOKEN_SECRET', 32);
  const sessionSecret = need('SESSION_SECRET', 32);
  const adminPassword = need('ADMIN_PASSWORD', 10);
  if (errors.length) throw new Error('إعدادات غير صالحة:\n - ' + errors.join('\n - '));

  return Object.freeze({
    port: num(env.PORT, 4000),
    dataFile: env.DATA_FILE || './data/db.json',
    tokenSecret,
    sessionSecret,
    adminPassword,
    tokenIntervalSeconds: num(env.TOKEN_INTERVAL_SECONDS, 5),
    tokenToleranceWindows: 1, // النافذة الحالية + السابقة
    maxGpsAccuracyMeters: num(env.MAX_GPS_ACCURACY_METERS, 50),
    lateAfterMinutes: num(env.LATE_AFTER_MINUTES, 15),
    // طلاب القاعة غالباً خلف IP عام واحد (NAT)، لذا الحد لكل IP مرتفع. الحماية الفعلية لكل رقم جامعي + القفل.
    scanRatePerIpPerMinute: num(env.SCAN_RATE_PER_IP, 300),
    maxFailedAttempts: num(env.MAX_FAILED_ATTEMPTS, 5),
    lockoutMs: num(env.LOCKOUT_MINUTES, 15) * 60_000,
    instructorSessionMs: 8 * 3600_000,
    allowedOrigins: [
      ...(env.ALLOWED_ORIGINS || '').split(',').map((s) => s.trim()).filter(Boolean),
      // أصول تطبيق الجوال (Capacitor): أندرويد https://localhost وآيفون capacitor://localhost
      ...(env.ALLOW_NATIVE_APP === '1' ? NATIVE_APP_ORIGINS : []),
    ],
    trustProxy: env.TRUST_PROXY === '1',
    webDist: env.WEB_DIST || '../web/dist', // مجلد الواجهة المبنية (npm run build)
    cspEnabled: env.DISABLE_CSP !== '1', // للتشخيص فقط
  });
}
