import fs from 'node:fs';
import path from 'node:path';
import express from 'express';
import { securityHeaders, cors, notFound, errorHandler } from './http/middleware.js';
import { buildRouter } from './http/routes.js';
import { serveStatic } from './http/static.js';

export function createApp({ config, service }) {
  const app = express();
  app.disable('x-powered-by');
  if (config.trustProxy) app.set('trust proxy', 1);

  app.use(securityHeaders(config));
  app.use(cors(config.allowedOrigins));
  app.use(express.json({ limit: '10kb' }));

  app.get('/api/health', (_req, res) => res.json({ ok: true }));
  app.use('/api', buildRouter({ config, service }));

  // الواجهة المبنية من نفس الخادم: رابط واحد، بلا CORS، وHTTPS واحد
  const webDist = config.webDist && path.resolve(config.webDist);
  const serveWeb = Boolean(webDist) && fs.existsSync(path.join(webDist, 'index.html'));
  if (serveWeb) app.use(serveStatic(webDist));

  app.use(notFound);
  app.use(errorHandler);
  return app;
}
