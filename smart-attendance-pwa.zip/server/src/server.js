import { loadConfig } from './config.js';
import { Store } from './store/store.js';
import fs from 'node:fs';
import { createSeed } from './store/seed.js';
import { createSeedFromFrontend } from './store/import.js';
import { createServices } from './services/index.js';
import { createApp } from './app.js';

const config = loadConfig();
const store = new Store(config.dataFile);

let seededCodes = null;
const firstRun = store.load(() => {
  // إن وُجد ملف بيانات الواجهة (npm run export-seed في الواجهة) نستورده كي تتطابق المعرّفات
  const seedFile = process.env.SEED_FILE || './data/seed-input.json';
  const seed = fs.existsSync(seedFile)
    ? createSeedFromFrontend(JSON.parse(fs.readFileSync(seedFile, 'utf8')))
    : createSeed();
  console.log(fs.existsSync(seedFile) ? `[seed] استيراد من ${seedFile}` : '[seed] بيانات تجريبية افتراضية');
  seededCodes = seed.codes;
  return seed.db;
});

if (firstRun) {
  console.log('\n=== أول تشغيل: الأكواد السرية للطلاب (تظهر الآن مرة واحدة فقط، سلّمها لكل طالب) ===');
  for (const [uid, code] of Object.entries(seededCodes)) console.log(`  ${uid}  ->  ${code}`);
  console.log('=====================================================================================\n');
}

const service = createServices({ store, config });
const app = createApp({ config, service });

app.listen(config.port, () => {
  console.log(`Attendance server listening on :${config.port}`);
  console.log(
    fs.existsSync(`${config.webDist}/index.html`)
      ? `[web] تُخدم الواجهة من ${config.webDist}`
      : `[web] لا توجد واجهة مبنية في ${config.webDist} (شغّل npm run build في web/ أو اضبط WEB_DIST)`
  );
});
