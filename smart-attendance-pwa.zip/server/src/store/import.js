import { randomBytes } from 'node:crypto';
import { hashSecret, generateSecretCode } from '../lib/crypto.js';

const DEFAULT_HALL = { name: 'القاعة A1', lat: 32.123456, lng: 20.123456, radius: 30 };

const toIso = (s) => {
  const d = new Date(String(s ?? '').replace(' ', 'T'));
  return Number.isNaN(d.getTime()) ? null : d.toISOString();
};

/**
 * يبني قاعدة بيانات الخادم من بيانات الواجهة (INITIAL_*) حتى تتطابق المعرّفات.
 * الأكواد السرية القديمة (الموجودة في كود الواجهة) تُتجاهل، وتُولَّد أكواد جديدة عشوائية.
 * السجلات التاريخية تُستورد بـ method='import' وتُنشأ لها جلسات مغلقة لتظهر في التقارير.
 */
export function createSeedFromFrontend(input) {
  const need = (k) => {
    if (!Array.isArray(input?.[k])) throw new Error(`ملف البيانات ناقص: الحقل ${k} مطلوب`);
    return input[k];
  };
  const srcStudents = need('students');
  const srcCourses = need('courses');
  const srcEnrollments = need('enrollments');
  const srcLectures = need('lectures');
  const srcAttendance = Array.isArray(input.attendance) ? input.attendance : [];

  const codes = {};
  const seenUni = new Set();
  const students = srcStudents.map((s) => {
    const uid = String(s.university_id);
    if (seenUni.has(uid.toLowerCase())) throw new Error(`رقم جامعي مكرر: ${uid}`);
    seenUni.add(uid.toLowerCase());
    const code = generateSecretCode();
    codes[uid] = code;
    return { id: s.student_id, universityId: uid, fullName: s.full_name, secretHash: hashSecret(code) };
  });
  const studentIds = new Set(students.map((s) => s.id));

  const courses = srcCourses.map((c) => ({ id: c.course_id, code: c.course_code, name: c.course_name }));
  const courseIds = new Set(courses.map((c) => c.id));

  const enrollments = srcEnrollments
    .filter((e) => studentIds.has(e.student_id) && courseIds.has(e.course_id))
    .map((e) => ({ courseId: e.course_id, studentId: e.student_id }));

  const lectures = srcLectures
    .filter((l) => courseIds.has(l.course_id))
    .map((l) => ({
      id: l.lecture_id,
      courseId: l.course_id,
      topic: l.topic || '',
      date: l.lecture_date,
      time: l.lecture_time,
      hall: {
        name: l.hall_name ?? DEFAULT_HALL.name,
        lat: l.hall_lat ?? DEFAULT_HALL.lat,
        lng: l.hall_lng ?? DEFAULT_HALL.lng,
        radius: l.allowed_radius_meters ?? DEFAULT_HALL.radius,
      },
    }));
  const lectureIds = new Set(lectures.map((l) => l.id));

  const seen = new Set();
  const attendance = [];
  for (const a of srcAttendance) {
    const key = `${a.lecture_id}:${a.student_id}`;
    if (!studentIds.has(a.student_id) || !lectureIds.has(a.lecture_id) || seen.has(key)) continue;
    if (!['Present', 'Absent', 'Late', 'Excused'].includes(a.status)) continue;
    seen.add(key);
    attendance.push({
      id: a.attendance_id, lectureId: a.lecture_id, studentId: a.student_id, status: a.status,
      notes: String(a.notes ?? '').slice(0, 500), method: 'import',
      recordedAt: toIso(a.recorded_at) || new Date(0).toISOString(),
    });
  }

  // نقاط التفاعل والتقييمات التاريخية
  const participations = [];
  for (const p of Array.isArray(input.participations) ? input.participations : []) {
    if (!studentIds.has(p.student_id) || !courseIds.has(p.course_id)) continue;
    const points = Number.isInteger(p.points_added) && p.points_added > 0 && p.points_added <= 100 ? p.points_added : 1;
    participations.push({
      id: participations.length + 1, studentId: p.student_id, courseId: p.course_id, lectureId: null, points,
      reason: String(p.reason ?? '').slice(0, 200), createdAt: toIso(p.timestamp) || new Date(0).toISOString(), actor: 'import',
    });
  }
  const ratedKeys = new Set();
  const feedbacks = [];
  for (const f of Array.isArray(input.feedbacks) ? input.feedbacks : []) {
    const key = `${f.lecture_id}:${f.student_id}`;
    if (!studentIds.has(f.student_id) || !lectureIds.has(f.lecture_id) || ratedKeys.has(key)) continue;
    if (!Number.isInteger(f.understanding_score) || f.understanding_score < 1 || f.understanding_score > 10) continue;
    ratedKeys.add(key);
    feedbacks.push({
      id: feedbacks.length + 1, lectureId: f.lecture_id, studentId: f.student_id, score: f.understanding_score,
      createdAt: toIso(f.timestamp) || new Date(0).toISOString(),
    });
  }

  // جلسة مغلقة لكل محاضرة لها سجلات تاريخية (تُحتسب ضمن "المحاضرات المنعقدة")
  const sessions = {};
  for (const lectureId of new Set(attendance.map((a) => a.lectureId))) {
    const opened = Date.parse(attendance.find((a) => a.lectureId === lectureId).recordedAt) || 0;
    sessions[lectureId] = { nonce: randomBytes(16).toString('hex'), openedAt: opened, closedAt: opened + 2 * 3600_000, openedBy: 'import' };
  }

  const max = (arr) => arr.reduce((m, x) => Math.max(m, x.id), 0);
  const db = {
    counters: { students: max(students), attendance: max(attendance), audit: 0 },
    students, courses, enrollments, lectures, sessions, attendance, participations, feedbacks, audit: [],
  };
  return { db, codes };
}
