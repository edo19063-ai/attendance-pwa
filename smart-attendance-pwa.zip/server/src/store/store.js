import fs from 'node:fs';
import path from 'node:path';

/**
 * تخزين بسيط في ملف JSON مع كتابة ذرّية (ملف مؤقت ثم rename).
 * مناسب لقاعة/كلية واحدة. للإنتاج الكبير استبدله بـ PostgreSQL/MySQL بنفس الواجهة.
 */
export class Store {
  constructor(file = null) {
    this.file = file;
    this.db = null;
  }

  /** يحمّل الملف إن وُجد وإلا يستدعي seedFn. يرجع true إذا تم التهيئة لأول مرة. */
  load(seedFn) {
    if (this.file && fs.existsSync(this.file)) {
      this.db = JSON.parse(fs.readFileSync(this.file, 'utf8'));
      this.normalize(); // ترحيل قواعد بيانات أُنشئت بإصدارات أقدم
      return false;
    }
    this.db = seedFn();
    this.normalize();
    this.save();
    return true;
  }

  /** يضمن وجود الجداول والعدّادات الجديدة (الأعذار والتنبيهات) دون المساس بالبيانات الحالية. */
  normalize() {
    const d = this.db;
    d.counters ??= {};
    for (const table of ['excuses', 'alerts', 'participations', 'feedbacks', 'delegations']) {
      d[table] ??= [];
      d.counters[table] ??= d[table].reduce((m, x) => Math.max(m, x.id), 0);
    }
  }

  save() {
    if (!this.file) return;
    fs.mkdirSync(path.dirname(this.file), { recursive: true });
    const tmp = `${this.file}.tmp`;
    fs.writeFileSync(tmp, JSON.stringify(this.db), { mode: 0o600 });
    fs.renameSync(tmp, this.file);
  }

  nextId(table) {
    this.db.counters[table] = (this.db.counters[table] || 0) + 1;
    return this.db.counters[table];
  }
}
