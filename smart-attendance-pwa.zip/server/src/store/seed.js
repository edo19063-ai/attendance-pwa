import { hashSecret, generateSecretCode } from '../lib/crypto.js';

const NAMES = ['أحمد المصراطي', 'فاطمة الفيتوري', 'محمد الورفلي', 'مريم الزناتي', 'خالد بن عمر'];

/**
 * بيانات تجريبية. الأكواد السرية تُولَّد عشوائياً وتُطبع مرة واحدة فقط عند أول تشغيل،
 * وتُخزَّن مجزّأة (hash) فلا يمكن استرجاعها لاحقاً.
 */
export function createSeed() {
  const codes = {};
  const students = NAMES.map((fullName, i) => {
    const universityId = String(20230001 + i);
    const code = generateSecretCode();
    codes[universityId] = code;
    return { id: i + 1, universityId, fullName, secretHash: hashSecret(code) };
  });

  const lectures = [1, 2, 3, 4, 5].map((id) => ({
    id,
    courseId: 1,
    topic: `المحاضرة ${id}`,
    hall: { name: 'القاعة A1', lat: 32.123456, lng: 20.123456, radius: 30 },
  }));

  const db = {
    counters: { students: students.length, attendance: 0, audit: 0 },
    students,
    courses: [{ id: 1, code: 'CS301', name: 'نظم قواعد البيانات' }],
    enrollments: students.map((s) => ({ courseId: 1, studentId: s.id })),
    lectures,
    sessions: {}, // lectureId -> { nonce, openedAt, closedAt, openedBy }
    attendance: [],
    audit: [],
  };
  return { db, codes };
}
