import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { setupFull } from './helpers.js';
import { Store } from '../src/store/store.js';

const fails = (fn, code) => assert.throws(fn, (e) => e.code === code, `expected ${code}`);

test('excuse needs valid credentials and shares the lockout with scanning', () => {
  const { service, creds } = setupFull();
  fails(() => service.submitExcuse({ ...creds(1), secretCode: 'WRONG123', lectureId: 5, reasonText: 'مرض شديد' }), 'invalid_credentials');
  for (let i = 0; i < 4; i++) fails(() => service.submitExcuse({ ...creds(1), secretCode: 'WRONG123', lectureId: 5, reasonText: 'مرض شديد' }), 'invalid_credentials');
  fails(() => service.submitExcuse({ ...creds(1), lectureId: 5, reasonText: 'مرض شديد' }), 'locked');
});

test('submit → pending; duplicate pending rejected; mine shows only own', () => {
  const { service, creds } = setupFull();
  const e = service.submitExcuse({ ...creds(1), lectureId: 5, reasonText: 'مراجعة المستشفى' });
  assert.equal(e.status, 'pending');
  assert.equal(e.studentName.length > 0, true);
  fails(() => service.submitExcuse({ ...creds(1), lectureId: 5, reasonText: 'مرة ثانية للمحاضرة نفسها' }), 'duplicate_pending');
  service.submitExcuse({ ...creds(2), lectureId: 5, reasonText: 'ظرف عائلي طارئ' });
  assert.equal(service.listMine(creds(1)).length, 1);
  assert.equal(service.listMine(creds(2)).length, 1);
  fails(() => service.listMine({ ...creds(1), secretCode: 'WRONG123' }), 'invalid_credentials');
});

test('document URL: only http(s); junk and javascript: rejected', () => {
  const { service, creds } = setupFull();
  for (const bad of ['javascript:alert(1)', 'data:text/html,<script>1</script>', 'ftp://x.org/a', 'not a url', 'https://a.com/with space', 'x'.repeat(600)]) {
    fails(() => service.submitExcuse({ ...creds(1), lectureId: 5, reasonText: 'سبب كافٍ للعذر', documentUrl: bad }), 'invalid_document_url');
  }
  const ok = service.submitExcuse({ ...creds(1), lectureId: 5, reasonText: 'سبب كافٍ للعذر', documentUrl: 'https://uni.edu/report.pdf' });
  assert.equal(ok.documentUrl, 'https://uni.edu/report.pdf');
});

test('reason length and request validation', () => {
  const { service, creds } = setupFull();
  fails(() => service.submitExcuse({ ...creds(1), lectureId: 5, reasonText: 'قصير' }), 'invalid_reason');
  fails(() => service.submitExcuse({ ...creds(1), lectureId: 5, reasonText: 'ن'.repeat(1001) }), 'invalid_reason');
  fails(() => service.submitExcuse({ ...creds(1), lectureId: '5', reasonText: 'سبب كافٍ للعذر' }), 'invalid_request');
  fails(() => service.submitExcuse(null), 'invalid_request');
  fails(() => service.submitExcuse({ ...creds(1), lectureId: 99, reasonText: 'سبب كافٍ للعذر' }), 'lecture_not_found');
});

test('not enrolled student cannot submit', () => {
  const { service, creds, store } = setupFull();
  store.db.enrollments = store.db.enrollments.filter((e) => e.studentId !== 1);
  fails(() => service.submitExcuse({ ...creds(1), lectureId: 5, reasonText: 'سبب كافٍ للعذر' }), 'not_enrolled');
});

test('a student already marked present cannot submit an excuse', () => {
  const { service, creds, scanFor } = setupFull();
  service.openSession(5);
  service.scan(scanFor(1));
  fails(() => service.submitExcuse({ ...creds(1), lectureId: 5, reasonText: 'سبب كافٍ للعذر' }), 'already_present');
});

test('accept → attendance becomes Excused (manual, locked); second review rejected', () => {
  const { service, creds, scanFor } = setupFull();
  const e = service.submitExcuse({ ...creds(1), lectureId: 5, reasonText: 'تقرير طبي معتمد' });
  const r = service.reviewExcuse(e.id, 'accept', 'موافق');
  assert.equal(r.status, 'accepted');
  assert.equal(r.reviewNotes, 'موافق');
  const row = service.getRoster(5).find((x) => x.studentId === 1);
  assert.equal(row.status, 'Excused');
  assert.equal(row.method, 'manual');
  fails(() => service.reviewExcuse(e.id, 'reject'), 'already_reviewed');
  fails(() => service.submitExcuse({ ...creds(1), lectureId: 5, reasonText: 'عذر جديد للمحاضرة نفسها' }), 'already_excused');
  service.openSession(5);
  fails(() => service.scan(scanFor(1)), 'locked_by_instructor'); // قرار المحاضر لا يُلغى بالمسح
});

test('reject keeps attendance untouched and allows a new excuse later', () => {
  const { service, creds } = setupFull();
  const e = service.submitExcuse({ ...creds(1), lectureId: 5, reasonText: 'سبب غير مقنع' });
  assert.equal(service.reviewExcuse(e.id, 'reject').reviewNotes, 'تم رفض العذر');
  assert.equal(service.getRoster(5).find((x) => x.studentId === 1).status, 'Absent');
  assert.equal(service.submitExcuse({ ...creds(1), lectureId: 5, reasonText: 'سبب جديد مع مستند' }).status, 'pending');
});

test('accept is atomic: if attendance update fails the excuse stays pending', () => {
  const { service, creds, store } = setupFull();
  const e = service.submitExcuse({ ...creds(1), lectureId: 5, reasonText: 'تقرير طبي معتمد' });
  store.db.enrollments = store.db.enrollments.filter((x) => x.studentId !== 1);
  fails(() => service.reviewExcuse(e.id, 'accept'), 'not_enrolled');
  assert.equal(service.listExcuses({ status: 'pending' }).length, 1);
});

test('instructor list/filter/validation', () => {
  const { service, creds } = setupFull();
  const a = service.submitExcuse({ ...creds(1), lectureId: 5, reasonText: 'تقرير طبي معتمد' });
  service.submitExcuse({ ...creds(2), lectureId: 5, reasonText: 'ظرف عائلي طارئ' });
  service.reviewExcuse(a.id, 'reject');
  assert.equal(service.listExcuses().length, 2);
  assert.equal(service.listExcuses({ status: 'pending' }).length, 1);
  assert.equal(service.listExcuses({ status: 'rejected' }).length, 1);
  assert.equal(service.listExcuses({ lectureId: 4 }).length, 0);
  fails(() => service.listExcuses({ status: 'weird' }), 'invalid_status');
  fails(() => service.reviewExcuse(a.id, 'maybe'), 'invalid_action');
  fails(() => service.reviewExcuse(999, 'accept'), 'excuse_not_found');
});

test('excuse views never expose secrets; audit has no reason text', () => {
  const { service, creds, codes } = setupFull();
  service.submitExcuse({ ...creds(1), lectureId: 5, reasonText: 'تفاصيل طبية حساسة جداً' });
  const dump = JSON.stringify([service.listExcuses(), service.listMine(creds(1)), service.listAudit(50)]);
  assert.ok(!dump.includes('secretHash') && !dump.includes(codes['20230001']));
  assert.ok(!JSON.stringify(service.listAudit(50)).includes('تفاصيل طبية'));
});

test('legacy database file (no excuses/alerts tables) is migrated on load', () => {
  const file = path.join(fs.mkdtempSync(path.join(os.tmpdir(), 'db-')), 'db.json');
  fs.writeFileSync(file, JSON.stringify({ counters: { students: 1, attendance: 0, audit: 0 }, students: [], courses: [], enrollments: [], lectures: [], sessions: {}, attendance: [], audit: [] }));
  const store = new Store(file);
  assert.equal(store.load(() => { throw new Error('should not seed'); }), false);
  assert.deepEqual(store.db.excuses, []);
  assert.deepEqual(store.db.alerts, []);
  assert.equal(store.nextId('excuses'), 1);
  assert.equal(store.nextId('alerts'), 1);
});
