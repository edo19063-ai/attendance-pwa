import test from 'node:test';
import assert from 'node:assert/strict';
import { makeToken, currentToken, verifyToken } from '../src/lib/token.js';
import { checkGeofence, haversineMeters } from '../src/lib/geo.js';
import { hashSecret, verifySecret, signSession, verifySession } from '../src/lib/crypto.js';
import { loadConfig } from '../src/config.js';

const base = { secret: 'x'.repeat(40), lectureId: 5, nonce: 'abc', intervalSeconds: 5 };

test('token: valid now, valid previous window, expired after two windows', () => {
  const t0 = 1_000_000_000_000;
  const { token } = currentToken(base, t0);
  assert.equal(verifyToken({ ...base, token }, t0).valid, true);
  assert.equal(verifyToken({ ...base, token }, t0 + 5_000).valid, true);
  assert.equal(verifyToken({ ...base, token }, t0 + 10_000).valid, false);
});

test('token: bound to lecture, nonce and secret', () => {
  const t0 = 1_000_000_000_000;
  const { token } = currentToken(base, t0);
  assert.equal(verifyToken({ ...base, lectureId: 6, token }, t0).valid, false);
  assert.equal(verifyToken({ ...base, nonce: 'zzz', token }, t0).valid, false);
  assert.equal(verifyToken({ ...base, secret: 'y'.repeat(40), token }, t0).valid, false);
  assert.equal(verifyToken({ ...base, token: 'not-a-token' }, t0).valid, false);
  assert.equal(verifyToken({ ...base, token: undefined }, t0).valid, false);
});

test('token: deterministic and 16 hex chars', () => {
  const a = makeToken({ ...base, window: 7 });
  assert.match(a, /^[0-9a-f]{16}$/);
  assert.equal(a, makeToken({ ...base, window: 7 }));
});

test('geo: haversine sanity (~111 km per degree latitude)', () => {
  assert.ok(Math.abs(haversineMeters(0, 0, 1, 0) - 111195) < 200);
});

test('geo: accepts inside, rejects outside / missing / inaccurate / null island', () => {
  const hall = { lat: 32.123456, lng: 20.123456, radius: 30 };
  const o = { maxAccuracyMeters: 50 };
  assert.equal(checkGeofence({ lat: hall.lat + 0.00007, lng: hall.lng, accuracy: 5 }, hall, o).ok, true);
  assert.equal(checkGeofence({ lat: hall.lat + 0.004, lng: hall.lng, accuracy: 5 }, hall, o).reason, 'out_of_range');
  assert.equal(checkGeofence(undefined, hall, o).reason, 'missing_location');
  assert.equal(checkGeofence({ lat: hall.lat, lng: hall.lng }, hall, o).reason, 'missing_location');
  assert.equal(checkGeofence({ lat: '32.1', lng: 20.1, accuracy: 5 }, hall, o).reason, 'missing_location');
  assert.equal(checkGeofence({ lat: hall.lat, lng: hall.lng, accuracy: 500 }, hall, o).reason, 'low_accuracy');
  assert.equal(checkGeofence({ lat: 0, lng: 0, accuracy: 5 }, hall, o).reason, 'invalid_location');
});

test('crypto: scrypt hash verifies only the right secret', () => {
  const h = hashSecret('ABCD2345');
  assert.equal(verifySecret('ABCD2345', h), true);
  assert.equal(verifySecret('ABCD2346', h), false);
  assert.equal(verifySecret('x', 'garbage'), false);
});

test('crypto: signed session rejects tamper and expiry', () => {
  const s = 'k'.repeat(40);
  const tok = signSession({ role: 'instructor', exp: 2000 }, s);
  assert.equal(verifySession(tok, s, 1000).role, 'instructor');
  assert.equal(verifySession(tok, s, 3000), null);
  assert.equal(verifySession(tok, 'z'.repeat(40), 1000), null);
  const [body, sig] = tok.split('.');
  const forged = Buffer.from(JSON.stringify({ role: 'instructor', exp: 9e15 })).toString('base64url');
  assert.equal(verifySession(`${forged}.${sig}`, s, 1000), null);
  assert.equal(verifySession('a.b.c', s, 1000), null);
});

test('config: refuses weak or missing secrets', () => {
  assert.throws(() => loadConfig({}), /TOKEN_SECRET/);
  assert.throws(() => loadConfig({ TOKEN_SECRET: 'short', SESSION_SECRET: 'x'.repeat(40), ADMIN_PASSWORD: 'x'.repeat(12) }));
});
