import test from 'node:test';
import assert from 'node:assert/strict';
import { setupFull } from './helpers.js';
import { signSession } from '../src/lib/crypto.js';
import { ENV } from './helpers.js';

const fails = (fn, code) => assert.throws(fn, (e) => e.code === code, `expected ${code}`);

test('participation: points accumulate per course and appear in the lecture map', () => {
  const { service } = setupFull();
  assert.equal(service.addParticipation(5, 1, 'إجابة ممتازة').points, 1);
  assert.equal(service.addParticipation(5, 1).points, 2);
  service.addParticipation(5, 2);
  const m = service.pointsForLecture(5);
  assert.equal(m.get(1), 2);
  assert.equal(m.get(2), 1);
  assert.equal(m.get(3), undefined);
  assert.equal(service.participationPoints(5, 1), 2);
});

test('participation: validation, enrollment and per-lecture cap', () => {
  const { service, store } = setupFull();
  fails(() => service.addParticipation(99, 1), 'lecture_not_found');
  fails(() => service.addParticipation(5, 999), 'student_not_found');
  fails(() => service.addParticipation(5, '1'), 'invalid_request');
  fails(() => service.addParticipation(5, 1, 'x'.repeat(201)), 'invalid_reason');
  for (let i = 0; i < 10; i++) service.addParticipation(5, 1);
  fails(() => service.addParticipation(5, 1), 'too_many_points');
  store.db.enrollments = store.db.enrollments.filter((e) => e.studentId !== 2);
  fails(() => service.addParticipation(5, 2), 'not_enrolled');
});

test('feedback: attended student rates once; token is bound to student+lecture', () => {
  const { service, scanFor } = setupFull();
  service.openSession(5);
  const { studentId } = service.scan(scanFor(1));
  const token = service.issueFeedbackToken(studentId, 5);
  assert.deepEqual(service.submitFeedback({ feedbackToken: token, score: 9 }), { ok: true });
  fails(() => service.submitFeedback({ feedbackToken: token, score: 7 }), 'already_rated');
  assert.deepEqual(service.feedbackStats(5), { average: 9, count: 1, breakdown: { 9: 1 } });
});

test('feedback: invalid scores, forged / expired / wrong-purpose tokens, non-attendees', () => {
  const { service, scanFor, clock } = setupFull();
  service.openSession(5);
  const { studentId } = service.scan(scanFor(1));
  const token = service.issueFeedbackToken(studentId, 5);
  for (const bad of [0, 11, 5.5, '7', null, undefined]) fails(() => service.submitFeedback({ feedbackToken: token, score: bad }), 'invalid_score');
  fails(() => service.submitFeedback({ feedbackToken: 'garbage', score: 5 }), 'invalid_feedback_token');
  fails(() => service.submitFeedback(null), 'invalid_feedback_token');
  const other = signSession({ purpose: 'instructor', studentId, lectureId: 5, exp: clock.t + 60_000 }, ENV.SESSION_SECRET);
  fails(() => service.submitFeedback({ feedbackToken: other, score: 5 }), 'invalid_feedback_token');
  const forged = signSession({ purpose: 'feedback', studentId, lectureId: 5, exp: clock.t + 60_000 }, 'z'.repeat(40));
  fails(() => service.submitFeedback({ feedbackToken: forged, score: 5 }), 'invalid_feedback_token');
  // طالب لم يحضر لا يستطيع التقييم حتى لو حصل على رمز
  fails(() => service.submitFeedback({ feedbackToken: service.issueFeedbackToken(2, 5), score: 5 }), 'not_attended');
  clock.t += 31 * 60_000;
  fails(() => service.submitFeedback({ feedbackToken: token, score: 5 }), 'invalid_feedback_token');
});

test('feedback stats: average, breakdown, anonymous', () => {
  const { service, scanFor } = setupFull();
  service.openSession(5);
  const scores = [10, 8, 8];
  scores.forEach((score, i) => {
    const { studentId } = service.scan(scanFor(i + 1));
    service.submitFeedback({ feedbackToken: service.issueFeedbackToken(studentId, 5), score });
  });
  const stats = service.feedbackStats(5);
  assert.equal(stats.count, 3);
  assert.equal(stats.average, 8.7);
  assert.deepEqual(stats.breakdown, { 8: 2, 10: 1 });
  assert.ok(!JSON.stringify(stats).includes('studentId'));
  assert.deepEqual(service.feedbackStats(4), { average: 0, count: 0, breakdown: {} });
  fails(() => service.feedbackStats(99), 'lecture_not_found');
});
