import test from 'node:test';
import assert from 'node:assert/strict';
import { setupFull } from './helpers.js';

const fails = (fn, code) => assert.throws(fn, (e) => e.code === code, `expected ${code}`);
const MIN = 60_000;

test('create returns a one-time code; listing never exposes it or its hash', () => {
  const { service } = setupFull();
  const { delegation, accessCode } = service.createDelegation({ assistantName: 'م. ريم', lectureId: 5, durationMinutes: 60 });
  assert.match(accessCode, /^\d+-[A-Z2-9]{10}$/);
  assert.equal(delegation.status, 'active');
  assert.equal(delegation.lectureId, 5);
  const dump = JSON.stringify([service.listDelegations(), service.listAudit(50)]);
  assert.ok(!dump.includes(accessCode.split('-')[1]) && !dump.includes('codeHash') && !dump.includes('s1$'));
});

test('create validates name, lecture and duration', () => {
  const { service } = setupFull();
  fails(() => service.createDelegation({ assistantName: 'ا', lectureId: 5 }), 'invalid_name');
  fails(() => service.createDelegation({ assistantName: 'x'.repeat(61), lectureId: 5 }), 'invalid_name');
  fails(() => service.createDelegation({ assistantName: 'معيد\u0007', lectureId: 5 }), 'invalid_name');
  fails(() => service.createDelegation({ assistantName: 'معيد', lectureId: '5' }), 'invalid_request');
  fails(() => service.createDelegation({ assistantName: 'معيد', lectureId: 99 }), 'lecture_not_found');
  fails(() => service.createDelegation({ assistantName: 'معيد', lectureId: 5, durationMinutes: 5 }), 'invalid_duration');
  fails(() => service.createDelegation({ assistantName: 'معيد', lectureId: 5, durationMinutes: 241 }), 'invalid_duration');
  fails(() => service.createDelegation({ assistantName: 'معيد', lectureId: 5, durationMinutes: 30.5 }), 'invalid_duration');
});

test('login: right code works; wrong/unknown/malformed rejected with generic errors', () => {
  const { service } = setupFull();
  const { accessCode, delegation } = service.createDelegation({ assistantName: 'م. ريم', lectureId: 5 });
  const grant = service.assistantLogin(accessCode);
  assert.equal(grant.lectureId, 5);
  assert.equal(grant.assistantName, 'م. ريم');
  assert.equal(grant.delegationId, delegation.id);
  fails(() => service.assistantLogin(`${delegation.id}-AAAAAAAAAA`), 'invalid_access_code');
  fails(() => service.assistantLogin('999-AAAAAAAAAA'), 'invalid_access_code'); // نفس خطأ الكود الخاطئ
  for (const bad of ['', 'abc', '5', '5-SHORT', null, undefined, 123, '5-AAAAAAAAAA-extra']) fails(() => service.assistantLogin(bad), 'invalid_request');
  assert.equal(service.assistantLogin(accessCode.toLowerCase()).lectureId, 5); // غير حساس لحالة الأحرف
});

test('login lockout after 5 wrong codes, then recovers after the lock window', () => {
  const { service, clock } = setupFull();
  const { accessCode, delegation } = service.createDelegation({ assistantName: 'م. ريم', lectureId: 5 });
  for (let i = 0; i < 5; i++) fails(() => service.assistantLogin(`${delegation.id}-AAAAAAAAAA`), 'invalid_access_code');
  fails(() => service.assistantLogin(accessCode), 'locked'); // حتى الكود الصحيح مرفوض أثناء القفل
  clock.t += 16 * MIN;
  assert.equal(service.assistantLogin(accessCode).lectureId, 5);
});

test('expiry and revocation end the delegation immediately', () => {
  const { service, clock } = setupFull();
  const a = service.createDelegation({ assistantName: 'معيد أ', lectureId: 5, durationMinutes: 30 });
  const b = service.createDelegation({ assistantName: 'معيد ب', lectureId: 5, durationMinutes: 60 });
  assert.equal(service.checkDelegation(a.delegation.id).lectureId, 5);

  service.revokeDelegation(b.delegation.id);
  fails(() => service.checkDelegation(b.delegation.id), 'delegation_ended');
  fails(() => service.assistantLogin(b.accessCode), 'delegation_ended');
  fails(() => service.revokeDelegation(b.delegation.id), 'not_active');

  clock.t += 31 * MIN;
  fails(() => service.checkDelegation(a.delegation.id), 'delegation_ended');
  fails(() => service.assistantLogin(a.accessCode), 'delegation_ended');
  fails(() => service.revokeDelegation(a.delegation.id), 'not_active');
  assert.deepEqual(service.listDelegations().map((d) => d.status).sort(), ['expired', 'revoked']);
  fails(() => service.checkDelegation(999), 'delegation_ended');
  fails(() => service.revokeDelegation(999), 'delegation_not_found');
});

test('active delegation cap', () => {
  const { service } = setupFull();
  for (let i = 0; i < 20; i++) service.createDelegation({ assistantName: `معيد ${i}`, lectureId: 5 });
  fails(() => service.createDelegation({ assistantName: 'معيد زائد', lectureId: 5 }), 'too_many_delegations');
});

test('assistant log shows delegation lifecycle and the assistant\'s own actions only', () => {
  const { service } = setupFull();
  const { accessCode, delegation } = service.createDelegation({ assistantName: 'م. ريم', lectureId: 5 });
  service.assistantLogin(accessCode, { ip: '10.0.0.7' });
  const actor = 'assistant:م. ريم';
  service.openSession(5, actor);
  service.setStatus(5, 1, 'Present', 'تحضير المعيد', actor);
  service.addParticipation(5, 1, 'مشاركة', actor);
  service.setStatus(5, 2, 'Absent', '', 'instructor'); // فعل المحاضر لا يظهر
  service.setStatus(4, 3, 'Present', '', actor);        // محاضرة أخرى لا تظهر
  service.revokeDelegation(delegation.id);

  const log = service.assistantLog(5);
  const actions = log.map((l) => l.action_performed).join(' | ');
  assert.match(actions, /منح تفويض مؤقت/);
  assert.match(actions, /دخول المعيد/);
  assert.match(actions, /فتح جلسة الحضور/);
  assert.match(actions, /حاضر/);
  assert.match(actions, /نقطة تفاعل/);
  assert.match(actions, /سحب تفويض/);
  assert.ok(!actions.includes('غائب'));
  assert.equal(log.length, 6);
  assert.ok(log.every((l) => l.lecture_id === 5 && l.status === 'نجاح'));
  assert.ok(log.some((l) => l.ip_address === '10.0.0.7'));
  assert.equal(log[0].action_performed.includes('سحب'), true); // الأحدث أولاً
  fails(() => service.assistantLog(99), 'lecture_not_found');
});
