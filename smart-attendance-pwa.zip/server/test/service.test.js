import test from 'node:test';
import assert from 'node:assert/strict';
import { setup } from './helpers.js';

const fails = (fn, code) => assert.throws(fn, (e) => e.code === code, `expected ${code}`);

test('scan fails while session is closed, works after open', () => {
  const { service, codes } = setup();
  const req = { lectureId: 5, universityId: '20230001', secretCode: codes['20230001'], token: 'a'.repeat(16),
    deviceId: 'device-1-abcdefgh', geo: { lat: 32.1235, lng: 20.1235, accuracy: 5 } };
  fails(() => service.scan(req), 'session_closed');
});

test('happy path: Present, then idempotent second scan', () => {
  const { service, scanFor } = setup();
  service.openSession(5);
  const r1 = service.scan(scanFor(1));
  assert.equal(r1.status, 'Present');
  assert.equal(r1.alreadyRecorded, false);
  const r2 = service.scan(scanFor(1));
  assert.equal(r2.alreadyRecorded, true);
  assert.equal(service.getRoster(5).filter((r) => r.status === 'Present').length, 1);
});

test('wrong secret code rejected; unknown id gives same error', () => {
  const { service, scanFor } = setup();
  service.openSession(5);
  fails(() => service.scan(scanFor(1, { secretCode: 'WRONG123' })), 'invalid_credentials');
  fails(() => service.scan(scanFor(1, { universityId: '99999999' })), 'invalid_credentials');
});

test('a friend cannot check in for someone using the shared token alone', () => {
  const { service, scanFor } = setup();
  service.openSession(5);
  // الصديق يعرف التوكن والرقم الجامعي لكن ليس الكود السري
  fails(() => service.scan(scanFor(2, { secretCode: 'GUESS234' })), 'invalid_credentials');
});

test('lockout after repeated bad codes, even with the right code afterwards', () => {
  const { service, scanFor } = setup();
  service.openSession(5);
  for (let i = 0; i < 5; i++) fails(() => service.scan(scanFor(1, { secretCode: 'WRONG123' })), 'invalid_credentials');
  fails(() => service.scan(scanFor(1)), 'locked');
});

test('lockout expires and rotating the code clears it', () => {
  const { service, scanFor, clock } = setup();
  service.openSession(5);
  for (let i = 0; i < 5; i++) fails(() => service.scan(scanFor(1, { secretCode: 'WRONG123' })), 'invalid_credentials');
  clock.t += 16 * 60_000;
  // الجلسة ما زالت مفتوحة لكن التوكن يُولَّد بالوقت الجديد
  assert.equal(service.scan(scanFor(1)).status, 'Late'); // مضى أكثر من 15 دقيقة على فتح الجلسة
});

test('expired / forged / foreign token rejected', () => {
  const { service, scanFor, clock } = setup();
  service.openSession(5);
  const stale = scanFor(1);
  clock.t += 11_000;
  fails(() => service.scan(stale), 'invalid_token');
  fails(() => service.scan(scanFor(1, { token: 'deadbeefdeadbeef' })), 'invalid_token');
});

test('token from a previous session of the same lecture is rejected (nonce)', () => {
  const { service, scanFor } = setup();
  service.openSession(5);
  const old = scanFor(1).token;
  service.closeSession(5);
  service.openSession(5);
  fails(() => service.scan(scanFor(1, { token: old })), 'invalid_token');
});

test('geofence is mandatory: missing, outside, inaccurate all rejected', () => {
  const { service, scanFor, store } = setup();
  service.openSession(5);
  const h = store.db.lectures[0].hall;
  fails(() => service.scan(scanFor(1, { geo: undefined })), 'missing_location');
  fails(() => service.scan(scanFor(1, { geo: { lat: h.lat + 0.004, lng: h.lng, accuracy: 5 } })), 'out_of_range');
  fails(() => service.scan(scanFor(1, { geo: { lat: h.lat, lng: h.lng, accuracy: 300 } })), 'low_accuracy');
  assert.equal(service.getRoster(5).filter((r) => r.status !== 'Absent').length, 0);
});

test('one device cannot check in two different students', () => {
  const { service, scanFor } = setup();
  service.openSession(5);
  service.scan(scanFor(1, { deviceId: 'shared-device-xyz' }));
  fails(() => service.scan(scanFor(2, { deviceId: 'shared-device-xyz' })), 'device_already_used');
});

test('late status after the grace period', () => {
  const { service, scanFor, clock } = setup();
  service.openSession(5);
  clock.t += 20 * 60_000;
  assert.equal(service.scan(scanFor(1)).status, 'Late');
});

test('non-enrolled student rejected', () => {
  const { service, scanFor, store } = setup();
  service.openSession(5);
  store.db.enrollments = store.db.enrollments.filter((e) => e.studentId !== 1);
  fails(() => service.scan(scanFor(1)), 'not_enrolled');
});

test('manual decision by instructor cannot be overridden by scanning', () => {
  const { service, scanFor } = setup();
  service.openSession(5);
  service.setStatus(5, 1, 'Excused', 'عذر طبي');
  fails(() => service.scan(scanFor(1)), 'locked_by_instructor');
  assert.equal(service.getRoster(5)[0].status, 'Excused');
});

test('input validation', () => {
  const { service } = setup();
  service.openSession(5);
  fails(() => service.scan(null), 'invalid_request');
  fails(() => service.scan({ lectureId: '5', universityId: 'x', secretCode: 'y', token: 'z', deviceId: 'd' }), 'invalid_request');
  fails(() => service.setStatus(5, 1, 'Flying'), 'invalid_status');
  fails(() => service.setStatus(5, 999, 'Present'), 'student_not_found');
  fails(() => service.setStatus(99, 1, 'Present'), 'lecture_not_found');
});

test('live token requires an open session', () => {
  const { service } = setup();
  fails(() => service.getLiveToken(5), 'session_closed');
  service.openSession(5);
  const t = service.getLiveToken(5);
  assert.match(t.token, /^[0-9a-f]{16}$/);
  assert.ok(t.expiresInMs > 0 && t.expiresInMs <= 5000);
  service.closeSession(5);
  fails(() => service.getLiveToken(5), 'session_closed');
});

test('rotateSecret invalidates the old code and returns a new one once', () => {
  const { service, scanFor, codes } = setup();
  service.openSession(5);
  const { secretCode } = service.rotateSecret(1);
  assert.notEqual(secretCode, codes['20230001']);
  fails(() => service.scan(scanFor(1)), 'invalid_credentials');
  assert.equal(service.scan(scanFor(1, { secretCode })).status, 'Present');
});

test('report counts only held lectures; late counts as attended', () => {
  const { service, scanFor, clock } = setup();
  service.openSession(5);
  service.scan(scanFor(1));
  service.scan(scanFor(2, { deviceId: 'device-b-abcdefgh' }));
  const rep = service.getReport(1);
  assert.equal(rep.totalLectures, 1);
  const s1 = rep.rows.find((r) => r.studentId === 1);
  assert.equal(s1.present, 1);
  assert.equal(s1.attendancePercentage, 100);
  assert.equal(rep.rows.find((r) => r.studentId === 3).absent, 1);
  clock.t += 20 * 60_000;
  service.scan(scanFor(3, { deviceId: 'device-c-abcdefgh' }));
  assert.equal(service.getReport(1).rows.find((r) => r.studentId === 3).attendancePercentage, 100);
});

test('audit log records failures and never contains secrets', () => {
  const { service, scanFor, codes } = setup();
  service.openSession(5);
  try { service.scan(scanFor(1, { secretCode: 'WRONG123' })); } catch {}
  service.scan(scanFor(1));
  const log = JSON.stringify(service.listAudit(50));
  assert.ok(log.includes('scan_bad_credentials') && log.includes('scan_success'));
  assert.ok(!log.includes('WRONG123') && !log.includes(codes['20230001']) && !log.includes('secretHash'));
});
