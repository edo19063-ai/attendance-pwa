import test from 'node:test';
import assert from 'node:assert/strict';
import { createSeedFromFrontend } from '../src/store/import.js';
import { Store } from '../src/store/store.js';
import { createAttendanceService } from '../src/services/attendance.js';
import { loadConfig } from '../src/config.js';
import { ENV } from './helpers.js';

const input = {
  students: [
    { student_id: 7, full_name: 'سارة', university_id: '2023007', secret_code: 'OLDLEAK' },
    { student_id: 9, full_name: 'ياسر', university_id: '2023009' },
  ],
  courses: [{ course_id: 3, course_name: 'شبكات', course_code: 'NW1' }],
  enrollments: [{ student_id: 7, course_id: 3 }, { student_id: 9, course_id: 3 }, { student_id: 99, course_id: 3 }],
  lectures: [
    { lecture_id: 11, course_id: 3, lecture_date: '2024-10-06', lecture_time: '09:00:00', topic: 'أ', hall_lat: 31.5, hall_lng: 20.5, allowed_radius_meters: 25 },
    { lecture_id: 12, course_id: 3, lecture_date: '2024-10-13', lecture_time: '09:00:00', topic: 'ب' },
  ],
  attendance: [
    { attendance_id: 4, lecture_id: 11, student_id: 7, status: 'Present', notes: '', recorded_at: '2024-10-06 09:05:10' },
    { attendance_id: 5, lecture_id: 11, student_id: 9, status: 'Absent', notes: 'x', recorded_at: '2024-10-06 09:20:00' },
    { attendance_id: 6, lecture_id: 11, student_id: 9, status: 'Present', recorded_at: '2024-10-06 09:21:00' }, // مكرر
    { attendance_id: 7, lecture_id: 11, student_id: 555, status: 'Present', recorded_at: '2024-10-06 09:21:00' }, // طالب مجهول
  ],
};

test('import keeps frontend ids, drops old codes, filters bad rows', () => {
  const { db, codes } = createSeedFromFrontend(input);
  assert.deepEqual(db.students.map((s) => s.id), [7, 9]);
  assert.ok(codes['2023007'] && codes['2023007'] !== 'OLDLEAK');
  assert.equal(db.enrollments.length, 2);
  assert.equal(db.lectures[0].hall.radius, 25);
  assert.equal(db.lectures[1].hall.lat, 32.123456); // افتراضي
  assert.equal(db.attendance.length, 2);
  assert.ok(db.sessions[11].closedAt && !db.sessions[12]);
  assert.equal(db.counters.attendance, 5);
  assert.ok(!JSON.stringify(db).includes('OLDLEAK'));
});

test('import rejects incomplete files and duplicate university ids', () => {
  assert.throws(() => createSeedFromFrontend({}), /students/);
  assert.throws(() => createSeedFromFrontend({ ...input, students: [input.students[0], { ...input.students[0], student_id: 8 }] }), /مكرر/);
});

test('imported "Absent" record does not block a real scan, and is updated in place', () => {
  const config = loadConfig(ENV);
  const store = new Store(null);
  let codes;
  store.load(() => { const s = createSeedFromFrontend(input); codes = s.codes; return s.db; });
  let t = Date.UTC(2026, 10, 15, 10, 0, 0);
  const service = createAttendanceService({ store, config, now: () => t });
  service.openSession(11); // يعيد فتح محاضرة كانت مغلقة باستيراد
  const { token } = service.getLiveToken(11);
  const res = service.scan({ lectureId: 11, universityId: '2023009', secretCode: codes['2023009'], token,
    deviceId: 'device-xyz-12345', geo: { lat: 31.5 + 0.00005, lng: 20.5, accuracy: 6 } });
  assert.equal(res.alreadyRecorded, false);
  assert.equal(store.db.attendance.filter((a) => a.studentId === 9 && a.lectureId === 11).length, 1);
  assert.equal(service.getRoster(11).find((r) => r.studentId === 9).method, 'scan');
});
