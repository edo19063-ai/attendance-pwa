import test from 'node:test';
import assert from 'node:assert/strict';
import { setup } from './helpers.js';

let express = null;
try { express = await import('express'); } catch { /* غير مثبت */ }

test('HTTP end-to-end (يتطلب npm install)', { skip: !express && 'express غير مثبت' }, async (t) => {
  const { createApp } = await import('../src/app.js');
  const { config, service, scanFor } = setup();
  const server = createApp({ config, service }).listen(0);
  t.after(() => server.close());
  const base = `http://127.0.0.1:${server.address().port}/api`;
  const call = async (method, path, body, token) => {
    const res = await fetch(base + path, {
      method,
      headers: { 'Content-Type': 'application/json', ...(token ? { Authorization: `Bearer ${token}` } : {}) },
      body: body ? JSON.stringify(body) : undefined,
    });
    return { status: res.status, json: await res.json() };
  };

  // مسارات المحاضر مغلقة بلا تسجيل دخول
  assert.equal((await call('GET', '/lectures/5/token')).status, 401);
  assert.equal((await call('POST', '/auth/login', { password: 'wrong' })).status, 401);

  const login = await call('POST', '/auth/login', { password: 'admin-password-123' });
  assert.equal(login.status, 200);
  const jwt = login.json.token;

  assert.equal((await call('POST', '/lectures/5/session/open', null, jwt)).status, 200);
  const tok = await call('GET', '/lectures/5/token', null, jwt);
  assert.match(tok.json.token, /^[0-9a-f]{16}$/);

  // الطالب: بدون موقع = مرفوض، مع موقع صحيح = مقبول
  const good = scanFor(1);
  const noGeo = await call('POST', '/attendance/scan', { ...good, geo: undefined });
  assert.equal(noGeo.status, 403);
  const ok = await call('POST', '/attendance/scan', good);
  assert.equal(ok.status, 200);
  assert.equal(ok.json.status, 'Present');

  assert.equal((await call('GET', '/lectures/abc/token', null, jwt)).status, 400);
  assert.equal((await call('GET', '/nope')).status, 404);
  const roster = await call('GET', '/lectures/5/roster', null, jwt);
  assert.equal(roster.json.roster.filter((r) => r.status === 'Present').length, 1);
  assert.ok(!JSON.stringify(roster.json).includes('secretHash'));
});
