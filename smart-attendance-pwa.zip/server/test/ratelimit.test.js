import test from 'node:test';
import assert from 'node:assert/strict';
import { EventEmitter } from 'node:events';
import { rateLimit } from '../src/http/middleware.js';

const call = (mw, req = { ip: '1.1.1.1' }, status = 200) => {
  const res = new EventEmitter();
  res.statusCode = status;
  res.headers = {};
  res.set = (k, v) => { res.headers[k] = v; return res; };
  res.status = (c) => { res.statusCode = c; return res; };
  res.json = (b) => { res.body = b; return res; };
  let passed = false;
  mw(req, res, () => { passed = true; });
  if (passed) res.emit('finish'); // الطلب اكتمل بالحالة المحددة
  return { passed, res };
};

test('plain limiter blocks after max and sets Retry-After', () => {
  const mw = rateLimit({ windowMs: 60_000, max: 3 });
  for (let i = 0; i < 3; i++) assert.equal(call(mw).passed, true);
  const r = call(mw);
  assert.equal(r.passed, false);
  assert.equal(r.res.statusCode, 429);
  assert.ok(Number(r.res.headers['Retry-After']) > 0);
});

test('limiter is per key (different IPs are independent)', () => {
  const mw = rateLimit({ windowMs: 60_000, max: 1 });
  assert.equal(call(mw, { ip: 'a' }).passed, true);
  assert.equal(call(mw, { ip: 'a' }).passed, false);
  assert.equal(call(mw, { ip: 'b' }).passed, true);
});

test('failuresOnly: successes never consume the budget, failures do', () => {
  const mw = rateLimit({ windowMs: 60_000, max: 3, failuresOnly: true });
  for (let i = 0; i < 20; i++) assert.equal(call(mw, { ip: 'x' }, 200).passed, true); // 20 نجاحاً لا تحجب
  for (let i = 0; i < 3; i++) assert.equal(call(mw, { ip: 'x' }, 401).passed, true); // 3 إخفاقات مسموحة
  assert.equal(call(mw, { ip: 'x' }, 200).passed, false); // الرابعة محجوبة
});
