import test from 'node:test';
import assert from 'node:assert/strict';
import { setupFull } from './helpers.js';

const fails = (fn, code) => assert.throws(fn, (e) => e.code === code, `expected ${code}`);

// محاضرات 1..3 منعقدة. الطالب 1 حضر الأولى فقط، والطالب 2 حضر الكل، والبقية لم يحضروا.
function withHistory() {
  const ctx = setupFull();
  const { service } = ctx;
  for (const lec of [1, 2, 3]) { service.openSession(lec); service.closeSession(lec); }
  service.setStatus(1, 1, 'Present');
  for (const lec of [1, 2, 3]) service.setStatus(lec, 2, 'Present');
  return ctx;
}

test('at-risk lists students over the threshold, worst first', () => {
  const { service } = withHistory();
  const rows = service.atRisk({ minAbsences: 2, minPct: 20 });
  assert.deepEqual(rows.map((r) => r.studentId).sort(), [1, 3, 4, 5]);
  assert.equal(rows[0].absent, 3);
  assert.equal(rows.find((r) => r.studentId === 1).absent, 2);
  assert.equal(rows.find((r) => r.studentId === 1).absentPercentage, 66.7);
  assert.ok(!rows.some((r) => r.studentId === 2));
  assert.equal(rows[0].courseCode, 'CS301');
});

test('at-risk validates parameters', () => {
  const { service } = withHistory();
  fails(() => service.atRisk({ minAbsences: 1000 }), 'invalid_param');
  fails(() => service.atRisk({ minAbsences: 'x' }), 'invalid_param');
  fails(() => service.atRisk({ minAbsences: 2, minPct: -1 }), 'invalid_param');
  assert.equal(service.atRisk({ minAbsences: 3, minPct: 100 }).length, 3); // 3,4,5 فقط
});

test('auto-generate creates one alert per at-risk student and is idempotent', () => {
  const { service } = withHistory();
  service.createAlert({ studentId: 3, absenceCount: 3, advisorName: 'د. سالم' }); // موجود مسبقاً
  assert.equal(service.autoGenerate().created, 3); // 1 و4 و5
  assert.equal(service.autoGenerate().created, 0);
  assert.equal(service.listAlerts().length, 4);
  assert.match(service.listAlerts().find((a) => a.studentId === 1).notes, /غياب 2 محاضرات/);
});

test('create / update / delete alert with validation', () => {
  const { service } = withHistory();
  const a = service.createAlert({ studentId: 1, absenceCount: 2 });
  assert.equal(a.status, 'قيد المتابعة');
  assert.match(a.advisorName, /عبد السلام/);
  assert.ok(a.studentName && a.universityId);
  fails(() => service.createAlert({ studentId: 999, absenceCount: 2 }), 'student_not_found');
  fails(() => service.createAlert({ studentId: 1, absenceCount: -1 }), 'invalid_param');
  fails(() => service.createAlert({ studentId: 1, absenceCount: 2, notes: 'x'.repeat(501) }), 'invalid_param');

  const u = service.updateAlert(a.id, { status: 'تم التدخل', notes: 'تم الاتصال بالطالب' });
  assert.equal(u.status, 'تم التدخل');
  assert.match(u.notes, /تنبيه مبكر.*\| تم الاتصال بالطالب/);
  fails(() => service.updateAlert(a.id, { status: 'غير معروف' }), 'invalid_status');
  fails(() => service.updateAlert(999, { status: 'مغلق' }), 'alert_not_found');

  service.deleteAlert(a.id);
  assert.equal(service.listAlerts().length, 0);
  fails(() => service.deleteAlert(a.id), 'alert_not_found');
});
