import test from 'node:test';
import assert from 'node:assert/strict';
import http from 'node:http';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { serveStatic } from '../src/http/static.js';
import { securityHeaders } from '../src/http/middleware.js';

function makeDist() {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'dist-'));
  fs.mkdirSync(path.join(dir, 'assets'));
  fs.mkdirSync(path.join(dir, 'icons'));
  fs.writeFileSync(path.join(dir, 'index.html'), '<!doctype html><title>APP</title>');
  fs.writeFileSync(path.join(dir, 'sw.js'), '// sw');
  fs.writeFileSync(path.join(dir, 'manifest.webmanifest'), '{}');
  fs.writeFileSync(path.join(dir, 'assets', 'app-abc123.js'), 'console.log(1)');
  fs.writeFileSync(path.join(dir, 'icons', 'icon-192.png'), 'PNG');
  // ملف سري خارج المجلد للتأكد أنه لا يُقدَّم
  fs.writeFileSync(path.join(dir, '..', 'secret-outside.txt'), 'TOP-SECRET');
  return dir;
}

async function withServer(dir, fn) {
  const handler = serveStatic(dir);
  const server = http.createServer((req, res) => {
    req.path = new URL(req.url, 'http://x').pathname; // Express يوفّر هذه الخاصية
    res.set = (o) => { for (const [k, v] of Object.entries(o)) res.setHeader(k, v); return res; };
    res.sendStatus = (c) => { res.statusCode = c; res.end(); return res; };
    handler(req, res, () => { res.statusCode = 404; res.end('NEXT'); });
  });
  await new Promise((r) => server.listen(0, '127.0.0.1', r));
  const base = `http://127.0.0.1:${server.address().port}`;
  try { await fn(base); } finally { server.close(); }
}

// fetch يطبّع المسارات؛ نستخدم http الخام لإرسال المسار كما هو
const raw = (base, rawPath, method = 'GET') =>
  new Promise((resolve, reject) => {
    const u = new URL(base);
    const req = http.request({ host: u.hostname, port: u.port, path: rawPath, method }, (res) => {
      let body = '';
      res.on('data', (c) => (body += c));
      res.on('end', () => resolve({ status: res.statusCode, headers: res.headers, body }));
    });
    req.on('error', reject);
    req.end();
  });

test('serves index at / and SPA fallback for extensionless app routes', async () => {
  const dir = makeDist();
  await withServer(dir, async (base) => {
    for (const p of ['/', '/reports', '/anything/deep']) {
      const r = await raw(base, p);
      assert.equal(r.status, 200, p);
      assert.match(r.body, /APP/);
      assert.match(r.headers['content-type'], /text\/html/);
      assert.equal(r.headers['cache-control'], 'no-cache'); // لا تخزين لـ index.html
    }
  });
});

test('hashed assets are immutable-cached; sw and manifest are never cached long', async () => {
  const dir = makeDist();
  await withServer(dir, async (base) => {
    const a = await raw(base, '/assets/app-abc123.js');
    assert.equal(a.status, 200);
    assert.match(a.headers['content-type'], /javascript/);
    assert.match(a.headers['cache-control'], /immutable/);
    assert.equal((await raw(base, '/sw.js')).headers['cache-control'], 'no-cache');
    const m = await raw(base, '/manifest.webmanifest');
    assert.match(m.headers['content-type'], /manifest\+json/);
    assert.equal(m.headers['cache-control'], 'no-cache');
    assert.equal((await raw(base, '/icons/icon-192.png')).headers['content-type'], 'image/png');
  });
});

test('missing file with an extension is a real 404 (not index.html)', async () => {
  const dir = makeDist();
  await withServer(dir, async (base) => {
    const r = await raw(base, '/assets/missing.js');
    assert.equal(r.status, 404);
    assert.equal(r.body, 'NEXT');
  });
});

test('never touches /api paths', async () => {
  const dir = makeDist();
  await withServer(dir, async (base) => {
    for (const p of ['/api', '/api/health', '/api/unknown']) {
      const r = await raw(base, p);
      assert.equal(r.body, 'NEXT', p);
    }
  });
});

test('path traversal attempts never leak files outside the dist folder', async () => {
  const dir = makeDist();
  await withServer(dir, async (base) => {
    const attempts = [
      '/../secret-outside.txt',
      '/%2e%2e/secret-outside.txt',
      '/..%2fsecret-outside.txt',
      '/assets/../../secret-outside.txt',
      '/%2e%2e%2f%2e%2e%2fetc/passwd',
      '/..%5csecret-outside.txt',
      '/%00',
      '/%',
    ];
    for (const p of attempts) {
      const r = await raw(base, p);
      assert.ok(!r.body.includes('TOP-SECRET'), `leaked via ${p}`);
      assert.ok(!r.body.includes('root:'), `leaked via ${p}`);
    }
    assert.equal((await raw(base, '/%00')).status, 400);
    assert.equal((await raw(base, '/%')).status, 400);
  });
});

test('HEAD returns headers without a body; POST is ignored', async () => {
  const dir = makeDist();
  await withServer(dir, async (base) => {
    const h = await raw(base, '/', 'HEAD');
    assert.equal(h.status, 200);
    assert.equal(h.body, '');
    assert.ok(Number(h.headers['content-length']) > 0);
    assert.equal((await raw(base, '/', 'POST')).body, 'NEXT');
  });
});

test('security headers: CSP, permissions, HSTS only on secure proxied requests', () => {
  const run = (config, req) => {
    const headers = {};
    securityHeaders(config)(req, { set: (o) => Object.assign(headers, o) }, () => {});
    return headers;
  };
  const h = run({ cspEnabled: true, trustProxy: false }, { secure: true });
  assert.match(h['Content-Security-Policy'], /default-src 'self'/);
  assert.match(h['Content-Security-Policy'], /frame-ancestors 'none'/);
  assert.doesNotMatch(h['Content-Security-Policy'], /script-src[^;]*unsafe/);
  assert.match(h['Permissions-Policy'], /camera=\(self\)/);
  assert.match(h['Permissions-Policy'], /geolocation=\(self\)/);
  assert.equal(h['Strict-Transport-Security'], undefined); // لا proxy موثوق
  assert.ok(run({ trustProxy: true }, { secure: true })['Strict-Transport-Security']);
  assert.equal(run({ trustProxy: true }, { secure: false })['Strict-Transport-Security'], undefined);
  assert.equal(run({ cspEnabled: false }, {})['Content-Security-Policy'], undefined);
});
