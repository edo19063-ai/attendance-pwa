import test from 'node:test';
import assert from 'node:assert/strict';
import { requireRole } from '../src/http/middleware.js';
import { signSession } from '../src/lib/crypto.js';
import { loadConfig } from '../src/config.js';
import { ENV, setupFull } from './helpers.js';

const config = loadConfig(ENV);
const bearer = (payload, secret = config.sessionSecret) => ({ authorization: `Bearer ${signSession(payload, secret)}` });
const run = (mw, req) => {
  let result;
  mw({ params: {}, ...req }, {}, (err) => { result = err || 'ok'; });
  return result;
};
const code = (r) => (r === 'ok' ? 'ok' : r.code);

test('requireRole: no/forged/expired tokens are 401', () => {
  const { service } = setupFull();
  const mw = requireRole(config, service);
  const exp = Date.now() + 60_000;
  assert.equal(code(run(mw, { headers: {} })), 'unauthorized');
  assert.equal(code(run(mw, { headers: bearer({ role: 'instructor', exp }, 'z'.repeat(40)) })), 'unauthorized');
  assert.equal(code(run(mw, { headers: bearer({ role: 'instructor', exp: Date.now() - 1 }) })), 'unauthorized');
  assert.equal(code(run(mw, { headers: bearer({ role: 'superuser', exp }) })), 'unauthorized');
  assert.equal(code(run(mw, { headers: bearer({ role: 'instructor', exp }) })), 'ok');
});

test('requireRole: assistants are 403 on instructor-only routes (not logged out)', () => {
  const { service } = setupFull();
  const { delegation } = service.createDelegation({ assistantName: 'م. ريم', lectureId: 5 });
  const headers = bearer({ role: 'assistant', delegationId: delegation.id, exp: Date.now() + 60_000 });
  const r = run(requireRole(config, service), { headers });
  assert.equal(r.code, 'forbidden');
  assert.equal(r.status, 403);
});

test('requireRole: assistant allowed only for their own lecture, with actor set', () => {
  const { service } = setupFull();
  const { delegation } = service.createDelegation({ assistantName: 'م. ريم', lectureId: 5 });
  const headers = bearer({ role: 'assistant', delegationId: delegation.id, exp: Date.now() + 60_000 });
  const mw = requireRole(config, service, { allowAssistant: true, lectureParam: 'id' });

  const req = { headers, params: { id: '5' } };
  assert.equal(code(run(mw, req)), 'ok');
  let seen;
  mw(req, {}, () => { seen = req; });
  assert.equal(seen.actor, 'assistant:م. ريم');
  assert.equal(seen.role, 'assistant');

  const wrong = run(mw, { headers, params: { id: '4' } });
  assert.equal(wrong.code, 'out_of_scope');
  assert.equal(wrong.status, 403);
});

test('requireRole: a revoked or expired delegation is cut off on the very next request', () => {
  const { service, clock } = setupFull();
  const a = service.createDelegation({ assistantName: 'معيد أ', lectureId: 5, durationMinutes: 30 });
  const b = service.createDelegation({ assistantName: 'معيد ب', lectureId: 5, durationMinutes: 120 });
  const mw = requireRole(config, service, { allowAssistant: true, lectureParam: 'id' });
  const mk = (d) => ({ headers: bearer({ role: 'assistant', delegationId: d.id, exp: Date.now() + 3600_000 }), params: { id: '5' } });

  assert.equal(code(run(mw, mk(a.delegation))), 'ok');
  service.revokeDelegation(a.delegation.id);
  const r = run(mw, mk(a.delegation));
  assert.equal(r.code, 'delegation_ended');
  assert.equal(r.status, 401); // 401 ⇒ الواجهة تُخرج المعيد تلقائياً

  assert.equal(code(run(mw, mk(b.delegation))), 'ok');
  clock.t += 121 * 60_000;
  assert.equal(run(mw, mk(b.delegation)).code, 'delegation_ended');
});

test('instructor passes everywhere, including lecture-scoped routes', () => {
  const { service } = setupFull();
  const headers = bearer({ role: 'instructor', exp: Date.now() + 60_000 });
  const mw = requireRole(config, service, { allowAssistant: true, lectureParam: 'id' });
  assert.equal(code(run(mw, { headers, params: { id: '3' } })), 'ok');
});
