import test from 'node:test';
import assert from 'node:assert/strict';
import { cors } from '../src/http/middleware.js';
import { loadConfig, NATIVE_APP_ORIGINS } from '../src/config.js';
import { ENV } from './helpers.js';

const run = (allowed, req) => {
  const headers = {};
  let status = null;
  let passed = false;
  cors(allowed)(req, { set: (o) => Object.assign(headers, o), sendStatus: (c) => { status = c; } }, () => { passed = true; });
  return { headers, status, passed };
};

test('CORS allows DELETE (needed by alert deletion from a cross-origin client)', () => {
  const r = run(['https://localhost'], { method: 'OPTIONS', headers: { origin: 'https://localhost' } });
  assert.match(r.headers['Access-Control-Allow-Methods'], /DELETE/);
  assert.equal(r.headers['Access-Control-Allow-Origin'], 'https://localhost');
  assert.equal(r.headers['Access-Control-Max-Age'], '600');
  assert.equal(r.status, 204); // preflight ينتهي هنا
});

test('CORS: unknown origins get no headers; same-origin requests pass through', () => {
  const evil = run(['https://localhost'], { method: 'GET', headers: { origin: 'https://evil.example' } });
  assert.equal(evil.headers['Access-Control-Allow-Origin'], undefined);
  const same = run([], { method: 'GET', headers: {} });
  assert.equal(same.passed, true);
});

test('ALLOW_NATIVE_APP=1 adds the Capacitor origins; default does not', () => {
  assert.deepEqual(loadConfig(ENV).allowedOrigins, []);
  const on = loadConfig({ ...ENV, ALLOW_NATIVE_APP: '1', ALLOWED_ORIGINS: 'https://a.example' });
  assert.deepEqual(on.allowedOrigins, ['https://a.example', ...NATIVE_APP_ORIGINS]);
  assert.deepEqual(NATIVE_APP_ORIGINS, ['https://localhost', 'capacitor://localhost']);
});
