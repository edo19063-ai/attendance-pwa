import { loadConfig } from '../src/config.js';
import { Store } from '../src/store/store.js';
import { createSeed } from '../src/store/seed.js';
import { createAttendanceService } from '../src/services/attendance.js';
import { createServices } from '../src/services/index.js';

export const ENV = {
  TOKEN_SECRET: 't'.repeat(40), SESSION_SECRET: 's'.repeat(40), ADMIN_PASSWORD: 'admin-password-123',
};

export function setup(overrides = {}) {
  const config = loadConfig({ ...ENV, ...overrides });
  const store = new Store(null);
  let codes;
  store.load(() => { const s = createSeed(); codes = s.codes; return s.db; });
  const clock = { t: Date.UTC(2026, 10, 15, 10, 0, 0) };
  const service = createAttendanceService({ store, config, now: () => clock.t });
  const hall = store.db.lectures[0].hall;
  const inside = { lat: hall.lat + 0.00007, lng: hall.lng + 0.00006, accuracy: 8 };
  // يبني طلب مسح صالحاً للطالب رقم n (1..5) ثم يسمح بتعديل الحقول
  const scanFor = (n, extra = {}) => {
    const uid = String(20230000 + n);
    const { token } = service.getLiveToken(5);
    return { lectureId: 5, universityId: uid, secretCode: codes[uid], token, deviceId: `device-${n}-abcdefgh`, geo: inside, ...extra };
  };
  return { config, store, service, clock, codes, inside, scanFor };
}

/** نفس setup لكن مع الخدمات الكاملة (حضور + أعذار + إرشاد) */
export function setupFull(overrides = {}) {
  const base = setup(overrides);
  const full = createServices({ store: base.store, config: base.config, now: () => base.clock.t });
  const scanFor = (n, extra = {}) => {
    const uid = String(20230000 + n);
    const { token } = full.getLiveToken(5);
    return { lectureId: 5, universityId: uid, secretCode: base.codes[uid], token, deviceId: `device-${n}-abcdefgh`, geo: base.inside, ...extra };
  };
  const creds = (n, extra = {}) => ({ universityId: String(20230000 + n), secretCode: base.codes[String(20230000 + n)], ...extra });
  return { ...base, service: full, scanFor, creds };
}
