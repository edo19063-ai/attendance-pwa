# خادم الحضور الذكي (Express)

كل قرارات الأمان على الخادم: توليد التوكن، التحقق منه، التحقق الجغرافي، وكتابة الحضور.
الواجهة تعرض وترسل فقط، ولا تملك أي سر أو منطق تحقق.

## البنية
```
server/
├─ src/
│  ├─ server.js              نقطة التشغيل (تحميل الإعدادات، التخزين، الاستماع)
│  ├─ app.js                 تجميع Express والـ middleware
│  ├─ config.js              الإعدادات، ويرفض الأسرار الضعيفة
│  ├─ lib/
│  │  ├─ token.js            HMAC-SHA256 للتوكن الزمني (+ nonce لكل جلسة)
│  │  ├─ geo.js              Haversine + شروط دقة الـ GPS
│  │  └─ crypto.js           scrypt، مقارنة ثابتة الزمن، جلسات المحاضر الموقّعة
│  ├─ services/attendance.js كل منطق العمل (لا يعتمد على Express)
│  ├─ store/                 تخزين JSON ذرّي + بيانات تجريبية
│  └─ http/                  المسارات + الأمان (CORS، حدود المعدّل، الأخطاء)
├─ test/                     27 اختباراً
└─ client/api.ts             عميل API للواجهة
```

## التشغيل
```bash
cd server
npm install
cp .env.example .env        # املأ الأسرار الثلاثة (الأمر موجود داخل الملف)
npm run dev                 # عند أول تشغيل تُطبع أكواد الطلاب السرية مرة واحدة
npm test
```

## واجهة API
| الطريقة | المسار | من | الوظيفة |
|---|---|---|---|
| POST | `/api/auth/login` | محاضر | كلمة المرور ← رمز جلسة (8 ساعات) |
| POST | `/api/lectures/:id/session/open` / `close` | محاضر | فتح/إغلاق جلسة الحضور |
| GET | `/api/lectures/:id/token` | محاضر | التوكن الحالي لعرضه كـ QR |
| GET | `/api/lectures/:id/roster` | محاضر | قائمة الطلاب وحالاتهم |
| PUT | `/api/lectures/:id/attendance/:studentId` | محاضر | تعديل يدوي (Present/Absent/Late/Excused) |
| GET | `/api/courses/:id/report` | محاضر | تقرير النسب |
| POST | `/api/students/:id/secret/rotate` | محاضر | كود سري جديد (يظهر مرة واحدة) |
| GET | `/api/audit` | محاضر | سجل التدقيق |
| POST | `/api/attendance/scan` | طالب | `{lectureId, universityId, secretCode, token, deviceId, geo}` |

## ما الذي يُمنع فعلياً (ومغطى باختبارات)
| محاولة غش | الحماية |
|---|---|
| تزوير توكن | سر HMAC في الخادم فقط، و`nonce` عشوائي لكل جلسة |
| تمرير التوكن لصديق | يلزم الرقم الجامعي + **كود سري خاص** (مجزّأ بـ scrypt) |
| تخمين الكود السري | قفل 15 دقيقة بعد 5 محاولات + حد معدّل لكل IP ولكل رقم جامعي |
| إعادة استخدام توكن قديم | صلاحية نافذتين (≈10 ثوانٍ) وتغيّر `nonce` بين الجلسات |
| تجاوز السياج الجغرافي | الموقع **إلزامي**، ودقة GPS ≤ 50م، وتُرفض (0,0) |
| جهاز واحد لعدة طلاب | ربط جهاز واحد بطالب واحد لكل محاضرة |
| المسح بعد إغلاق الجلسة | يُرفض |
| تغيير قرار المحاضر بالمسح | يُرفض (`locked_by_instructor`) |
| معرفة موقع القاعة بالتجربة | لا تُرجَع المسافة الدقيقة للطالب (تُسجَّل في التدقيق) |
| تسريب بيانات | الأخطاء الداخلية لا تُرسل للعميل، وسجل التدقيق لا يحوي أسراراً |

## حدود لا يستطيع أي تطبيق ويب إغلاقها كلياً
- **انتحال GPS** (تطبيقات Mock Location على أجهزة مُعدَّلة): نقلّل الخطر بالدقة وربط الجهاز والتدقيق، لا نلغيه. للحماية الأقوى استخدم تطبيقاً أصلياً مع Play Integrity / App Attest.
- **تواطؤ طالبين**: إذا أعطى طالبٌ كودَه السري لصديقه وكان الصديق داخل القاعة بجهازه، فسيُقبل. `deviceId` يمكن تغييره بمسح بيانات المتصفح. السجل يكشف الأنماط المشبوهة.
- **التخزين**: ملف JSON مناسب لقاعة/كلية صغيرة وخادم واحد. للتوسع انقل `Store` إلى PostgreSQL/MySQL، وحدود المعدّل إلى Redis.

## النشر
- **HTTPS إلزامي**: المتصفح يمنع الكاميرا والـ GPS بدونه.
- خلف nginx/سحابة: اضبط `TRUST_PROXY=1` ليقرأ الخادم IP الحقيقي.
- أضف مجلد `data/` للنسخ الاحتياطي، وغيّر كلمة مرور المحاضر بانتظام.

## ربط الواجهة
1. انسخ `client/api.ts` إلى `src/services/api.ts`.
2. في `vite.config.ts`:
   ```ts
   server: { proxy: { '/api': 'http://localhost:4000' } }
   ```
3. استبدل في الواجهة:
   - `LiveScreenView`: بدل `generateToken(...)` استدعِ `fetchLiveToken(lectureId)` وارسم `token` كـ QR، وجدول الطلب التالي بعد `expiresInMs`.
   - `StudentScannerView`: بدل `scanAttendance` من `AttendanceContext` استدعِ `scanAttendance` من `api.ts` مع حقل إدخال للكود السري. احذف أوضاع محاكاة الموقع.
   - `ManualAttendanceView` ← `setStudentStatus`، و`ReportsView` ← `fetchReport`.
4. احذف `src/utils/security.ts` من الواجهة (يحوي السر القديم) وغيّر أي سر كان مستخدماً.

## استيراد بيانات الواجهة (مهم)
لكي تتطابق معرّفات الطلاب والمحاضرات بين الواجهة والخادم، شغّل من مجلد `web/`:
```bash
npm run export-seed      # يكتب ../server/data/seed-input.json
```
ثم شغّل الخادم لأول مرة (يستورد الملف تلقائياً). تُهمَل الأكواد السرية القديمة وتُولَّد أكواد جديدة تُطبع مرة واحدة.
لإعادة الاستيراد من الصفر احذف `server/data/db.json` ثم أعد التشغيل (سيضيع الحضور المسجَّل).

## مسارات إضافية (الأدوار والتفويض والتفاعل)
| الطريقة | المسار | من | الوظيفة |
|---|---|---|---|
| POST | `/api/auth/assistant-login` | معيد | `{accessCode}` ← جلسة مقيّدة بمحاضرة التفويض |
| GET | `/api/auth/me` | محاضر/معيد | الدور الحالي |
| POST | `/api/delegations` | محاضر | `{assistantName, lectureId, durationMinutes}` ← كود تفويض (مرة واحدة) |
| GET | `/api/delegations?lectureId=` | محاضر | قائمة التفويضات وحالتها |
| POST | `/api/delegations/:id/revoke` | محاضر | سحب فوري |
| GET | `/api/lectures/:id/assistant-log` | محاضر/معيد (لمحاضرته) | سجل تدقيق التفويض وأفعال المعيد |
| POST | `/api/lectures/:id/participation` | محاضر/معيد (لمحاضرته) | نقطة تفاعل لطالب |
| GET | `/api/lectures/:id/feedback` | محاضر/معيد (لمحاضرته) | متوسط التقييم وتوزيعه (بلا أسماء) |
| POST | `/api/feedback` | طالب | `{feedbackToken, score}` (الرمز يأتي من نتيجة المسح، عمره 30 دقيقة) |
| POST | `/api/excuses` · `/api/excuses/mine` | طالب | تقديم عذر / عرض أعذاره (بهويته) |
| GET/POST | `/api/excuses` · `/api/excuses/:id/review` | محاضر | مراجعة الأعذار |
| GET/POST/PUT/DELETE | `/api/academic-alerts…` · `/api/advising/at-risk` | محاضر | الإرشاد الأكاديمي |
